"""Thanksgiving decorations (Alex, Nov 2026): a turkey walking along the bottom of the home page and
the daily puzzle screens, and fall leaves drifting down behind everything. Only on US Thanksgiving
(the 4th Thursday of November) by the player's own date, so they turn themselves off the next day.
UAT can show them any day with ?turkey=1 in the address (gui.thanksgiving_preview).

Also on Thanksgiving: the daily Wordle is a Thanksgiving word (daily.THANKSGIVING_WORDS), solving a
daily sends the turkey running across with a burst of leaves (draw_celebration), shared results show
🦃 for 🟩 (turkey_squares), and tapping the turkey makes it hop and gobble.

Everything here draws straight in pixels on the surface it's given, behind the game's own drawing (the
celebration, a couple of seconds long, on top). The turkey's tap target is registered before every
button, and the game gives a tap to the last target registered under it, so a button always wins."""
import datetime
import math
import random

import pygame

import daily

TURKEY_W, TURKEY_H = 64, 58   # the turkey's box in points at full size (feet on the bottom edge)
WALK_SPEED = 34               # points a second
STEP = 7.0                    # points walked per leg swing (radians of the walk cycle per point = 1 / STEP)
PAUSE_EVERY_MS = 7000         # every 7 s it stops for a moment...
PAUSE_MS = 1600               # ...to peck at the ground or gobble
HOP_MS = 700                  # a tapped turkey hops twice...
HOP_HEIGHT = 9                # ...this high (points, at full size)
GOBBLE_MS = 1500              # and says "Gobble gobble!" this long
CELEBRATE_MS = 2600           # a daily solved on Thanksgiving: leaves burst out...
RUN_MS = 1700                 # ...and the turkey runs across the screen in this long
BURST_LEAVES = 34
BURST_GRAVITY = 620           # points a second, a second
SAYINGS = ["Happy Thanksgiving!", None, "Gobble gobble!", None]  # one per pause, in turn (None = peck)

FEATHERS = [(142, 52, 32), (196, 98, 38), (226, 160, 58), (120, 74, 40)]
BODY = (112, 70, 42)
WING = (86, 52, 30)
HEAD = (196, 160, 140)
SNOOD = (204, 44, 44)
BEAK = (240, 172, 52)
LEGS = (226, 150, 48)

LEAF_COLORS = [(214, 102, 36), (190, 54, 38), (226, 168, 48), (150, 88, 40), (232, 132, 44)]
LEAF_STRENGTH = 0.62          # leaves are mixed this much into the background: there, but quiet


def thanksgiving(year):
    """US Thanksgiving: the fourth Thursday of November (daily.py also gives that day's Wordle its word)."""
    return daily.thanksgiving(year)


def is_thanksgiving(date):
    return date == thanksgiving(date.year)


def preview_requested(search):
    """?turkey=1 in the address (only honoured on UAT, see gui.thanksgiving_preview)."""
    return "turkey=1" in search.lstrip("?").split("&")


def turkey_squares(text):
    """A shared result on Thanksgiving: 🦃 for every 🟩. (A tile-costume account's squares are its
    own emoji already, with no 🟩 left, so its joke stays as it is.)"""
    return text.replace("\U0001F7E9", "\U0001F983")


def mix(color, background, amount):
    return tuple(round(b + (c - b) * amount) for c, b in zip(color, background))


# ----- the turkey -------------------------------------------------------------

def walk_state(now, width):
    """Where the turkey is at `now` (ms) walking back and forth across `width` points:
    (x of its box's left edge, facing right?, walk cycle in radians, pause progress 0-1 or None,
    the pause's saying or None)."""
    lane = max(1.0, width - TURKEY_W)
    walk_ms = PAUSE_EVERY_MS - PAUSE_MS
    rounds, into = divmod(now, PAUSE_EVERY_MS)
    walked_ms = rounds * walk_ms + min(into, walk_ms)
    distance = walked_ms / 1000 * WALK_SPEED
    leg, along = divmod(distance, lane)
    facing_right = int(leg) % 2 == 0
    x = along if facing_right else lane - along
    pause = None
    saying = None
    if into >= walk_ms:
        pause = (into - walk_ms) / PAUSE_MS
        saying = SAYINGS[int(rounds) % len(SAYINGS)]
    return x, facing_right, distance / STEP, pause, saying


def ellipse_points(cx, cy, rx, ry, angle, steps=18):
    ca, sa = math.cos(angle), math.sin(angle)
    points = []
    for i in range(steps):
        t = 2 * math.pi * i / steps
        x, y = rx * math.cos(t), ry * math.sin(t)
        points.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return points


def turkey_surface(scale, cycle, peck):
    """The turkey facing right, `scale` pixels per point, its legs at `cycle`, its head `peck` (0-1) of the
    way down to the ground."""
    s = scale
    surface = pygame.Surface((max(1, round(TURKEY_W * s)), max(1, round(TURKEY_H * s))), pygame.SRCALPHA)
    ground = TURKEY_H - 1
    bob = abs(math.sin(cycle)) * 1.4 * (1 - peck)

    def P(x, y):
        return (x * s, y * s)

    def poly(color, points):
        pygame.draw.polygon(surface, color, [P(x, y) for x, y in points])

    def circle(color, x, y, r):
        pygame.draw.circle(surface, color, P(x, y), max(1, r * s))

    def line(color, a, b, width):
        pygame.draw.line(surface, color, P(*a), P(*b), max(1, round(width * s)))

    # Legs first (behind the body), swinging opposite each other.
    hip_y = 47 - bob
    for i, hip_x in enumerate((26, 32)):
        swing = math.sin(cycle + i * math.pi) * 3.2 * (1 - peck)
        foot = (hip_x + swing, ground)
        line(LEGS, (hip_x, hip_y), foot, 2.2)
        line(LEGS, foot, (foot[0] + 4.5, ground), 1.8)
        line(LEGS, foot, (foot[0] + 3, ground - 2.2), 1.4)

    # The tail fan: two rings of feathers behind the body, swaying a little with each step.
    sway = math.sin(cycle) * 0.05
    tail_x, tail_y = 22, 33 - bob
    for ring, (length, width, offset) in enumerate(((24, 6.5, 0), (17, 5.5, 1))):
        for i in range(7):
            angle = math.radians(-168 + i * 26) + sway
            color = FEATHERS[(i + offset) % len(FEATHERS)]
            if ring:
                color = mix(color, (255, 236, 200), 0.18)
            cx = tail_x + math.cos(angle) * length * 0.55
            cy = tail_y + math.sin(angle) * length * 0.55
            poly(color, ellipse_points(cx, cy, length * 0.5, width, angle))

    # Body and wing.
    poly(BODY, ellipse_points(29, 38 - bob, 15, 12.5, -0.1))
    poly(WING, ellipse_points(26, 39 - bob, 9, 6.5, 0.25))
    for i in range(3):  # wing feather lines
        line(mix(WING, (0, 0, 0), 0.3), (21 + i * 3, 41 - bob), (27 + i * 3, 37 - bob), 1)

    # Neck and head: up and forward when walking, down at the ground when pecking.
    head_x = 43 + (50 - 43) * peck
    head_y = 20 + (ground - 7 - 20) * peck - bob
    line(HEAD, (37, 34 - bob), (head_x - 1, head_y + 3), 5)
    circle(HEAD, head_x, head_y, 5.6)
    poly(BEAK, [(head_x + 4.5, head_y - 1.6), (head_x + 9.5, head_y + 0.6), (head_x + 4.5, head_y + 2.4)])
    poly(SNOOD, ellipse_points(head_x + 5, head_y + 5.2, 1.8, 3.6, 0.2, 10))  # the red wattle
    circle((255, 255, 255), head_x + 1.6, head_y - 1.6, 1.7)
    circle((20, 20, 20), head_x + 2.1, head_y - 1.6, 0.9)
    return surface


def hop_height(since_tap):
    """How high (points, at full size) the turkey is `since_tap` ms after a tap: two little hops."""
    if since_tap is None or not 0 <= since_tap < HOP_MS:
        return 0.0
    return abs(math.sin(since_tap / HOP_MS * 2 * math.pi)) * HOP_HEIGHT


def draw_turkey(screen, scale, now, left, right, floor, size=1.0, background=(0, 0, 0), bubble=None,
                since_tap=None):
    """The turkey walking between `left` and `right` (points) with its feet on `floor`, `size` times
    full size. `bubble(text, x, y)` draws what it says (in points, the bubble's bottom middle), if given.
    `since_tap`: ms since the player tapped it (it hops and gobbles). Returns its box in points."""
    width = right - left
    x, facing_right, cycle, pause, saying = walk_state(now, width / size)
    x = left + x * size
    peck = 0.0
    if pause is not None and saying is None:
        # Down and up twice.
        peck = abs(math.sin(pause * 2 * math.pi))
    tapped = since_tap is not None and 0 <= since_tap < GOBBLE_MS
    if tapped:
        peck, saying = 0.0, "Gobble gobble!"
    surface = turkey_surface(scale * size, cycle, peck)
    if not facing_right:
        surface = pygame.transform.flip(surface, True, False)
    top = floor - TURKEY_H * size
    lift = hop_height(since_tap) * size
    screen.blit(surface, (round(x * scale), round((top - lift) * scale)))
    if saying and bubble:
        head_x = x + (43 if facing_right else TURKEY_W - 43) * size
        bubble(saying, head_x, top - lift + 8 * size)
    return pygame.Rect(round(x), round(top), round(TURKEY_W * size), round(TURKEY_H * size))


def draw_celebration(screen, scale, t, width, height, floor, origin, background):
    """A daily solved on Thanksgiving: the turkey runs across the screen along `floor` while a burst of
    leaves flies out of `origin` (points) and falls away. `t` = ms since it started; draws nothing after
    CELEBRATE_MS."""
    if not 0 <= t < CELEBRATE_MS:
        return
    seconds = t / 1000
    pick = random.Random(26)
    for _ in range(BURST_LEAVES):
        vx, vy = pick.uniform(-240, 240), pick.uniform(-460, -140)
        x = origin[0] + vx * seconds
        y = origin[1] + vy * seconds + 0.5 * BURST_GRAVITY * seconds * seconds
        if y > height + 20:
            continue
        spin = pick.uniform(-9, 9)
        color = pick.choice(LEAF_COLORS)
        draw_leaf(screen, scale, x, y, pick.uniform(7, 12), spin * seconds, 0.6 + 0.4 * abs(math.cos(spin * seconds)),
                  color, background)
    run = min(1.0, t / RUN_MS)
    x = -TURKEY_W + run * (width + TURKEY_W)
    if run < 1:
        surface = turkey_surface(scale, t / 45, 0.0)
        screen.blit(surface, (round(x * scale), round((floor - TURKEY_H - abs(math.sin(t / 45)) * 3) * scale)))


# ----- falling leaves -----------------------------------------------------------

def leaves_for(width):
    """A fixed set of leaves for this width (the same every frame, so they fall smoothly)."""
    count = max(8, min(26, int(width / 36)))
    pick = random.Random(1126 + count)
    leaves = []
    for i in range(count):
        leaves.append({
            "x": (i + pick.random()) / count,           # where across the screen it falls (0-1)
            "speed": pick.uniform(22, 46),              # points a second
            "start": pick.random(),                     # where in its fall it is at time 0
            "sway": pick.uniform(10, 26),               # points side to side
            "sway_ms": pick.uniform(2200, 4200),
            "spin_ms": pick.uniform(2600, 6000) * pick.choice((-1, 1)),
            "size": pick.uniform(7, 12),
            "color": LEAF_COLORS[i % len(LEAF_COLORS)],
            "phase": pick.uniform(0, 2 * math.pi),
        })
    return leaves


_leaves = {}


def draw_leaves(screen, scale, now, width, height, background):
    leaves = _leaves.get(width)
    if leaves is None:
        _leaves.clear()
        leaves = _leaves[width] = leaves_for(width)
    fall = height + 40
    for leaf in leaves:
        size = leaf["size"]
        y = ((now / 1000 * leaf["speed"]) + leaf["start"] * fall) % fall - 20
        x = leaf["x"] * width + math.sin(now / leaf["sway_ms"] * 2 * math.pi + leaf["phase"]) * leaf["sway"]
        angle = now / leaf["spin_ms"] * 2 * math.pi + leaf["phase"]
        # Tumbling: the leaf looks narrower as it turns edge-on.
        flat = 0.45 + 0.55 * abs(math.cos(now / (leaf["spin_ms"] * 0.7) * math.pi + leaf["phase"]))
        draw_leaf(screen, scale, x, y, size, angle, flat, mix(leaf["color"], background, LEAF_STRENGTH), background)


def draw_leaf(screen, scale, x, y, size, angle, flat, color, background):
    """A pointed leaf centred on (x, y) points, turned `angle` radians, `flat` (0-1) as seen edge-on."""
    ca, sa = math.cos(angle), math.sin(angle)

    def at(px, py):
        return ((x + px * ca - py * sa) * scale, (y + px * sa + py * ca) * scale)

    # Two curves meeting at the tip and the stem end.
    points = []
    for i in range(13):
        t = i / 12
        points.append(at(size * (t * 2 - 1), size * 0.55 * flat * math.sin(t * math.pi)))
    for i in range(1, 12):
        t = 1 - i / 12
        points.append(at(size * (t * 2 - 1), -size * 0.55 * flat * math.sin(t * math.pi)))
    pygame.draw.polygon(screen, color, points)
    vein = mix(color, background, 0.55)
    pygame.draw.line(screen, vein, at(-size * 1.35, 0), at(size * 0.85, 0), max(1, round(scale * 0.9)))
