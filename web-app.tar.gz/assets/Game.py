"""Game rules shared by the terminal game (Wordle.py / Quordle.py) and the GUI (gui.py).

Nothing in here reads input or prints, so any front end can drive it.
"""
from Board import Board

WORDLE_GUESSES = 6
QUORDLE_GUESSES = 9


class InvalidGuess(ValueError):
    """A guess the game won't accept. str(error) is a short message for the player."""


class Game:
    def __init__(self, words, dictionary, solver, max_guesses=None):
        self.words = [w.lower() for w in words]
        self.word_length = len(self.words[0])
        self.valid_words = dictionary if isinstance(dictionary, (set, frozenset)) else set(dictionary)
        self.solver = solver
        if max_guesses is None:
            max_guesses = WORDLE_GUESSES if len(self.words) == 1 else QUORDLE_GUESSES
        self.max_guesses = max_guesses
        self.boards = [Board(word) for word in self.words]
        self.guesses = []
        self._candidates = {}

    @property
    def remaining_guesses(self):
        return self.max_guesses - len(self.guesses)

    @property
    def won(self):
        return all(board.solved for board in self.boards)

    @property
    def over(self):
        return self.won or self.remaining_guesses <= 0

    def check(self, guess):
        """Return the normalized guess, or raise InvalidGuess."""
        guess = guess.strip().lower()
        if len(guess) < self.word_length:
            raise InvalidGuess("Not enough letters")
        if len(guess) > self.word_length:
            raise InvalidGuess("Too many letters")
        if guess not in self.valid_words:
            raise InvalidGuess("Not in word list")
        return guess

    def submit(self, guess):
        """Play a guess on every board. Returns the indexes of boards this guess solved."""
        if self.over:
            raise RuntimeError("The game is already over")
        guess = self.check(guess)
        was_solved = [board.solved for board in self.boards]
        for board in self.boards:
            board.process_guess(guess)
        self.guesses.append(guess)
        return [i for i, board in enumerate(self.boards) if board.solved and not was_solved[i]]

    def candidates(self, board_index):
        """Answers still possible on a board, given every guess it has seen."""
        return self.possible_after(board_index, len(self.boards[board_index].guesses))

    def possible_after(self, board_index, guess_count):
        """Answers that were still possible on a board after its first guess_count guesses."""
        key = (board_index, guess_count)
        if key not in self._candidates:
            if guess_count == 0:
                words = self.solver.answers
            else:
                guess, colors = self.boards[board_index].history()[guess_count - 1]
                words = self.solver.narrow(self.possible_after(board_index, guess_count - 1), guess, colors)
            self._candidates[key] = words
        return self._candidates[key]

    def known_answer(self):
        """The word that wins right now, if it's certain: one unsolved board left, with one answer left."""
        if self.over:
            return None
        unsolved = [i for i, board in enumerate(self.boards) if not board.solved]
        if len(unsolved) == 1:
            left = self.candidates(unsolved[0])
            if len(left) == 1:
                return left[0]
        return None

    def hint(self, board_index=None):
        """Suggest the guess that narrows things down the most.

        With no board_index the guess is chosen for all unsolved boards together; with one,
        only that board counts. Returns a Hint (hint.word is None if the solver is stumped).
        Raises ValueError if the board is already solved, or the game is over.
        """
        if self.over:
            raise ValueError("The game is already over")
        if board_index is not None and self.boards[board_index].solved:
            raise ValueError("Board %d is already solved" % (board_index + 1))
        considered = [None if board.solved or board_index not in (None, i) else self.candidates(i)
                      for i, board in enumerate(self.boards)]
        return Hint(self.solver.best_guess(considered), board_index, len(self.boards))


class Hint:
    """What the solver suggests, plus enough detail to explain why."""

    def __init__(self, suggestion, board_index, board_count):
        self.board = board_index      # the board asked about, or None for "all boards"
        self.board_count = board_count
        self.word = suggestion.word if suggestion else None
        # board index -> answers still possible / about how many would be left after this guess
        self.possible = {i: len(p) for i, p in enumerate(suggestion.possible) if p is not None} if suggestion else {}
        self.expected_left = suggestion.expected_left if suggestion else {}
        self.worst_left = suggestion.worst_left if suggestion else {}
        # Boards where this word is the only possible answer.
        self.sure_boards = [i for i, p in enumerate(suggestion.possible) if p == [self.word]] if suggestion else []

    def explain(self):
        """One short line saying why this word, e.g. "30 possible, about 4 left after this"."""
        if self.word is None:
            return "The solver is stumped. You're on your own!"
        multi = self.board_count > 1
        if self.sure_boards:
            if not multi:
                return "It can only be this word"
            return "%s can only be this word" % board_names(self.sure_boards)
        if len(self.possible) == 1:
            i = next(iter(self.possible))
            where = "Board %d: " % (i + 1) if multi else ""
            if self.worst_left[i] <= 1:
                after = "you'll know it after this"
            else:
                after = "about %s left after this" % round_left(self.expected_left[i])
            return "%s%d possible, %s" % (where, self.possible[i], after)
        target = self.target()
        return "%s: %d possible, about %s left after this" % (
            target[0].upper() + target[1:], sum(self.possible.values()), round_left(sum(self.expected_left.values())))

    def target(self):
        """Which boards this hint was chosen for, e.g. "all 4 boards" or "boards 1 and 3"."""
        if len(self.possible) == self.board_count:
            return "all %d boards" % self.board_count
        return board_names(sorted(self.possible)).lower()


def board_names(indexes):
    names = [str(i + 1) for i in indexes]
    if len(names) == 1:
        return "Board " + names[0]
    return "Boards %s and %s" % (", ".join(names[:-1]), names[-1])


def round_left(x):
    return "%d" % max(1, round(x)) if x > 0 else "0"
