"""The text people share after a game: colored squares, or the same with the words.

Wordle:                            With the words:
    Wordle Daily #9 4/6 (1 hint)       Wordle Daily #9 4/6 (1 hint)
    ⬛🟨⬛⬛⬛                            ⬛🟨⬛⬛⬛ RAISE
    🟨🟨⬛⬛⬛ 📖                         🟨🟨⬛⬛⬛ SLATE 📖
    ...                                ...
    🟩🟩🟩🟩🟩 💡                         🟩🟩🟩🟩🟩 CRANE 💡
    <link>                             <link>

A row ends in 💡 if a hint (or Solve) was shown while that guess was being typed, else 📖 if the
word list was opened (game["marks"], one per guess). Games from before marks were kept have no
row marks; the header still says if hints or the word list were used. Quordle shows how many guesses each board took, in the boards'
2x2 layout (🟥 = not solved), and a line naming the helped guesses; the version with the words adds
the answers in the same layout plus the guesses.
"""
import custom
from Board import score

PROD_LINK = "https://apeckman.github.io/wordle-web/"
SQUARES = {"green": "\U0001F7E9", "yellow": "\U0001F7E8", "black": "⬛"}
MISSED = "\U0001F7E5"
MARKS = {"hint": "\U0001F4A1", "list": "\U0001F4D6"}  # 💡 a hint (or Solve), 📖 the word list opened
NAMES = {"w": "Wordle", "q": "Quordle"}


def keycap(n):
    return "%d️⃣" % n


def title(game, max_guesses):
    """"Wordle Daily #9 4/6", "Quordle Practice X/9", "Alex's Wordle 3/6" (a custom Wordle)."""
    answers, guesses = game["answers"], game["guesses"]
    won = all(answer in guesses for answer in answers)
    score_text = "%d/%d" % (len(guesses), max_guesses) if won else "X/%d" % max_guesses
    if game.get("custom"):
        return "%s %s" % (custom.title(game["custom"]), score_text)  # "Alex's Wordle 4/6"
    kind = "Daily #%d" % game["daily"] if game.get("daily") is not None else "Practice"
    return "%s %s %s" % (NAMES[game["mode"]], kind, score_text)


REUSED = "\U0001F501"  # 🔁 a letter already shown gray, played again


def count_tiles(game):
    """(yellows, greens, grays, gray letters played again) over all the guesses.

    The colours: every yellow, green and gray tile; Quordle adds up all four boards, each counting
    its guesses up to the one that solved it (a solved board takes no more).
    Gray letters played again: every tile whose letter an earlier guess already showed isn't in the
    answer. A gray tile that's only an extra copy (one E gray while another E is yellow) doesn't
    rule the letter out, since it's in the word. In Quordle a letter counts once it's out of every
    board still unsolved at that guess, since until then it can still help another board."""
    yellows = greens = grays = 0
    guesses, answers = game["guesses"], game["answers"]
    for answer in answers:
        upto = guesses.index(answer) + 1 if answer in guesses else len(guesses)
        for guess in guesses[:upto]:
            colors = score(guess, answer)
            yellows += colors.count("yellow")
            greens += colors.count("green")
            grays += colors.count("black")
    again, tried = 0, set()
    for i, guess in enumerate(guesses):
        unsolved = [answer for answer in answers if answer not in guesses[:i]]
        # (every board still unsolved was shown each earlier guess, so a letter tried before and in
        # none of their answers was shown gray on all of them)
        again += sum(1 for letter in guess if letter in tried and not any(letter in answer for answer in unsolved))
        tried.update(guess)
    return yellows, greens, grays, again


def counts_text(game, max_guesses, link=PROD_LINK):
    """The result as tile counts, no grid:  Wordle Daily #9 4/6 / 🟨 5 · 🟩 9 · ⬛ 6 · 🔁 1 / <link>
    (🔁 = gray letters played again: count_tiles)."""
    yellows, greens, grays, again = count_tiles(game)
    lines = [title(game, max_guesses), "%s %d · %s %d · %s %d · %s %d" % (
        SQUARES["yellow"], yellows, SQUARES["green"], greens, SQUARES["black"], grays, REUSED, again)]
    if link:
        lines.append(link)
    return "\n".join(lines)


def left_text(counts):
    """A guess's answers left, one per board: "128" (Wordle), "412 · 380 · 1 · –" (Quordle, – = a board
    solved by an earlier guess)."""
    return " · ".join("–" if n is None else str(n) for n in counts)


def share_text(game, max_guesses, spoilers=False, link=PROD_LINK, left=None):
    """game: a history record (mode, daily, answers, guesses, hints, won).

    left: with spoilers, the answers still possible after each guess, one list per guess with a count
    per board (None for a board already solved), as the game shows next to each row (Game.possible_after);
    each guess line then ends in them: "⬛🟨⬛⬛⬛ RAISE · 128", Quordle one line per guess (Alex, Nov 2026)."""
    if left is not None and len(left) != len(game["guesses"]):
        left = None
    answers, guesses = game["answers"], game["guesses"]
    won = all(answer in guesses for answer in answers)
    header = title(game, max_guesses)
    notes = []
    hints = game.get("hints", 0)
    if hints:
        notes.append("%d hint%s" % (hints, "" if hints == 1 else "s"))
    marks = list(game.get("marks") or [])
    marks = (marks + [""] * len(guesses))[:len(guesses)]
    looked = marks.count("list")
    if looked:
        notes.append("%d with the word list" % looked)
    elif game.get("lists") and "marks" not in game:
        notes.append("word list used")  # (played before rows were marked: which guesses isn't known)
    if notes:
        header += " (%s)" % ", ".join(notes)
    lines = [header]

    def mark(i):
        return " " + MARKS[marks[i]] if marks[i] in MARKS else ""

    if len(answers) == 1:
        for i, guess in enumerate(guesses):
            row = "".join(SQUARES[color] for color in score(guess, answers[0]))
            words = ""
            if spoilers:
                words = " " + guess.upper() + (" · " + left_text(left[i]) if left else "")
            lines.append(row + words + mark(i))
        if spoilers and not won:
            lines.append("Answer: " + answers[0].upper())
    else:
        cells = []
        for answer in answers:
            cells.append(keycap(guesses.index(answer) + 1) if answer in guesses else MISSED)
        for top in (0, 2):
            row = cells[top] + " " + cells[top + 1]
            if spoilers:
                row += "   " + answers[top].upper() + " " + answers[top + 1].upper()
            lines.append(row)
        if spoilers and left:
            lines.append("Guesses (answers left per board):")
            for i, g in enumerate(guesses):
                lines.append(g.upper() + mark(i) + " · " + left_text(left[i]))
        elif spoilers:
            lines.append("Guesses: " + " ".join(g.upper() + mark(i).strip() for i, g in enumerate(guesses)))
        else:
            helped = ["%s guess %s" % (MARKS[kind], ", ".join(str(i + 1) for i, m in enumerate(marks) if m == kind))
                      for kind in ("hint", "list") if kind in marks]
            if helped:
                lines.append("   ".join(helped))

    if link:
        lines.append(link)
    return "\n".join(lines)
