"""The text people share after a game: colored squares, or the same with the words.

Wordle:                            With the words:
    Wordle Daily #9 4/6 (1 hint)       Wordle Daily #9 4/6 (1 hint)
    ⬛🟨⬛⬛⬛                            ⬛🟨⬛⬛⬛ RAISE
    🟨🟨⬛⬛⬛ 📖                         🟨🟨⬛⬛⬛ SLATE 📖
    ...                                ...
    🟩🟩🟩🟩🟩 💡                         🟩🟩🟩🟩🟩 CRANE 💡
    <link>                             <link>

A row ends in 💡 if that guess was a hint (or Solve) and 📖 if it was tapped in the word list
(game["marks"], one per guess). Quordle shows how many guesses each board took, in the boards'
2x2 layout (🟥 = not solved), and a line naming the helped guesses; the version with the words adds
the answers in the same layout plus the guesses.
"""
from Board import score

PROD_LINK = "https://apeckman.github.io/wordle-web/"
SQUARES = {"green": "\U0001F7E9", "yellow": "\U0001F7E8", "black": "⬛"}
MISSED = "\U0001F7E5"
MARKS = {"hint": "\U0001F4A1", "list": "\U0001F4D6"}  # 💡 a hint (or Solve), 📖 tapped in the word list
NAMES = {"w": "Wordle", "q": "Quordle"}


def keycap(n):
    return "%d️⃣" % n


def share_text(game, max_guesses, spoilers=False, link=PROD_LINK):
    """game: a history record (mode, daily, answers, guesses, hints, won)."""
    answers, guesses = game["answers"], game["guesses"]
    won = all(answer in guesses for answer in answers)
    score_text = "%d/%d" % (len(guesses), max_guesses) if won else "X/%d" % max_guesses
    kind = "Daily #%d" % game["daily"] if game.get("daily") is not None else "Practice"
    header = "%s %s %s" % (NAMES[game["mode"]], kind, score_text)
    notes = []
    hints = game.get("hints", 0)
    if hints:
        notes.append("%d hint%s" % (hints, "" if hints == 1 else "s"))
    marks = list(game.get("marks") or [])
    marks = (marks + [""] * len(guesses))[:len(guesses)]
    picked = marks.count("list")
    if picked:
        notes.append("%d from the word list" % picked)
    if notes:
        header += " (%s)" % ", ".join(notes)
    lines = [header]

    def mark(i):
        return " " + MARKS[marks[i]] if marks[i] in MARKS else ""

    if len(answers) == 1:
        for i, guess in enumerate(guesses):
            row = "".join(SQUARES[color] for color in score(guess, answers[0]))
            lines.append(row + (" " + guess.upper() if spoilers else "") + mark(i))
        if spoilers and not won:
            lines.append("Answer: " + answers[0].upper())
    else:
        cells = []
        for answer in answers:
            cells.append(keycap(guesses.index(answer) + 1) if answer in guesses else MISSED)
        for top in (0, 2):
            row = cells[top] + " " + cells[top + 1]
            if spoilers:
                row += "   " + answers[top].upper() + " " + answers[top + 1].upper()
            lines.append(row)
        if spoilers:
            lines.append("Guesses: " + " ".join(g.upper() + mark(i).strip() for i, g in enumerate(guesses)))
        else:
            helped = ["%s guess %s" % (MARKS[kind], ", ".join(str(i + 1) for i, m in enumerate(marks) if m == kind))
                      for kind in ("hint", "list") if kind in marks]
            if helped:
                lines.append("   ".join(helped))

    if link:
        lines.append(link)
    return "\n".join(lines)
