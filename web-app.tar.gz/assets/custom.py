"""Custom Wordles: a player picks a word and sends a link; whoever opens it plays that word (Alex, Nov 2026).

There's no server involved in making one: the word is scrambled into a short code in the link, like
the daily puzzles are worked out from the public code. Anyone who reads this file can decode a link,
which is fine for a game among friends; it just keeps the word out of sight in a text message.

A link looks like  <site>?w=CODE&by=MAKER&from=Alex
- CODE (7 characters) is the word, scrambled, with a check so a mistyped link is turned down.
- MAKER is the maker's tag from the server (sync.py's state["maker"], wordle.maker), so the server can tell
  whose word a finished game was played on (friends see each other's custom games in their 1-on-1). A
  link made before the device ever synced has none; the game still plays, it just isn't anyone's.
- from= is the maker's name as they chose it, only for the screen ("Alex's Wordle").

A custom game is saved like a practice game with record["custom"] = {"code", "by", "from"}; it never
counts in anyone's own stats (history.stats leaves it out), and one link gets one try per player.
Never change ALPHABET, SALT, MULTIPLIER or OFFSET: links already sent would stop working.
"""
import hashlib
import re
from urllib.parse import quote, unquote

ALPHABET = "abcdefghijkmnpqrstuvwxyz23456789"  # 32 characters, no l / o / 0 / 1 (they look alike)
SALT = "wordle-custom-2026"
BITS = 35                 # 7 characters of 5 bits
MASK = (1 << BITS) - 1
CHECK_BITS = 11           # the word takes 24 bits (26^5 < 2^24); the rest is a check
MULTIPLIER = 0x5DEECE66D & MASK | 1  # odd, so scrambling can be undone
OFFSET = 0x2C9277B5A3 & MASK
CODE_LENGTH = 7
NAME_LENGTH = 16
MAKER_RE = re.compile(r"^[a-z0-9]{8}$")
NAME_RE = re.compile(r"^[A-Za-z0-9 ]{1,16}$")


def _check(word):
    return int.from_bytes(hashlib.sha256((SALT + word).encode()).digest()[:2], "big") >> (16 - CHECK_BITS)


def _number(word):
    n = 0
    for letter in word:
        n = n * 26 + ord(letter) - ord("a")
    return n


def _word(n):
    letters = []
    for _ in range(5):
        n, letter = divmod(n, 26)
        letters.append(chr(ord("a") + letter))
    return "".join(reversed(letters)) if n == 0 else None


def encode(word):
    """The link code for a 5-letter word (lower case a-z)."""
    word = str(word).lower()
    if not re.match(r"^[a-z]{5}$", word):
        raise ValueError("a custom word is 5 letters")
    value = ((_number(word) << CHECK_BITS) | _check(word)) * MULTIPLIER + OFFSET & MASK
    out = []
    for _ in range(CODE_LENGTH):
        value, digit = divmod(value, 32)
        out.append(ALPHABET[digit])
    return "".join(out)


def decode(code):
    """The word a link code stands for, or None if it isn't a code (mistyped, cut short...)."""
    code = str(code or "").lower()
    if len(code) != CODE_LENGTH or any(c not in ALPHABET for c in code):
        return None
    value = 0
    for c in reversed(code):
        value = value * 32 + ALPHABET.index(c)
    value = (value - OFFSET) * pow(MULTIPLIER, -1, 1 << BITS) & MASK
    word = _word(value >> CHECK_BITS)
    if word is None or _check(word) != value & ((1 << CHECK_BITS) - 1):
        return None
    return word


def clean_name(name):
    """A maker's name fit for the screen (letters, digits and spaces, up to 16), or None."""
    name = " ".join(str(name or "").split())[:NAME_LENGTH].strip()
    return name if name and NAME_RE.match(name) else None


def make(word, maker=None, name=None):
    """The record["custom"] for a word: {"code", "by", "from"} (by / from may be None)."""
    return {"code": encode(word), "by": maker if isinstance(maker, str) and MAKER_RE.match(maker) else None,
            "from": clean_name(name)}


def link(site, custom):
    """The link to send for a custom Wordle (custom = make(...))."""
    out = "%s?w=%s" % (site, custom["code"])
    if custom.get("by"):
        out += "&by=" + custom["by"]
    if custom.get("from"):
        out += "&from=" + quote(custom["from"])
    return out


def parse(search):
    """(custom, word) from a page address's "?w=CODE&by=...&from=...", or None if there's no good code."""
    params = {}
    for part in str(search or "").lstrip("?").split("&"):
        name, _, value = part.partition("=")
        if name in ("w", "by", "from") and name not in params:
            try:
                params[name] = unquote(value.replace("+", " "))
            except Exception:
                params[name] = ""
    word = decode(params.get("w"))
    if word is None:
        return None
    custom = make(word, params.get("by", "").lower() or None, params.get("from"))
    return custom, word


def key(custom):
    """What tells two custom Wordles apart: the word and who made it (one try each)."""
    return "%s:%s" % (custom.get("code"), custom.get("by") or "")


def title(custom):
    """"Alex's Wordle", or "A custom Wordle" when the link has no name."""
    name = (custom or {}).get("from")
    if not name:
        return "A custom Wordle"
    return "%s' Wordle" % name if name.endswith("s") else "%s's Wordle" % name


def is_custom(game):
    return isinstance(game.get("custom"), dict)


def looks_like_custom(value):
    """A record["custom"] worth keeping (from storage or the server)."""
    return (isinstance(value, dict) and decode(value.get("code")) is not None
            and (value.get("by") is None or (isinstance(value.get("by"), str) and MAKER_RE.match(value["by"])))
            and (value.get("from") is None or clean_name(value.get("from")) == value.get("from")))
