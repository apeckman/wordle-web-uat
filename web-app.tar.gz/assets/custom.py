"""Custom Wordles: a player picks a word and sends a link; whoever opens it plays that word (Alex, Nov 2026).

There's no server involved in making one: the word is scrambled into a short code in the link, like
the daily puzzles are worked out from the public code. Anyone who reads this file can decode a link,
which is fine for a game among friends; it just keeps the word out of sight in a text message.

A link looks like  <site>?w=CODE&by=MAKER&from=Alex
- CODE is the word, scrambled, with a check so a mistyped link is turned down: 7 characters for a
  5-letter word, 5/6/8/9 for 3/4/6/7 letters (LENGTHS).
- MAKER is the maker's tag from the server (sync.py's state["maker"], wordle.maker), so the server can tell
  whose word a finished game was played on (friends see each other's custom games in their 1-on-1). A
  link made before the device ever synced has none; the game still plays, it just isn't anyone's.
- from= is the maker's name as they chose it, only for the screen ("Alex's Wordle").
- n= is the link's own id (4 random characters, a new one for every link sent), so a second link with the
  same word from the same maker is a new game, not the one already played (Alex, Nov 2026). Links from
  before it have none; those keep their old one-try-per-word-and-maker key.

A custom game is saved like a practice game with record["custom"] = {"code", "by", "from"} (+ "n"); it never
counts in anyone's own stats (history.stats leaves it out), and one link gets one try per player.
Never change ALPHABET, SALT, MULTIPLIER or OFFSET: links already sent would stop working.
"""
import hashlib
import re
from urllib.parse import quote, unquote

ALPHABET = "abcdefghijkmnpqrstuvwxyz23456789"  # 32 characters, no l / o / 0 / 1 (they look alike)
SALT = "wordle-custom-2026"
BITS = 35                 # 7 characters of 5 bits
MASK = (1 << BITS) - 1
CHECK_BITS = 11           # the word takes 24 bits (26^5 < 2^24); the rest is a check
MULTIPLIER = 0x5DEECE66D & MASK | 1  # odd, so scrambling can be undone
OFFSET = 0x2C9277B5A3 & MASK
CODE_LENGTH = 7
# Words of 3-7 letters (Alex, Nov 2026). A 5-letter word keeps its 7-character code exactly as above
# (links already sent); each other length has its own code length, so the code's length says the word's:
# letters -> (code characters, check bits). The word takes ceil(letters * log2(26)) bits, the rest is a check.
LENGTHS = {3: (5, 10), 4: (6, 11), 5: (7, 11), 6: (8, 11), 7: (9, 12)}
WORD_LENGTHS = tuple(sorted(LENGTHS))
CODE_LENGTHS = {code: letters for letters, (code, _check_bits) in LENGTHS.items()}
NAME_LENGTH = 16
MAKER_RE = re.compile(r"^[a-z0-9]{8}$")
NAME_RE = re.compile(r"^[A-Za-z0-9 ]{1,16}$")
LINK_ID_LENGTH = 4
LINK_ID_RE = re.compile(r"^[a-kmnp-z2-9]{4}$")  # (ALPHABET's characters)


def _shape(letters):
    """(code characters, bits, mask, check bits, multiplier, offset) for words of this length. For 5
    letters these are the constants above; the others take the same constants, cut to their size."""
    chars, check_bits = LENGTHS[letters]
    bits = 5 * chars
    mask = (1 << bits) - 1
    return chars, bits, mask, check_bits, 0x5DEECE66D & mask | 1, 0x2C9277B5A3 & mask


def _check(word, check_bits=CHECK_BITS):
    return int.from_bytes(hashlib.sha256((SALT + word).encode()).digest()[:2], "big") >> (16 - check_bits)


def _number(word):
    n = 0
    for letter in word:
        n = n * 26 + ord(letter) - ord("a")
    return n


def _word(n, letters=5):
    out = []
    for _ in range(letters):
        n, letter = divmod(n, 26)
        out.append(chr(ord("a") + letter))
    return "".join(reversed(out)) if n == 0 else None


def encode(word):
    """The link code for a word of 3-7 letters (lower case a-z)."""
    word = str(word).lower()
    if not re.match(r"^[a-z]{3,7}$", word):
        raise ValueError("a custom word is 3 to 7 letters")
    chars, _bits, mask, check_bits, multiplier, offset = _shape(len(word))
    value = ((_number(word) << check_bits) | _check(word, check_bits)) * multiplier + offset & mask
    out = []
    for _ in range(chars):
        value, digit = divmod(value, 32)
        out.append(ALPHABET[digit])
    return "".join(out)


def decode(code):
    """The word a link code stands for, or None if it isn't a code (mistyped, cut short...)."""
    code = str(code or "").lower()
    letters = CODE_LENGTHS.get(len(code))
    if letters is None or any(c not in ALPHABET for c in code):
        return None
    _chars, bits, mask, check_bits, multiplier, offset = _shape(letters)
    value = 0
    for c in reversed(code):
        value = value * 32 + ALPHABET.index(c)
    value = (value - offset) * pow(multiplier, -1, 1 << bits) & mask
    word = _word(value >> check_bits, letters)
    if word is None or _check(word, check_bits) != value & ((1 << check_bits) - 1):
        return None
    return word


def clean_name(name):
    """A maker's name fit for the screen (letters, digits and spaces, up to 16), or None."""
    name = " ".join(str(name or "").split())[:NAME_LENGTH].strip()
    return name if name and NAME_RE.match(name) else None


def new_link_id():
    """A fresh link id (n=) for a link about to be sent."""
    import secrets
    return "".join(secrets.choice(ALPHABET) for _ in range(LINK_ID_LENGTH))


def link_id(value):
    """value if it's a well-formed link id, else None."""
    return value if isinstance(value, str) and LINK_ID_RE.match(value) else None


def make(word, maker=None, name=None, n=None):
    """The record["custom"] for a word: {"code", "by", "from"} (by / from may be None), plus "n" (the
    link's own id) when it has one."""
    out = {"code": encode(word), "by": maker if isinstance(maker, str) and MAKER_RE.match(maker) else None,
           "from": clean_name(name)}
    if link_id(n):
        out["n"] = n
    return out


def link(site, custom):
    """The link to send for a custom Wordle (custom = make(...))."""
    out = "%s?w=%s" % (site, custom["code"])
    if custom.get("by"):
        out += "&by=" + custom["by"]
    if custom.get("from"):
        out += "&from=" + quote(custom["from"])
    if custom.get("n"):
        out += "&n=" + custom["n"]
    return out


def parse(search):
    """(custom, word) from a page address's "?w=CODE&by=...&from=...", or None if there's no good code."""
    params = {}
    for part in str(search or "").lstrip("?").split("&"):
        name, _, value = part.partition("=")
        if name in ("w", "by", "from", "n") and name not in params:
            try:
                params[name] = unquote(value.replace("+", " "))
            except Exception:
                params[name] = ""
    word = decode(params.get("w"))
    if word is None:
        return None
    custom = make(word, params.get("by", "").lower() or None, params.get("from"), params.get("n", "").lower() or None)
    return custom, word


def key(custom):
    """What tells two custom Wordles apart (one try each): the word, who made it and, for links that have
    one, the link's id (so the same word sent again is a new game)."""
    out = "%s:%s" % (custom.get("code"), custom.get("by") or "")
    return out + ":" + custom["n"] if custom.get("n") else out


def title(custom):
    """"Alex's Wordle", or "A custom Wordle" when the link has no name."""
    name = (custom or {}).get("from")
    if not name:
        return "A custom Wordle"
    return "%s' Wordle" % name if name.endswith("s") else "%s's Wordle" % name


def is_custom(game):
    return isinstance(game.get("custom"), dict)


def looks_like_custom(value):
    """A record["custom"] worth keeping (from storage or the server)."""
    return (isinstance(value, dict) and decode(value.get("code")) is not None
            and (value.get("by") is None or (isinstance(value.get("by"), str) and MAKER_RE.match(value["by"])))
            and (value.get("from") is None or clean_name(value.get("from")) == value.get("from"))
            and (value.get("n") is None or link_id(value.get("n")) is not None))
