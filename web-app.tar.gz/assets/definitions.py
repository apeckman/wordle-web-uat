"""Word definitions, bundled in Media/definitions so they work offline (and in a browser).

They come from WordNet 3.0 (Princeton University; license in Media/WORDNET_LICENSE), plus
hand-written ones for the answers WordNet misses. tools/make_definitions.py builds the file.
Every possible answer has a definition; many obscure guess words don't.
"""
from words import resource_path

PARTS_OF_SPEECH = {"n": "noun", "v": "verb", "a": "adjective", "r": "adverb", "x": ""}

_entries = None


def _load():
    global _entries
    if _entries is None:
        _entries = {}
        with open(resource_path("Media/definitions"), "r", encoding="utf-8") as f:
            for line in f:
                word, rest = line.rstrip("\n").split("\t", 1)
                _entries[word] = rest
    return _entries


class Definition:
    def __init__(self, word, senses, base=None):
        self.word = word
        self.senses = senses  # [(part of speech, meaning)], most common first; [] if unknown
        self.base = base      # the dictionary form the senses belong to (cranes -> crane), or None

    @property
    def found(self):
        return bool(self.senses)

    def lines(self):
        """Plain-text lines for showing it: "noun: a large wading bird", ..."""
        if not self.senses:
            return ["Not in the game's dictionary"]
        result = ["Form of %s" % self.base.upper()] if self.base else []
        for pos, meaning in self.senses:
            name = PARTS_OF_SPEECH.get(pos, "")
            result.append("%s: %s" % (name, meaning) if name else meaning)
        return result


def define(word):
    """The Definition of a word (found is False when there isn't one)."""
    word = word.lower()
    entries = _load()
    entry, base = entries.get(word), None
    if entry and entry.startswith("="):
        base = entry[1:]
        entry = entries.get(base)
    if not entry:
        return Definition(word, [])
    parts = entry.split("\t")
    return Definition(word, list(zip(parts[0::2], parts[1::2])), base)
