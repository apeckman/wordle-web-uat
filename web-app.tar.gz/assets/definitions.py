"""Word definitions, bundled in Media/definitions so they work offline (and in a browser).

They come from Wiktionary (CC BY-SA 4.0, via kaikki.org), with WordNet 3.0 (Princeton University)
as a fallback and for base forms, plus a few hand-written ones. Licenses: Media/DEFINITIONS_LICENSE
and Media/WORDNET_LICENSE. tools/make_definitions.py builds the file. Every possible answer has a
definition; some obscure guess words don't.
"""
from words import resource_path

_entries = None


def _load():
    global _entries
    if _entries is None:
        _entries = {}
        with open(resource_path("Media/definitions"), "r", encoding="utf-8") as f:
            for line in f:
                word, rest = line.rstrip("\n").split("\t", 1)
                _entries[word] = rest
    return _entries


class Definition:
    def __init__(self, word, senses, base=None, note=None):
        self.word = word
        # [(part of speech, meaning, example)], most common first; part of speech and example
        # may be "". Empty when the word isn't in the dictionary.
        self.senses = senses
        self.base = base  # the word the senses belong to when this is only a form of it (birds -> bird)
        self.note = note  # how it relates to base ("plural of bird")

    @property
    def found(self):
        return bool(self.senses)


def define(word):
    """The Definition of a word (found is False when there isn't one)."""
    word = word.lower()
    entries = _load()
    entry, base, note = entries.get(word), None, None
    if entry and entry.startswith("="):
        base, note = entry[1:].split("\t", 1)
        entry = entries.get(base)
    if not entry:
        return Definition(word, [])
    parts = entry.split("\t")
    return Definition(word, list(zip(parts[0::3], parts[1::3], parts[2::3])), base, note)
