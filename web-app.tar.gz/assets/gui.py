"""Graphical version of the game, built with pygame.

Run:  .venv/bin/python gui.py      (one-time setup: pip install -r requirements.txt)
The terminal version (python3 main.py) still works without pygame.

Controls: type letters, Enter to guess, Backspace to delete. The Hint button fills in the
guess that narrows things down the most; press Enter to play it. In Quordle, Hint first asks
which: all boards (1 guess for every unsolved board) or one board (also: keys 1-4, or tap a board
while choosing). Boards never give a hint from a tap alone. Next to each guessed row: "?" (left) shows what the
word means, and the count (right) lists the answers still possible.

The menu offers today's daily puzzle (the same words for everyone that day, see daily.py) or
practice games, plus stats and an archive of past daily puzzles. Games are saved on the device
(history.py); a daily puzzle in progress picks up where it was left. After a game, Share copies the
result (or opens the phone's share sheet), with or without the words (share.py). Once the server is
set up (sync.py), the Sync screen links devices so they all show the same games.
"""
import datetime
import json
import math
import os
import random
import subprocess
import sys
import threading
import time
import zlib

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
try:
    import pygame
except ImportError:
    sys.exit("The GUI needs pygame: pip install -r requirements.txt\n"
             "(or play the terminal version with: python3 main.py)")

import costume
import custom as custom_words
import daily
import thanksgiving
from Board import PRIORITY
from definitions import define
from Game import QUORDLE_GUESSES, WORDLE_GUESSES, Game, InvalidGuess
from history import (COUNTS_GAMES_KEPT, BrowserStorage, History, default_storage, helped_guesses, last_practice,
                     new_game, result_rank, split_from)
from share import PROD_LINK, counts_text, share_text
from Solver import Solver
from seeding import seed_random
from sync import Sync, default_transport, friend_custom, friend_games, friend_summary, result_text
from words import load_dictionary, load_length, load_word_bank, resource_path

# Running in a web browser (built with pygbag, see web/). No threads, no system fonts there.
WEB = sys.platform == "emscripten"
WEB_WIDTH = 600  # points; the page scales the canvas to fit the browser window
BOOT = {}  # web/main.py: when main.py, pygame, gui and the App were ready (ms since the page opened)
KEY_MAX_H = 82  # points: a key's tallest (on a phone 600 points are the screen's width: ~53 px, near the real Wordle's 58)
KEY_GAP = 6
WEB_STATUS_BLUR = 40  # CSS px below the iPhone status bar that iOS blurs in home-screen web apps
# Saying a word out loud (Settings: Say words aloud) on a computer: macOS's own voice. A browser
# speaks it from the page (web/template.tmpl wordleSay); elsewhere it stays quiet. test_gui blanks it.
SAY_COMMAND = ["say"] if sys.platform == "darwin" else None
UAT_COLOR = (230, 120, 40)  # the testing site's badge and icon background

WINDOW_SIZE = (740, 840)
MIN_SIZE = (520, 640)
FPS = 60

# Scrolling lists (Alex, Nov 2026: "can the scrolling be smoother everywhere"), tuned to feel like an
# iPhone's: the list follows the finger from where it passed the slop (no jump), keeps gliding after a
# flick and slows down like iOS's normal deceleration, and pulls back with a rubber band past either end.
DRAG_SLOP = 8            # points a finger moves before a press in a list counts as a drag, not a tap
SCROLL_DECAY = 0.998     # a gliding list keeps this share of its speed per millisecond (UIScrollView's normal rate)
SCROLL_MAX_SPEED = 7.0   # points per ms, the fastest flick
SCROLL_STOP_SPEED = 0.015  # points per ms: slower than this, a glide stops
SCROLL_SAMPLE_MS = 100   # a flick's speed comes from the finger's last 100 ms
SCROLL_CATCH_SPEED = 0.06  # a tap on a list gliding faster than this only stops it (like iOS), it doesn't pick a row
SPRING_W = 0.012         # the rubber band's spring (radians per ms, critically damped): back in about 0.4 s
SPRING_ENTRY_SPEED = 2.0  # points per ms a glide may still have as it runs past the end
RUBBER = 0.55            # iOS's rubber-band constant: dragging past the end moves the list less and less
FRect = getattr(pygame, "FRect", pygame.Rect)  # rows in a scrolling list sit on whole pixels, not whole points

# Palette
BG = (21, 25, 36)
PANEL = (33, 38, 54)
TEXT = (236, 239, 244)
DARK_TEXT = (21, 25, 36)
MUTED = (140, 148, 170)
EMPTY_BORDER = (50, 56, 76)
TYPED_BORDER = (112, 120, 146)
CURSOR_BORDER = (96, 165, 250)  # the Make a Wordle box the next letter goes in
CURSOR_FILL = (30, 44, 72)
KEY = (104, 112, 138)             # keyboard: letter not guessed yet (clearly lighter than...)
KEY_RULED_OUT = (33, 37, 50)       # ...a letter ruled out, which looks switched off
KEY_RULED_OUT_TEXT = (98, 105, 126)
BUTTON = (50, 57, 80)
ACCENT = (46, 160, 107)
SOLVED_TEXT = (96, 200, 145)  # "Solved in 4/6" on the menu and in the archive
LOST_TEXT = (236, 112, 112)  # "Lost" on the menu, the archive and the Friends screens
RELEASE_IDLE_MS = 20 * 1000  # reload for a new release on a menu left alone this long (reload_for_release)
INPUT_EVENTS = {pygame.KEYDOWN, pygame.TEXTINPUT, pygame.MOUSEBUTTONDOWN, pygame.MOUSEWHEEL, pygame.FINGERDOWN,
                pygame.FINGERMOTION}
ERROR_TEXT = (238, 150, 100)  # "That code didn't work" on the Sync screen
TILE_COLORS = {
    "green": (46, 160, 107),
    "yellow": (222, 168, 52),
    "black": (56, 60, 76),
}

# Animation timings (milliseconds)
FLIP_MS = 280
FLIP_STAGGER_MS = 140
POP_MS = 110
SHAKE_MS = 450
BOUNCE_MS = 420
BOUNCE_STAGGER_MS = 80
TOAST_MS = 1800
HINT_TOAST_MS = 4500
RESULT_SLIDE_MS = 300
UNDO_MS = 5000  # how long Sign out waits for an Undo (removing friends asks in a popup instead)

KEY_ROWS = [list("qwertyuiop"), list("asdfghjkl"), ["enter"] + list("zxcvbnm") + ["back"]]

WIN_MESSAGES = {  # one is picked per game (the same one if the game is shown again)
    1: ["Unreal!", "Mind reader!", "First try?!", "Are you psychic?", "Hole in one!", "Legendary!"],
    2: ["Brilliant!", "Genius!", "Incredible!", "Sharp as a tack!", "Lightning fast!", "Outstanding!"],
    3: ["Superb!", "Impressive!", "Excellent!", "Splendid!", "Top notch!", "On fire!"],
    4: ["Nice work!", "Great job!", "Well played!", "Nicely done!", "Good one!", "Very nice!"],
    5: ["Solid!", "Got there!", "Nice save!", "Steady wins it!", "Well earned!", "Not bad at all!"],
    6: ["Phew, close one!", "Just in time!", "Down to the wire!", "Cutting it close!", "Clutch!", "Made it!"],
}


REPLAY_NOTE = "Replays don\u2019t count toward your stats and are not synced"
MIN_CUSTOM_LETTERS, MAX_CUSTOM_LETTERS = custom_words.WORD_LENGTHS[0], custom_words.WORD_LENGTHS[-1]
CUSTOM_SOLVER_LIMIT = 200  # guesses scored per hint in a custom Wordle of 3, 4, 6 or 7 letters (Solver)
OWN_WORD_NOTE = "It\u2019s your own word, so this game isn\u2019t saved"
# While playing your own word (Alex, Nov 2026), in the message strip; the short one where there's no room.
OWN_WORD_STRIP = ("Your own word: just for fun, not saved or counted", "Your own word: not saved", "Not saved")


def win_message(game):
    """A congratulation for a won one-board game, chosen at random but the same each time this game is shown."""
    options = WIN_MESSAGES.get(len(game.guesses), ["Winner!"])
    seed = zlib.crc32(" ".join(list(game.words) + list(game.guesses)).encode())
    return options[seed % len(options)]


def clamp01(x):
    return max(0.0, min(1.0, x))


def ease_out(p):
    return 1 - (1 - p) ** 3


def lighten(color, amount):
    return tuple(min(255, int(v + (255 - v) * amount)) for v in color)


ICON_LETTERS = "ALEX"
APP_NAME = "Wordle"


def set_macos_app_name(name):
    """Show `name` instead of "Python" in the macOS menu bar.

    The game runs inside Python.app, so macOS uses that bundle's name. Changing the name in the
    bundle's info dictionary before the window (and NSApplication) exists makes the menu bar use
    ours. Uses ctypes to call the Objective-C runtime, so it needs no extra packages. Best effort:
    any failure just leaves the name as "Python".
    """
    if sys.platform != "darwin":
        return
    try:
        import ctypes
        import ctypes.util

        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        ctypes.cdll.LoadLibrary(ctypes.util.find_library("Foundation"))
        objc.objc_getClass.restype = ctypes.c_void_p
        objc.objc_getClass.argtypes = [ctypes.c_char_p]
        objc.sel_registerName.restype = ctypes.c_void_p
        objc.sel_registerName.argtypes = [ctypes.c_char_p]
        msg_send = ctypes.cast(objc.objc_msgSend, ctypes.c_void_p).value

        def send(receiver, selector, *args, restype=ctypes.c_void_p, argtypes=()):
            # objc_msgSend must be called through a prototype matching each call (required on Apple silicon).
            fn = ctypes.CFUNCTYPE(restype, ctypes.c_void_p, ctypes.c_void_p, *argtypes)(msg_send)
            return fn(receiver, objc.sel_registerName(selector), *args)

        def ns_string(text):
            return send(objc.objc_getClass(b"NSString"), b"stringWithUTF8String:", text.encode(),
                        argtypes=(ctypes.c_char_p,))

        bundle = send(objc.objc_getClass(b"NSBundle"), b"mainBundle")
        info = send(bundle, b"infoDictionary")
        if info:
            send(info, b"setObject:forKey:", ns_string(name), ns_string("CFBundleName"),
                 restype=None, argtypes=(ctypes.c_void_p, ctypes.c_void_p))
    except Exception:
        pass


def make_icon(fonts, size=512, full_bleed=False, background=BG):
    """App icon drawn in code: a 2x2 grid of game tiles spelling ICON_LETTERS on a dark rounded square.

    full_bleed: an opaque square with no border, for phones (iOS rounds the corners itself and
    turns transparent corners black). background: UAT_COLOR for the testing site's icon."""
    icon = pygame.Surface((size, size), pygame.SRCALPHA)
    if full_bleed:
        body = icon.get_rect()
        icon.fill(background)
    else:
        margin = round(size * 0.09)  # macOS icons leave a little transparent border
        body = pygame.Rect(margin, margin, size - 2 * margin, size - 2 * margin)
        pygame.draw.rect(icon, BG, body, border_radius=round(body.w * 0.22))
        pygame.draw.rect(icon, EMPTY_BORDER, body, max(2, size // 128), border_radius=round(body.w * 0.22))

    gap = round(body.w * 0.06)
    tile = (body.w - 2 * round(body.w * 0.13) - gap) // 2
    x0 = body.centerx - tile - gap // 2
    y0 = body.centery - tile - gap // 2
    for i, (letter, color) in enumerate(zip(ICON_LETTERS, ("green", "yellow", "black", "green"))):
        cell = pygame.Rect(x0 + (i % 2) * (tile + gap), y0 + (i // 2) * (tile + gap), tile, tile)
        pygame.draw.rect(icon, TILE_COLORS[color], cell, border_radius=round(tile * 0.16))
        label = fonts.render(letter, tile * 0.62, TEXT)
        icon.blit(label, label.get_rect(center=cell.center))
    return icon


def key_color(state):
    """Keyboard color for a letter's state on a board (None/"gray" = not guessed yet)."""
    if state == "black":
        return KEY_RULED_OUT
    return TILE_COLORS.get(state, KEY)


class Fonts:
    NAMES = "avenirnext,helveticaneue,helvetica,arial"

    def __init__(self):
        self._fonts = {}
        self._text = {}

    def get(self, size, bold=True):
        key = (max(8, int(size)), bold)
        if key not in self._fonts:
            self._fonts[key] = pygame.font.SysFont(self.NAMES, key[0], bold=bold)
        return self._fonts[key]

    def render(self, text, size, color, bold=True):
        key = (text, int(size), color, bold)
        surface = self._text.get(key)
        if surface is None:
            if len(self._text) > 3000:
                self._text.clear()
            surface = self.get(size, bold).render(text, True, color)
            self._text[key] = surface
        return surface


def rubber(distance, size):
    """How far a list shows past its end when dragged `distance` points past it (iOS's rubber band:
    less and less, never more than `size`, the list's height)."""
    return (1 - 1 / (distance * RUBBER / max(1, size) + 1)) * size


def unrubber(shown, size):
    """rubber() backwards: how far past the end a finger would be for the list to show `shown`."""
    size = max(1, size)
    shown = min(shown, size * 0.99)
    return (1 / (1 - shown / size) - 1) * size / RUBBER


def flick_speed(samples, now):
    """How fast (points per ms, + = down the list) a finger was moving as it lifted, from its
    (time, y) samples: zero if it had stopped before lifting."""
    if not samples:
        return 0.0
    still = len(samples) - 1  # (the finger's last spot: when did it get there?)
    while still > 0 and samples[still - 1][1] == samples[-1][1]:
        still -= 1
    if now - samples[still][0] > 40:  # (it stopped before lifting: no glide)
        return 0.0
    recent = [(t, y) for t, y in samples[:still + 1] if t >= now - SCROLL_SAMPLE_MS]
    if len(recent) < 2:
        return 0.0
    (t0, y0), (t1, y1) = recent[0], recent[-1]
    if t1 - t0 < 8:
        return 0.0
    speed = -(y1 - y0) / (t1 - t0)
    return max(-SCROLL_MAX_SPEED, min(SCROLL_MAX_SPEED, speed))


def release_label(pathname, search=""):
    """"UAT" on the testing site (its address has -uat in the path, or ?uat=1 to fake it), else None.

    UAT and prod run the very same files (publish_web.py promote copies UAT to prod unchanged), so
    the address is how the game knows where it is."""
    if "-uat/" in pathname or "uat=1" in search.lstrip("?").split("&"):
        return "UAT"
    return None


def sync_site(host, pathname, search=""):
    """Which of the server's sites games sync to: "prod" for the real website, "uat" for the testing
    site and any other address (like a local test build at localhost), so tests never mix with
    real players' games."""
    if host == "apeckman.github.io" and release_label(pathname, search) is None:
        return "prod"
    return "uat"


def browser_sync_site():
    if not WEB:
        return "uat"  # the Mac app is for testing: it syncs with the UAT site, never real players' games
    try:
        import platform
        location = platform.window.location
        return sync_site(str(location.host), str(location.pathname), str(location.search))
    except Exception:
        return "uat"


def debug_requested(search):
    """?debug=1 in the address: show the live diagnostics readout (draw_debug)."""
    return "debug=1" in search.lstrip("?").split("&")


def browser_debug():
    if not WEB:
        return False
    try:
        import platform
        return debug_requested(str(platform.window.location.search))
    except Exception:
        return False


def browser_turkey_preview():
    """?turkey=1 in the address: show the Thanksgiving turkey and leaves today (thanksgiving.py; UAT only)."""
    if not WEB:
        return False
    try:
        import platform
        return thanksgiving.preview_requested(str(platform.window.location.search))
    except Exception:
        return False


def browser_release_label():
    if not WEB:
        return None
    try:
        import platform
        location = platform.window.location
        return release_label(str(location.pathname), str(location.search))
    except Exception:
        return None


_safe_area_probe = None


def safe_area():
    """(top, bottom) CSS pixels the game must stay clear of: the notch/status bar and the home
    indicator when it runs full-screen from an iPhone home screen (zero in a normal browser tab).
    Add ?safe=47,34 to the URL to fake them for testing on a computer."""
    global _safe_area_probe
    import platform
    win = platform.window
    fake = str(win.location.search)
    if "safe=" in fake:
        top, bottom = fake.split("safe=")[1].split("&")[0].split(",")
        return float(top), float(bottom)
    if _safe_area_probe is None:
        # CSS knows the insets (env(safe-area-inset-*)); JavaScript can only read them off an element.
        _safe_area_probe = win.document.createElement("div")
        _safe_area_probe.style.cssText = ("position:fixed;top:0;left:0;visibility:hidden;pointer-events:none;"
                                          "padding-top:env(safe-area-inset-top);"
                                          "padding-bottom:env(safe-area-inset-bottom)")
        win.document.body.appendChild(_safe_area_probe)
    style = win.getComputedStyle(_safe_area_probe)
    return float(str(style.paddingTop).replace("px", "") or 0), float(str(style.paddingBottom).replace("px", "") or 0)


def touch_screen():
    """True in a browser on a phone or tablet (no mouse to hover, no keyboard to press W or Q)."""
    if not WEB:
        return False
    try:
        import platform
        return bool(platform.window.matchMedia("(pointer: coarse)").matches)
    except Exception:
        return False


def local_date():
    """Today's date where the player is. In a browser it comes from JavaScript's clock (web/template.tmpl
    defines wordleToday), which follows the phone's time zone."""
    if WEB:
        try:
            import platform
            year, month, day = (int(part) for part in str(platform.window.wordleToday()).split("-"))
            return datetime.date(year, month, day)
        except Exception:
            pass
    return datetime.date.today()


def browser_when(iso):
    """A saved time as the page words it in the phone's time zone (web/template.tmpl wordleWhen)."""
    try:
        import platform
        return str(platform.window.wordleWhen(iso)) or None
    except Exception:
        return None


def invite_code(search):
    """The friend code in an invite link's "?friend=ABCDEFGH", or None."""
    for part in str(search).lstrip("?").split("&"):
        name, _, value = part.partition("=")
        if name == "friend" and len(value) == 8 and value.isalpha():
            return value.upper()
    return None


def browser_invite():
    """A friend invite this page was opened with (then taken off the address, so a reload won't ask again)."""
    if not WEB:
        return None
    try:
        import platform
        location = platform.window.location
        code = invite_code(str(location.search))
        if code:
            platform.window.history.replaceState(None, "", str(location.pathname))
        return code
    except Exception:
        return None


def browser_custom():
    """A custom Wordle link this page was opened with: (custom, word) (custom.parse), or None. The ?w=...
    comes off the address straight away, so a reload or a home-screen icon made now opens the game as usual."""
    if not WEB:
        return None
    try:
        import platform
        location = platform.window.location
        search = str(location.search)
        if "w=" not in search:
            return None
        platform.window.history.replaceState(None, "", str(location.pathname))
        return custom_words.parse(search)
    except Exception:
        return None


MODE_NAMES = {"w": "wordle", "q": "quordle"}  # (in a screen's address)
MODES_BY_NAME = {name: mode for mode, name in MODE_NAMES.items()}


ROUTE_KEPT = 12  # screens remembered for Back (App.route_step)
SPARE_WAIT_MS = 700  # how long a new screen waits for the tap's spare history entry, and a spare for a new screen


def new_route(state):
    """App.route for the page's current history entry (browser_route_state)."""
    address, below, spare = state
    return {"addr": address, "below": list(below), "spare": None, "pending": None, "waiting": None,
            "after_back": None, "fix": True}


def screen_kind(address):
    """The kind of screen an address is ("daily", "friend", "stats"...): moving within one kind (a tab,
    a new practice game) isn't a new page for Back."""
    return "" if menu_address(address) else address.split("?")[0].split("/")[0]


def menu_address(address):
    """Is this the menu's address ("" or "practice": the Daily / Practice switch)?"""
    return address in ("", "practice")


def parse_address(address):
    """What a screen's address (after the #) opens: (screen, details), or ("menu", {}) for anything
    unknown. The opposite of App.address()."""
    address = str(address or "").lstrip("#")
    if address.startswith("custom?"):
        opened = custom_words.parse(address[len("custom"):])
        return ("custom", {"custom": opened[0], "word": opened[1]}) if opened else ("menu", {})
    parts = address.split("/")
    head, rest = parts[0], parts[1:]
    mode = MODES_BY_NAME.get(rest[0]) if rest else None
    if head == "practice" and not rest:
        return "menu", {"kind": "practice"}
    if head == "daily" and mode and len(rest) <= 2:
        if len(rest) == 1:
            return "daily", {"mode": mode, "number": None}
        if rest[1].isdigit() and 0 < int(rest[1]) < 100000:
            return "daily", {"mode": mode, "number": int(rest[1])}
    if head == "practice" and mode and len(rest) <= 2:
        return "practice", {"mode": mode, "id": rest[1] if len(rest) == 2 and rest[1].isalnum() else None}
    if head == "stats" and len(rest) == 2 and mode and rest[1] in ("daily", "practice", "all"):
        return "stats", {"mode": mode, "kind": rest[1]}
    if head == "archive" and len(rest) == 1 and mode:
        return "archive", {"mode": mode}
    if head == "friends" and (not rest or (len(rest) == 1 and mode)):
        return "friends", {"mode": mode or "w"}
    if head == "friend" and len(rest) == 1 and rest[0] and len(rest[0]) <= 64 \
            and rest[0].replace("-", "").isalnum():
        return "friend", {"id": rest[0]}
    if head in ("account", "settings", "make") and not rest:
        return head, {}
    return "menu", {}


def browser_route_state():
    """(address, below, spare) of the page's current history entry (web/template.tmpl wordleRouteState):
    below = the game's screens on the entries under it, oldest first; spare = it's an entry the page
    added during a tap for the game to fill (App.route_step). None off the web."""
    if not WEB:
        return None
    try:
        import platform
        state = json.loads(str(platform.window.wordleRouteState()))
        below = state.get("below")
        below = [str(a) for a in below if isinstance(a, str)][-ROUTE_KEPT:] if isinstance(below, list) else []
        return str(state.get("hash") or ""), below, bool(state.get("spare"))
    except Exception:
        return None


def browser_route(how, address="", below=(), steps=0):
    """Change the page's history: "fill" the spare entry or "replace" the current one with `address`
    (`below` = the screens under it), or "go" `steps` back (a negative number)."""
    try:
        import platform
        platform.window.wordleRoute(how, address, json.dumps(list(below)), steps)
    except Exception:
        pass


def browser_spare_take():
    """True once when the page has added a spare history entry during a tap (web/template.tmpl)."""
    try:
        import platform
        return bool(platform.window.wordleSpareTake())
    except Exception:
        return False


def browser_route_take():
    """The address the browser's Back or Forward went to since last asked (popstate), or None."""
    try:
        import platform
        taken = platform.window.wordleRouteTake()
        return None if taken is None else str(taken)
    except Exception:
        return None


def site_link():
    """The address to put in shared results: this site in a browser (UAT shares UAT), else prod."""
    if WEB:
        try:
            import platform
            location = platform.window.location
            return str(location.origin) + str(location.pathname)
        except Exception:
            pass
    return PROD_LINK


BOOT_STEPS = [  # (label, key): when each step of a launch was done, in the "started" note
    ("page", "html"), ("loader", "loader"), ("runtime", "runtime"), ("python", "python"), ("game files", "files"),
    ("pygame package", "pygame_pkg"), ("main.py", "main"), ("pygame", "pygame"), ("game code", "gui"), ("app", "app")]


def boot_steps(platform):
    """Where a launch went, in seconds since the page opened: when pygbag's files arrived and Python
    reached them (the page's timing, web/template.tmpl wordleBootTimes) and when main.py, pygame, the
    game code and the App were ready (web/main.py's BOOT marks). "" when none are known."""
    try:
        marks = json.loads(str(platform.window.wordleBootTimes()))
    except Exception:
        marks = {}
    marks = dict(marks) if isinstance(marks, dict) else {}
    marks.update({key: value for key, value in BOOT.items() if value is not None})
    return ", ".join("%s %.1f" % (label, marks[key] / 1000) for label, key in BOOT_STEPS
                     if isinstance(marks.get(key), (int, float)))


def home_screen_app(win):
    """True when launched from an iPhone home-screen icon (add ?standalone=1 to fake it)."""
    try:
        return bool(win.navigator.standalone) or "standalone=1" in str(win.location.search)
    except Exception:
        return False


def browser_view():
    """(width, height, pixel ratio, safe top, safe bottom) of the browser window in CSS pixels,
    or None outside a browser."""
    try:
        import platform  # pygbag's bridge to JavaScript
        win = platform.window
        try:
            top, bottom = safe_area()
        except Exception:
            top = bottom = 0.0
        if home_screen_app(win):
            # iOS blurs and fades a band below the status bar in home-screen web apps, so keep
            # the header clear of it (the page may start below the status bar, so top can be 0).
            top += WEB_STATUS_BLUR
        return win.innerWidth, win.innerHeight, win.devicePixelRatio or 1, top, bottom
    except Exception:
        return None


def web_canvas_size(view):
    """Layout size in points for the browser (WEB_WIDTH wide, shaped like the browser window), pixels
    per point so the canvas has as many pixels as it covers on screen (sharp on Retina), and the
    safe-area insets (top, bottom) in points."""
    if not view or view[0] <= 0 or view[1] <= 0:
        view = None  # a hidden or background tab can report a 0-size window; check_web_resize fixes it later
    css_w, css_h, dpr, top, bottom = view or (WEB_WIDTH, WEB_WIDTH * 1.4, 1, 0, 0)
    points =(WEB_WIDTH, int(min(1300, max(MIN_SIZE[1] * 1.25, WEB_WIDTH * css_h / css_w))))
    shown = min(css_w / points[0], css_h / points[1])  # the page scales the canvas to fit
    return points, max(1.0, min(3.0, shown * dpr)), (top / shown, bottom / shown)


def web_canvas_css(view, points):
    """The canvas's size on the page in CSS pixels (width, height): the layout scaled to fit the
    browser window without changing its shape, or None for a 0-size (hidden) window."""
    if not view or view[0] <= 0 or view[1] <= 0:
        return None
    shown = min(view[0] / points[0], view[1] / points[1])
    return int(points[0] * shown), int(points[1] * shown)



def frame_error_text(error):
    """An error's type, message and the last few places in the code it passed through, for the log."""
    import traceback
    where = traceback.extract_tb(error.__traceback__)[-3:] if error.__traceback__ else []
    path = " < ".join("%s:%d %s" % (w.filename.rsplit("/", 1)[-1], w.lineno, w.name) for w in reversed(where))
    return ("%s: %s" % (type(error).__name__, error))[:120] + (" (" + path + ")" if path else "")


class App:
    def __init__(self):
        set_macos_app_name(APP_NAME)  # must happen before pygame sets up the window system
        if WEB:
            seed_random()  # the browser's Python starts from the same random state on every load
            # Just graphics and text: starting the sound system makes browsers show a "playing audio" icon.
            pygame.display.init()
            pygame.font.init()
        else:
            pygame.init()
        # Use a taller window when the screen has room (bigger Quordle tiles).
        screen_h = pygame.display.Info().current_h
        size = (WINDOW_SIZE[0], max(MIN_SIZE[1], min(960, screen_h - 120)) if screen_h > 0 else WINDOW_SIZE[1])
        self.fonts = Fonts()
        icon = make_icon(self.fonts)

        # ?debug=1: a small live readout at the bottom of the screen, for finding slow or missed taps
        # on a phone (frames, taps the page saw vs. the game handled, canvas rebuilds, sync).
        self.debug = browser_debug()
        self.last_view = None  # (scene, mode, daily) last frame: a change syncs at once (tick_sync)
        self.dbg = {"frames": 0, "fps": 0, "second": 0, "slow": [], "fingers": 0, "mouse": 0, "dropped": 0,
                    "clicks": 0, "hits": 0, "rebuilds": 0, "last_tap": None}
        # For the server's log when the game stops answering (Nov 2026): the page's watchdog (watch())
        # and taps that hit nothing (missed_tap).
        self.beat_at = None   # when the page was last told the game is alive (ms)
        self.watch_at = None  # when the watchdog's notes were last collected (ms)
        self.missed = []      # recent taps that hit nothing (ms)
        self.missed_noted = None
        # The freeze hunt (Nov 2026: the whole page stopped a few seconds after starting, until the
        # app was hidden and shown again): how long each step of a frame took (lap), the last tap that
        # hit something, (note_slow_frame).
        self.laps = []
        self.last_tap_name = None   # (target name, screen, time.perf_counter())
        self.slow_noted = 0
        # All layout below is in "points" (what the window size and mouse use). On a Retina screen
        # pygame-ce gives us a surface with 2 pixels per point; self.scale converts at draw time.
        if WEB:
            # A fixed canvas shaped like the browser window (tall on a phone), scaled to fit by the page.
            self.window = None
            self.web_view = browser_view()
            self.web_resize = None  # (new view, when first seen) while the browser window is changing
            self.web_frames = 0
            self.apply_web_canvas()
        elif hasattr(pygame, "Window"):  # pygame-ce
            self.window = pygame.Window("Wordle / Quordle", size, resizable=True, allow_high_dpi=True)
            self.window.minimum_size = MIN_SIZE
            self.window.set_icon(icon)
        else:  # original pygame: works, but draws at 1x (soft on Retina)
            self.window = None
            pygame.display.set_caption("Wordle / Quordle")
            pygame.display.set_icon(icon)
            pygame.display.set_mode(size, pygame.RESIZABLE)
        self.begin_frame()
        pygame.key.set_repeat(350, 40)
        self.clock = pygame.time.Clock()

        self.word_bank = load_word_bank()
        dictionary = load_dictionary(self.word_bank)
        self.dictionary = set(dictionary)
        self.solver = Solver(self.word_bank)
        self.word_bank_set = set(self.word_bank)
        self.custom_solvers = {}  # (custom Wordles: a solver per word length, see solver_for)

        self.history = History(default_storage(WEB))
        self.sync = Sync(self.history, default_transport(WEB), browser_sync_site())
        if WEB:
            self.sync.format_when = browser_when
            try:
                import platform
                agent = str(platform.window.navigator.userAgent)
                # (just the device and browser, for the server's sync log: "iPhone Safari", "Mac Chrome 157")
                device = "iPhone" if "iPhone" in agent else "iPad" if "iPad" in agent else "Android" if "Android" in agent \
                    else "Mac" if "Macintosh" in agent else "Windows" if "Windows" in agent else "other"
                import re
                browser = re.search(r"(CriOS|Chrome|Firefox|FxiOS|EdgA?|Version)/(\d+)", agent)
                self.sync.agent = "%s %s" % (device, ("%s %s" % browser.groups()).replace("Version", "Safari")
                                             if browser else "")
                if bool(platform.window.navigator.standalone):
                    self.sync.agent += " home-screen"
            except Exception:
                pass
        self.friends_screen = {"mode": "w", "scroll": 0}
        self.friend_view = None  # {"id", "scroll"}: one friend's page (tap them in the Friends list)
        self.removing_friends = set()  # friends just removed (hidden until the server's list catches up)
        self.pending = None  # {"text", "action", "at", "key"}: an action waiting for its Undo time to pass
        self.dialog = None   # {"title", "text", "yes", "action"}: a confirmation popup
        self._menu_kind = "daily"  # the menu's Daily / Practice switch: every launch starts on Daily
        self.follow_wanted = False  # synced games changed: see follow_other_device once tiles stop flipping
        # The game's own state (start() sets it again for each game). Set here too, so code that runs on
        # every screen (tick_sync reads self.reveal) works before any game has been opened.
        self.reveal = None
        self.typed = ""
        self.pop = None
        self.shake_start = None
        self.shown_hint = None
        self.hint_hover = False
        self.result_at = None
        self.bounces = {}
        self.board_grid = (1, 1)
        self.entry = None  # {"kind": "friend" / "name", "text"} while typing on the Friends screen
        self.stats_mode = "w"
        self.stats_kind = "daily"  # the Stats screen's Daily / Practice / All switch
        self.archive = {"mode": "w", "scroll": 0}
        self.record = None       # the history entry for the game on screen
        self.daily = None        # its daily puzzle number (None for practice)
        self.replay = False      # it's a replay of a finished practice game: never saved, synced or counted
        self.custom = None       # the custom Wordle on screen ({"code", "by", "from"}, custom.py), or None
        self.own_word = False    # ...and it's this player's own word (played, but never saved: a replay)
        self.make = None         # the Make a Wordle screen's state: {"word", "custom"} once a word is ready
        self.link = site_link()
        self.share_targets = []  # (rect, text) for each Share button drawn this frame (the browser needs them)
        self.published_share = None
        self.say_targets = []  # (rect, word) for each spot that says a word, for the page (publish_say_targets)
        self.published_say = None
        self.saying = None  # the Mac's "say" process
        self.flip_stats = None   # the first flip's frame count and timings (measure_flip), noted once
        self.flip_noted = False
        self.published_auth = None  # the sign-in form spec last handed to the page (browser)
        self.published_push = ""
        self.last_input = 0      # when the player last pressed, tapped or typed (reload_for_release)
        self.woke_at = None      # when the page last came back into view (poll_woke)
        self.release_checked = None  # the push channel last handed to the page (browser; sync.push_channel)
        self.auth_input = {"mode": None}  # the Mac app's own sign-in form: typed fields and the focused one
        self.today_cache = None
        self.memo_cache = {}

        self.clickables = []  # (rect, action(now), name) registered by the last draw
        self.shown_enter_tip = False
        self.touch = touch_screen()
        self.release = browser_release_label()  # "UAT" on the testing site
        # The Thanksgiving turkey any day: ?turkey=1, only on UAT (prod waits for the day itself).
        self.turkey_preview = self.release == "UAT" and browser_turkey_preview()
        self.turkey_tap = None   # when the turkey was last tapped (it hops and gobbles)
        self.celebrate = None    # when a daily solved on Thanksgiving set the turkey running
        self.last_touch = -10000  # when the last FINGERDOWN arrived (to drop its emulated mouse click)
        self.drag = None          # a finger (or mouse) pressed in a scrolling list (scroller()), maybe dragging it
        self.fling = None         # a list gliding after a flick, or springing back past an end: {"info", "v", "at"}
        self.scroll_area = None   # where the open panel (words-left list or definition) scrolls
        self.wrap_cache = {}
        self.mode = None
        self.words = None
        self.go_to_menu()
        invite = browser_invite()
        if invite and self.sync.configured:
            self.sync.state()["invite"] = invite
            self.history.save()
            self.open_friends()
        opened = browser_custom()
        if opened:
            self.open_custom(*opened)
        # Each screen has its own address after the # (address()), so a reload opens the same screen and
        # the browser's Back goes to the one before (route_step; Alex, Nov 2026). A home-screen icon or a
        # shared link has none, so opening the game still starts on the Daily menu.
        self.route = None
        state = browser_route_state()
        if state is not None:
            if state[0] and not invite and not opened:
                self.open_address(state[0])
            self.route = new_route(state)

    # ----- state changes -------------------------------------------------

    def go_to_menu(self):
        self.scene = "menu"
        if self.entry and self.entry.get("kind") == "word":
            self.entry = None  # (leaving Make a Wordle)
        self.game = None
        self.thinking = None
        self.word_list = None
        self.definition = None
        self.hint_picker = False
        self.timers = []
        self.toasts = []

    def start(self, mode, words=None, number=None, resume=False, record=None, replay=False, custom=None):
        """Start a practice game (random words, or these `words`; `resume` carries on with the one left
        unfinished, if any), or daily puzzle `number`, which carries on from where it was left (or shows
        the finished game). `record`: show this saved game (finished or not) instead. `replay`: play
        `words` again after finishing them; a replay is kept only on screen (you already know the
        answer), so it's never saved, synced or counted in stats. `custom`: play `words` as this custom
        Wordle (custom.py; carries on from where it was left, or shows the finished game: one try per link)."""
        saved = None
        replay = bool(replay and words and number is None and record is None)
        if record is not None:
            custom = record.get("custom")
        custom = dict(custom) if custom and mode == "w" and number is None and not replay else None
        own = bool(custom and custom.get("by") and custom["by"] == self.sync.maker())
        if record is not None:
            saved, words = record, record["answers"]
        elif custom is not None:
            if not own:
                saved = self.history.custom_game(custom)[0]
            replay = own  # (your own word: you know the answer, so it's kept only on screen, like a replay)
        elif number is not None:
            saved, _finished = self.history.daily_game(mode, number)
            words = saved["answers"] if saved else daily.daily_words(self.word_bank, mode, number)
            if not saved and mode == "w" and self.turkey_preview and number == daily.puzzle_number(self.today()):
                words = [daily.THANKSGIVING_PREVIEW_WORD]  # (UAT's ?turkey=1: a stand-in, never the real word)
        elif resume:
            saved = self.history.practice_game(mode)
            words = saved["answers"] if saved else None
        self.mode = mode
        self.daily = number
        self.replay = replay
        self.custom = custom
        self.own_word = own
        count = 1 if mode == "w" else 4
        self.words = list(words) if words else random.sample(self.word_bank, count)
        last = None if words else last_practice(self.history.games, mode)
        while last is not None and self.words == list(last["answers"]):
            # Never the last practice game's words again, so history.replays() can't mistake a new game
            # for an old replay (CLEAN-UP with it, mid-2027).
            self.words = random.sample(self.word_bank, count)
        self.game = Game(self.words, self.dictionary_for(len(self.words[0])), self.solver_for(self.words, custom))
        self.scene = "game"
        self.typed = ""
        self.toasts = []
        self.timers = []
        self.reveal = None       # {"start": ms, "rows": {board_index: row_index}} while tiles flip
        self.shake_start = None
        self.pop = None          # (tile_index, start_ms) for the letter just typed
        self.bounces = {}        # board_index -> start_ms of its "solved" bounce
        self.result_at = None    # when the end-of-game panel appeared
        self.celebrate = None
        self.board_grid = (1, 1)
        self.thinking = None     # {"board", "guesses", "result"} while a hint is computed off-thread
        self.shown_hint = None   # the Hint whose word is in the typed row, for highlighting its boards
        self.hint_hover = False  # mouse is over the Hint button (Quordle previews which boards it covers)
        self.word_list = None    # {"board", "row", "scroll"} while the words-left list replaces the keyboard
        self.definition = None   # {"board", "row", "word", "scroll"} while a definition replaces the keyboard
        self.hint_picker = False  # Quordle: the "hint for which board?" chooser is open
        self.drag = None
        if saved:
            self.record = saved
            for guess in saved["guesses"]:
                try:
                    self.game.submit(guess)
                except (InvalidGuess, RuntimeError):
                    break
            if self.game.over:
                self.history.finish(saved, self.game.won, self.today())  # (does nothing if already recorded)
                self.result_at = -RESULT_SLIDE_MS  # already over: show the result without sliding it in
        elif replay:
            self.record = new_game(mode, self.words, custom=custom)  # (not handed to self.history)
        else:
            self.record = self.history.start(mode, self.words, number, custom=custom)

    # Each screen's address (after the # in a browser), for reloads and the browser's Back.

    def address(self):
        """This screen's address (parse_address reads it back). Popups, the word list, definitions and
        the sign-in form stay out of it. A replay keeps the address it was started from (it's never
        saved, so a reload shows the finished game again)."""
        scene = self.scene
        if scene == "menu":
            return "practice" if self.menu_kind == "practice" else ""
        if scene == "game":
            if self.custom:
                return custom_words.link("custom", self.custom)
            if self.replay:
                return self.route["addr"] if self.route else ""
            name = MODE_NAMES.get(self.mode, "wordle")
            if self.daily is not None:
                today = daily.puzzle_number(self.today())
                return "daily/" + name + ("" if self.daily == today else "/%d" % self.daily)
            game_id = (self.record or {}).get("id")
            return "practice/%s/%s" % (name, game_id) if game_id else "practice/" + name
        if scene == "stats":
            return "stats/%s/%s" % (MODE_NAMES.get(self.stats_mode, "wordle"), self.stats_kind)
        if scene == "archive":
            return "archive/" + MODE_NAMES.get(self.archive["mode"], "wordle")
        if scene == "friends":
            if self.friend_view:
                return "friend/%s" % self.friend_view["id"]
            return "friends/quordle" if self.friends_screen.get("mode") == "q" else "friends"
        return {"sync": "account", "settings": "settings", "make": "make"}.get(scene, "")

    def open_address(self, address):
        """Open the screen an address names (a reload, or the browser's Back / Forward). Anything that
        no longer fits (a daily from the future, a game that's gone) opens the closest thing: a new
        practice game, or the menu."""
        screen, details = parse_address(address)
        self.dialog = None
        if self.sync.auth_form and screen != "account":
            self.sync.auth_form = None  # (Back from the sign-in form: like its Cancel)
        self.go_to_menu()
        self.set_menu_kind(details.get("kind", "daily"))
        today = daily.puzzle_number(self.today())
        if screen == "daily":
            number = details["number"] or today
            if 1 <= number <= today:
                self.start(details["mode"], number=number)
        elif screen == "practice":
            mode, game_id = details["mode"], details["id"]
            finished = next((g for g in reversed(self.history.games) if game_id and g.get("id") == game_id
                             and g.get("mode") == mode and g.get("daily") is None and not g.get("custom")), None)
            if finished is not None:
                self.start(mode, record=finished)
            else:
                self.start(mode, resume=True)
        elif screen == "custom":
            self.open_custom(details["custom"], details["word"])
        elif screen == "stats":
            self.open_stats(details["mode"], details["kind"])
        elif screen == "archive":
            self.open_archive(details["mode"])
        elif screen in ("friends", "friend"):
            self.open_friends()
            if screen == "friends":
                self.friends_screen["mode"] = details["mode"]
            else:
                self.open_friend_page(details["id"])
        elif screen == "account":
            self.open_sync()
        elif screen == "settings":
            self.open_settings()
        elif screen == "make":
            self.open_make()

    def route_step(self, now):
        """Keep the page's address on this screen, every frame in a browser, and make the browser's Back
        go to the screen you were on before, step by step (Alex, Nov 2026).

        Each screen gets its own history entry, but the game can't add one itself: Safari and Chrome
        mark the entry you're leaving as one their Back button skips when a page adds an entry outside a
        tap, and the game only sees a tap a frame later (Back from the daily Quordle skipped the menu on
        Alex's iPhone). So the page adds a spare entry during every tap on something that may open a
        screen (publish_nav_targets; keys too, wordleNavKeys), and the game fills it with the new
        screen's address, or drops it (history.back(), which nothing skips) if the tap opened nothing.
        A new screen with no spare (opened without a tap) only replaces the address. Going to a screen
        that's already under this one (Home, a screen's own Back button) steps back to it. Moving within
        one kind of screen (a tab, a new practice game) isn't a new page. Each entry's state keeps the
        screens under it (`below`), so this works after a reload too."""
        route = self.route
        if route is None:
            return
        taken = browser_route_take()
        if taken is not None:
            state = browser_route_state()
            ours = route["waiting"] is not None
            route.update(waiting=None, addr=taken, below=state[1] if state else [], spare=None)
            if not ours:  # (the browser's own Back or Forward)
                route["pending"] = None
                if taken != self.address():
                    self.open_address(taken)
                route["fix"] = True
            elif route["after_back"] is not None:
                route["fix"], route["after_back"] = route["after_back"], None
        if route["waiting"] is not None:
            if now - route["waiting"] < 1500:
                return  # (a step back we asked for: wait for the browser to get there)
            route["waiting"] = None
        if browser_spare_take():
            route["spare"] = now
        want = self.address()
        fix, route["fix"] = route["fix"], False
        spare = route["spare"]
        if want == route["addr"]:
            route["pending"] = None
            if spare is not None and now - spare > SPARE_WAIT_MS:
                self.route_go(now, -1)  # (the tap opened nothing: drop its spare entry)
            return
        if fix:  # (the screen opened for a reload or a Back / Forward came out different: no new page)
            browser_route("replace", want, route["below"])
            route["addr"] = want
            return
        below = route["below"]
        if want in below:  # (Home, or a screen's own Back button: step back to it)
            index = len(below) - 1 - below[::-1].index(want)
            self.route_go(now, index - len(below) - (1 if spare is not None else 0))
            return
        if screen_kind(want) == screen_kind(route["addr"]) or menu_address(want) and menu_address(route["addr"]):
            if spare is not None:  # (not a new page: drop the spare, then change the address)
                self.route_go(now, -1, then=True)
                return
            browser_route("replace", want, below)
            route["addr"] = want
            return
        if spare is None:
            if route["pending"] is None:
                route["pending"] = now
            if now - route["pending"] < SPARE_WAIT_MS:
                return  # (the tap's spare entry comes as the finger lifts)
            browser_route("replace", want, below)  # (opened without a tap: no Back step)
            route.update(addr=want, pending=None)
            return
        below = (below + [route["addr"]])[-ROUTE_KEPT:]
        browser_route("fill", want, below)
        route.update(addr=want, below=below, spare=None, pending=None)

    def route_go(self, now, steps, then=False):
        """Step back through the page's history (history.go: unlike the Back button, nothing skips
        entries). `then`: once there, put this screen's address on that entry."""
        browser_route("go", steps=steps)
        self.route.update(waiting=now, spare=None, pending=None, after_back=True if then else None)

    def nav_rects(self):
        """The targets a tap on which may open a screen: every one except the keyboard, the board's
        buttons, the panels' words and the Share / Send link / Invite buttons. Those share on the tap
        itself, and stepping back off a spare entry (history.go) closes an iPhone's share sheet."""
        skip = ("key:", "count:", "define:", "word:", "say:", "board:", "auth:", "turkey:")
        shares = {tuple(rect) for rect, _text in self.share_targets}
        return [rect for rect, _action, name in self.clickables
                if not str(name).startswith(skip) and tuple(rect) not in shares]

    def publish_nav_targets(self):
        """Tell the page where the taps that may open a screen are (every target except the keyboard,
        the board's buttons and the panels' words), in canvas pixels, and whether keys may open one
        (not while typing a guess or a word): it adds a spare history entry during such a tap or key
        for route_step to fill."""
        # A target in a scrolling list acts when the finger lifts (2: the page always adds a spare);
        # any other acts as it goes down (1: the page adds one only if this tap changed the page by then,
        # wordleNavPage, once the game has seen it, wordleNavSeen: each spare the game steps back off is a
        # history.go, which made Safari flicker, Nov 2026).
        area = self.scroll_area if self.scroller() is not None else None
        targets = [[round(rect.x * self.scale), round((rect.y + self.offset_y) * self.scale),
                    round(rect.w * self.scale), round(rect.h * self.scale),
                    2 if area is not None and area.colliderect(rect) else 1] for rect in self.nav_rects()]
        keys = self.scene not in ("game", "make") and not self.entry
        address = self.address()
        page = "menu" if menu_address(address) else screen_kind(address)
        data = json.dumps([targets, keys])
        try:
            import platform
            platform.window.wordleNavSeen = self.dbg["fingers"] + self.dbg["mouse"]
            platform.window.wordleNavPage = page
            if data != getattr(self, "published_nav", None):
                platform.window.wordleNavTargets = json.dumps(targets)
                platform.window.wordleNavKeys = keys
                self.published_nav = data
        except Exception:
            pass

    def dictionary_for(self, letters):
        """The words accepted as guesses at this length: the usual list for 5 letters, else (a custom
        Wordle of 3, 4, 6 or 7 letters: Alex, Nov 2026) every word of that length in words.load_length."""
        return self.dictionary if letters == 5 else load_length(letters)

    def solver_for(self, words, custom=None):
        """The solver for these answers: the usual one (the 2,315 answers), or for a custom Wordle one that
        takes every accepted word of its length as a possible answer, since a friend may pick any of them
        (Alex, Nov 2026: counting the 2,315 plus the word itself gave an odd word away in the words-left
        list). It scores a spread of them (Solver's limit) to stay quick; one per length, kept."""
        letters = len(words[0])
        if custom is None and letters == 5:
            extra = [w for w in words if w not in self.word_bank_set]  # (a daily or practice game: never)
            return Solver(self.word_bank + extra) if extra else self.solver
        if letters not in self.custom_solvers:
            self.custom_solvers[letters] = Solver(sorted(self.dictionary_for(letters)), limit=CUSTOM_SOLVER_LIMIT)
        return self.custom_solvers[letters]

    def open_custom(self, custom, word):
        """Play a custom Wordle from a link (custom.parse). A word the game doesn't know isn't played."""
        if word not in self.dictionary_for(len(word)):
            self.go_to_menu()
            self.toast("That custom Wordle link didn't work", pygame.time.get_ticks(), 3200)
            return
        self.start("w", [word], custom=custom)

    def play_from_menu(self, mode):
        if self.menu_kind == "daily":
            self.start(mode, number=daily.puzzle_number(self.today()))
        else:
            self.start(mode, resume=True)

    # Settings (saved on this device in history.prefs).

    def fast(self):
        """Fast letter flips (Settings): the original speed. Normal flips take 2.5 times as long."""
        return self.history.prefs.get("flips") == "fast"

    def flip_ms(self, ms):
        return ms if self.fast() else ms * 5 // 2

    def counts_setting(self):
        """Settings' Answers remaining: the default for every game ("show" or "hide"; hidden unless turned on)."""
        return "show" if self.history.prefs.get("counts", "hide") == "show" else "hide"

    def show_counts(self):
        """The answers-remaining numbers next to each guessed row: Settings' choice, unless the game screen's
        Answers left switch changed it for the game on screen (game_counts)."""
        if self.scene == "game" and self.record is not None:
            choice = self.game_counts().get(self.record.get("id"))
            if choice in ("show", "hide"):
                return choice == "show"
        return self.counts_setting() == "show"

    def game_counts(self):
        """Games whose Answers left the game screen's switch changed: game id -> "show"/"hide" (Alex, Nov 2026:
        "changes only that game"). Kept in prefs["counts_games"], one of history.SYNCED_PREFS, so it follows
        the account to the same game on other devices like the other settings (newest wins); at most
        history.COUNTS_GAMES_KEPT."""
        kept = self.history.prefs.get("counts_games")
        return kept if isinstance(kept, dict) else {}

    def toggle_game_counts(self):
        """The game screen's Answers left switch: show or hide the counts for this game only. Settings'
        default stays as it is; switching back to the default just forgets the game."""
        game_id = self.record.get("id") if self.record else None
        if not game_id:
            return
        value = "hide" if self.show_counts() else "show"
        kept = {k: v for k, v in self.game_counts().items() if k != game_id}
        if value != self.counts_setting():
            kept[game_id] = value
        while len(kept) > COUNTS_GAMES_KEPT:
            kept.pop(next(iter(kept)))
        self.history.set_pref("counts_games", kept)
        self.sync.soon(pygame.time.get_ticks())  # (so the same game on the account's other devices follows)
        self.hint_picker = False

    def solving(self):
        """Is the header's Hint a "Solve" right now: the answer is certain (Game.known_answer) and Settings
        shows Answers remaining. With those numbers hidden it stays a plain "Hint", since "Solve" would give
        away that only one word is left (Alex, Nov 2026)."""
        return self.show_counts() and self.game.known_answer() is not None

    def speak_words(self):
        """Say a word out loud when its meaning opens (Settings; on unless turned off, on each device:
        the server only keeps the synced settings)."""
        return self.history.prefs.get("speak", "on") == "on"

    def say(self, word):
        """Say a word out loud. In a browser the page does it, during the tap itself (iPhone Safari only
        speaks from inside one): publish_say_targets tells it where; so nothing to do here."""
        if WEB or not SAY_COMMAND or not self.speak_words():
            return
        try:
            if self.saying is not None and self.saying.poll() is None:
                self.saying.terminate()
            self.saying = subprocess.Popen(SAY_COMMAND + [word.lower()], stdout=subprocess.DEVNULL,
                                           stderr=subprocess.DEVNULL)
        except Exception:
            self.saying = None

    def change_setting(self, key, value):
        if key == "counts" and self.game_counts():
            # Picking Answers remaining here (even the option already chosen) is the newest choice, so it
            # wins over every game's own switch, the game left open included (Alex, Nov 2026: changing both
            # mid-game should make sense; the last change wins).
            self.history.set_pref("counts_games", {})
        self.history.set_pref(key, value)
        self.sync.soon(pygame.time.get_ticks())  # (so the account, and its other devices, get it soon)

    def open_settings(self):
        self.scene = "settings"
        self.close_panel()
        self.toasts = []

    def draw_settings(self, now):
        w, h = self.size
        self.draw_screen_header("SETTINGS")
        col = pygame.Rect(max(24, w // 2 - 240), 0, min(480, w - 48), 0)
        y = 88
        rows = [("Letter flips", "How fast the tiles turn over after each guess.", "flips",
                 [("normal", "Normal"), ("fast", "Fast")], "fast" if self.fast() else "normal"),
                ("Answers remaining", "The number next to each guess: how many answers could still be right "
                 "after it (tap it to see them). A game's Answers left switch changes just that game, until you "
                 "pick here again.",
                 "counts", [("show", "Show"), ("hide", "Hide")], self.counts_setting()),
                ("Say words aloud", "Tapping ? next to a guess says the word as its meaning opens; tap the "
                 "word there to hear it again. Set on each device.",
                 "speak", [("on", "On"), ("off", "Off")], "on" if self.speak_words() else "off")]
        for title, note, key, options, value in rows:
            self.text(title, 18, TEXT, topleft=(col.x, y))
            y = self.paragraph(note, 14, MUTED, col, y + 28)
            self.segmented((col.x, y + 6, min(260, col.w), 40), options, value,
                           lambda choice, key=key: self.change_setting(key, choice), key)
            y += 74
        self.paragraph("Signed in, your settings follow your account to all your devices." if self.sync.signed_in else
                       "Saved on this device. Sign in and they follow your account to all your devices.",
                       13, MUTED, col, y + 4)

    # Make a Wordle: pick a word, send the link (custom.py).

    def open_make(self):
        self.scene = "make"
        self.close_panel()
        self.toasts = []
        self.entry = {"kind": "word", "text": "", "n": custom_words.new_link_id()}
        self.sync.fresh(pygame.time.get_ticks())  # (the maker tag comes with a sync)

    def new_game(self):
        """New / New game: a new practice game, or after (or during) a custom Wordle the Make a Wordle screen
        for a new custom word (Alex, Nov 2026)."""
        if self.custom:
            self.open_make()
        else:
            self.start(self.mode)

    def maker_name(self):
        """The name a custom Wordle link shows ("Alex's Wordle"): your Friends name, if you chose one."""
        profile = self.sync.friends_data().get("profile") or {}
        return custom_words.clean_name(profile.get("name"))

    def made_word(self):
        """(word, message, ok) for what's typed on the Make a Wordle screen; word is None until it's ready."""
        typed = (self.entry or {}).get("text", "").lower()
        if len(typed) < MIN_CUSTOM_LETTERS:
            return None, "Type your word", True  # (the boxes say how long: "3 to 7 letters")
        if typed not in self.dictionary_for(len(typed)):
            return None, "%s isn't in the word list" % typed.upper(), False
        return typed, "Ready: a %d-letter word. Send it to a friend" % len(typed), True

    def made_link_text(self, word):
        made = custom_words.make(word, self.sync.maker(), self.maker_name(), (self.entry or {}).get("n"))
        return "I made you a Wordle! Can you guess my word? %s" % custom_words.link(self.link, made)

    def send_made(self, now):
        """Send the Make a Wordle link: in a browser the page shares it on the tap itself (share_targets);
        a computer copies it."""
        word = self.made_word()[0]
        if word is None:
            self.shake_start = now
            return
        if not WEB:
            try:
                pygame.scrap.put_text(self.made_link_text(word))
                self.toast("Link copied: paste it in a message to a friend", now)
            except Exception:
                self.toast("Couldn't copy the link", now)
        # Every link sent gets its own id, so sending the same word again is a new game for whoever plays
        # it (Alex, Nov 2026). (In a browser the page already shared this one, inside the tap.)
        self.entry["n"] = custom_words.new_link_id()

    def draw_make(self, now):
        w, h = self.size
        self.draw_screen_header("MAKE A WORDLE")
        col = self.column()
        if self.entry is None or self.entry.get("kind") != "word":
            self.entry = {"kind": "word", "text": ""}
        y = self.paragraph("Pick a word for a friend to guess. They get one try with six guesses, like the real "
                           "thing.", 15, MUTED, col, 84, center=True)
        typed = self.entry["text"]
        # Always 7 boxes, so nothing moves while typing (Alex, Nov 2026: 5 boxes read as "5 letters"):
        # the first 3 are needed (plain boxes), 4 to 7 are optional (dashed), the next one to fill is lit.
        boxes = MAX_CUSTOM_LETTERS
        gap = 6
        tile = int(min(52, (col.w - (boxes - 1) * gap) / boxes))
        shake = 0
        if self.shake_start is not None and now - self.shake_start < 400:
            shake = int(math.sin((now - self.shake_start) / 400 * math.pi * 6) * 8)
        x = col.centerx - (boxes * tile + (boxes - 1) * gap) / 2 + shake
        for i in range(boxes):
            cell = pygame.Rect(round(x + i * (tile + gap)), y + 18, tile, tile)
            if i < len(typed):
                self.draw_tile(cell, typed[i], "typed")
            elif i == len(typed):
                self.draw_tile_cursor(cell, now)  # (Alex: the next box looks like neither a letter nor an empty box)
            elif i < MIN_CUSTOM_LETTERS:
                self.draw_tile(cell, "", "empty")
            else:
                self.draw_dashed_tile(cell)
        y += 18 + tile + 6
        self.text("%d to %d letters" % (MIN_CUSTOM_LETTERS, MAX_CUSTOM_LETTERS), 12, MUTED, center=(col.centerx, y + 7))
        y += 14 + 10
        word, message, ok = self.made_word()
        y = self.show_message((message, ok) if not ok else None, col, y) if not ok else \
            self.paragraph(message, 15, SOLVED_TEXT if word else MUTED, col, y + 4, center=True)
        send = self.button((col.centerx - 130, y + 10, 260, 46), "Send link" if WEB else "Copy link",
                           lambda now: self.send_made(now), size=16, primary=True, enabled=word is not None)
        if word is not None:
            self.share_targets.append((send, self.made_link_text(word)))
        y = send.bottom + 12
        name = self.maker_name()
        note = ("It shows as %s." % custom_words.title({"from": name}) if name else
                "Choose a name on the Friends screen and it shows as yours.")
        note += " If you're friends, you'll both see how it went on each other's Friends page."
        self.paragraph(note, 13, MUTED, col, y, center=True)
        self.draw_entry_keyboard(self.entry_keyboard_area())

    @property
    def menu_kind(self):
        """The menu's Daily / Practice switch. Every launch starts on Daily (Alex: opening the game
        should show today's puzzles); Practice lasts until the game is closed or reloaded."""
        return self._menu_kind

    def set_menu_kind(self, kind):
        self._menu_kind = "practice" if kind == "practice" else "daily"

    def open_stats(self, mode=None, kind=None):
        """Stats for mode ("w"/"q") and kind ("daily", "practice" or "all"); unset = as last shown,
        except that from the menu they follow its Daily / Practice switch."""
        if self.scene == "menu" and kind is None:
            kind = self.menu_kind
        self.scene = "stats"
        self.stats_mode = mode or self.stats_mode
        self.stats_kind = kind or self.stats_kind
        self.close_panel()
        self.toasts = []

    def open_sync(self):
        self.scene = "sync"
        self.entry = None
        self.sync.message = None
        self.toasts = []

    def open_friends(self):
        self.scene = "friends"
        self.friend_view = None
        self.removing_friends = set()
        self.sync.friends_at = None  # (fetch now: the friend code changes every few minutes)
        self.friends_screen = dict(self.friends_screen, scroll=0)
        self.entry = None
        self.sync.friends_message = None
        self.toasts = []

    def start_entry(self, kind):
        """Start typing a link code, a friend's code or a name (or stop, if already typing that)."""
        if self.entry and self.entry["kind"] == kind:
            self.entry = None
            return
        self.entry = {"kind": kind, "text": ""}
        self.sync.message = None
        self.sync.friends_message = None

    def entry_key(self, key, now):
        """A key for the code or name being typed (a letter, digit, "space", "back" or "enter")."""
        entry = self.entry
        if entry is None:
            return
        if entry["kind"] == "word":  # (Make a Wordle)
            if key == "back":
                entry["text"] = entry["text"][:-1]
            elif key == "enter":
                self.send_made(now)
            elif len(key) == 1 and key.isalpha() and key.isascii() and len(entry["text"]) < MAX_CUSTOM_LETTERS:
                entry["text"] += key.lower()
            return
        name = entry["kind"] == "name"
        if key == "back":
            entry["text"] = entry["text"][:-1]
        elif key == "enter":
            text = entry["text"].strip()
            if name and text:
                self.sync.set_name(text, now)
                self.entry = None
            elif len(text) == 8:
                self.sync.add_friend(text, now)
                self.entry = None
        elif key == "space":
            if name and entry["text"] and not entry["text"].endswith(" ") and len(entry["text"]) < 16:
                entry["text"] += " "
        elif len(key) == 1 and key.isalnum() and key.isascii() and (name or key.isalpha()):
            if len(entry["text"]) < (16 if name else 8):
                if not name or not entry["text"] or entry["text"].endswith(" "):
                    key = key.upper()  # (names: each word starts with a capital; the keyboard has no Shift)
                entry["text"] += key

    def open_archive(self, mode=None):
        self.scene = "archive"
        if mode and mode != self.archive["mode"]:
            self.archive = {"mode": mode, "scroll": 0}
        self.close_panel()
        self.toasts = []

    def today(self):
        """The local date, asked at most once a second (the browser asks JavaScript)."""
        now = pygame.time.get_ticks()
        if self.today_cache is None or now - self.today_cache[0] > 1000 or now < self.today_cache[0]:
            self.today_cache = (now, local_date())
        return self.today_cache[1]

    def memo(self, key, compute):
        """compute(), remembered until the saved games change (stats are drawn every frame)."""
        key = (self.history.revision, key)
        if key not in self.memo_cache:
            if len(self.memo_cache) > 60:
                self.memo_cache.clear()
            self.memo_cache[key] = compute()
        return self.memo_cache[key]

    def later(self, when, callback):
        self.timers.append((when, callback))

    def run_timers(self, now):
        due = [t for t in self.timers if t[0] <= now]
        self.timers = [t for t in self.timers if t[0] > now]
        for _, callback in due:
            callback(now)

    def toast(self, text, now, duration=TOAST_MS):
        self.toasts = [t for t in self.toasts if now - t[1] < t[2]][-2:] + [(text, now, duration)]

    def accepting_input(self):
        return self.scene == "game" and not self.game.over and self.reveal is None

    def type_letter(self, letter, now):
        if self.accepting_input() and len(self.typed) < self.game.word_length:
            self.typed += letter
            self.pop = (len(self.typed) - 1, now)

    def backspace(self, now=None):
        if self.accepting_input():
            self.typed = self.typed[:-1]

    def submit(self, now):
        if not self.accepting_input():
            return
        game = self.game
        try:
            guess = game.check(self.typed)
        except InvalidGuess as error:
            self.toast(str(error), now)
            self.shake_start = now
            return

        rows_before = [len(board.guesses) for board in game.boards]
        newly_solved = game.submit(guess)
        # Saved straight away (not after the tiles flip), so reloading can't undo a guess.
        self.record["guesses"] = list(game.guesses)
        # Which guesses had help: "hint" if a hint (or Solve) was shown while it was being typed,
        # "list" if the word list was opened (a word picked or not), "" if neither: shown in the
        # shared result. A hint wins when both were used.
        marks = (list(self.record.get("marks") or []) + [""] * len(game.guesses))[:len(game.guesses) - 1]
        self.record["marks"] = marks + [self.record.pop("help", "")]
        if self.replay:
            pass  # (a replay is never saved, synced or counted)
        elif game.over:
            self.history.finish(self.record, game.won, self.today())
            self.sync.soon(now)
        else:
            self.history.update(self.record)
            self.sync.soon(now)  # so another device carries on from here (daily or practice)
        self.reveal = {
            "start": now,
            "rows": {i: rows_before[i] for i, board in enumerate(game.boards) if len(board.guesses) > rows_before[i]},
        }
        self.typed = ""
        self.pop = None
        self.hint_picker = False
        done = now + self.flip_ms(FLIP_STAGGER_MS * (game.word_length - 1) + FLIP_MS)
        self.later(done, lambda t: self.finish_reveal(t, newly_solved))

    def finish_reveal(self, now, newly_solved):
        self.reveal = None
        for i in newly_solved:
            self.bounces[i] = now
        multi = len(self.game.boards) > 1
        if self.game.over and self.game.won and self.daily is not None and not self.replay and self.festive():
            self.celebrate = now  # Thanksgiving: the turkey runs across with a burst of leaves
        if self.game.over:
            delay = BOUNCE_MS + BOUNCE_STAGGER_MS * self.game.word_length if newly_solved else 350
            self.later(now + delay, self.show_result)
        elif newly_solved and multi:
            names = " and ".join(str(i + 1) for i in newly_solved)
            self.toast("Board %s solved!" % names, now)

    def show_result(self, now):
        self.result_at = now

    def hint(self, now, board_index=None):
        """Ask the solver for a hint. It can take up to a second, so it runs on a thread
        (in a browser, where there are no threads, it runs right after "Thinking..." is drawn)."""
        if not self.accepting_input() or self.thinking:
            return
        job = {"board": board_index, "guesses": len(self.game.guesses), "game": self.game,
               "result": None, "done": False, "polls": 0}
        self.thinking = job

        def work():
            try:
                job["result"] = job["game"].hint(board_index)
            except Exception:
                pass  # treated like no hint; never leave the button stuck on "thinking"
            finally:
                job["done"] = True

        if self.game.known_answer():
            work()  # "Solve": nothing to search for, so it's filled in at once
            self.poll_hint(now)
        elif WEB:
            job["work"] = work
        else:
            threading.Thread(target=work, daemon=True).start()

    def hint_button(self, now):
        """Wordle: hint straight away. Quordle: open (or close) the chooser, so a board-only hint
        never comes from a stray tap on a board."""
        if len(self.game.boards) == 1 or self.solving():
            self.hint(now)
        elif self.accepting_input() and not self.thinking:
            self.hint_picker = not self.hint_picker
            self.toasts = []  # the chooser uses the message strip

    def pick_hint(self, now, board_index=None):
        """From the chooser: None = best guess for all unsolved boards, else just that board."""
        self.hint_picker = False
        self.hint(now, board_index)

    def panel(self):
        """The scrollable panel open in the keyboard's spot (words-left list or definition), or None."""
        return self.word_list or self.definition

    def open_word_list(self, board_index, row):
        """Show (or, clicking the same count again, hide) the words left after a row."""
        current = self.word_list
        self.definition = None
        if current and (current["board"], current["row"]) == (board_index, row):
            self.word_list = None
        else:
            self.word_list = {"board": board_index, "row": row, "scroll": 0}
            if not self.game.over:
                self.record["lists"] = self.record.get("lists", 0) + 1
                self.note_help("list")
                self.save_progress()

    def save_progress(self):
        """Save the game on screen as it stands (a replay is never saved)."""
        if not self.replay:
            self.history.update(self.record)

    def note_help(self, kind):
        """The guess being typed had help ("hint" or "list"); kept in the saved game until it's
        played, so a reload doesn't lose it."""
        if self.record.get("help") != "hint":
            self.record["help"] = kind
            if not self.replay:
                self.sync.soon(pygame.time.get_ticks())  # (so another device finishing this guess marks it too)

    def open_definition(self, board_index, row):
        """Show (or, clicking the same "?" again, hide) what a guessed row's word means."""
        current = self.definition
        self.word_list = None
        if current and (current["board"], current["row"]) == (board_index, row):
            self.definition = None
        else:
            word = self.game.boards[board_index].history()[row][0]
            self.definition = {"board": board_index, "row": row, "word": word, "scroll": 0}
            self.say(word)

    def pick_word(self, word, now):
        if self.accepting_input():
            self.typed = word
            self.pop = None

    def close_panel(self, now=None):
        self.word_list = None
        self.definition = None

    def scroller(self):
        """What scrolls right now (a dict with "scroll"): the archive list, or the panel open over
        the keyboard. None if nothing does."""
        if self.scene == "archive":
            return self.archive
        if self.scene == "friends":
            return self.friend_view or self.friends_screen
        return self.panel() if self.scene == "game" else None

    def poll_hint(self, now):
        job = self.thinking
        if job and "work" in job and not job["done"]:
            job["polls"] += 1
            if job["polls"] >= 2:  # one frame showing "Thinking..." has been drawn
                job["work"]()
        if not job or not job["done"]:
            return
        self.thinking = None
        hint = job["result"]
        # Drop it if the player moved on (new game, or guessed) while it was computing.
        if hint is None or job["game"] is not self.game or job["guesses"] != len(self.game.guesses):
            return
        if not self.accepting_input():
            return
        if hint.word is None:
            self.toast(hint.explain(), now)
            return
        self.typed = hint.word
        self.pop = None
        self.shown_hint = hint
        self.record["hints"] = self.record.get("hints", 0) + 1
        self.note_help("hint")
        self.save_progress()
        if self.shown_enter_tip:
            self.toast(hint.explain(), now, HINT_TOAST_MS)
        else:
            self.shown_enter_tip = True
            self.toast(hint.explain() + ". Enter plays it", now, HINT_TOAST_MS)

    # ----- events --------------------------------------------------------

    def handle_event(self, event, now):
        if event.type == pygame.QUIT:
            return False
        if event.type in INPUT_EVENTS:
            self.last_input = now
        if event.type == getattr(pygame, "WINDOWFOCUSGAINED", -1) and not WEB:
            self.sync.woke(now)  # (back to the game window: pick up games played elsewhere)
        if event.type == pygame.VIDEORESIZE and self.window is None:
            w, h = max(MIN_SIZE[0], event.w), max(MIN_SIZE[1], event.h)
            if (w, h) != (event.w, event.h):
                pygame.display.set_mode((w, h), pygame.RESIZABLE)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dbg["mouse"] += 1
            if WEB and (getattr(event, "touch", False) or now - self.last_touch < 600):
                self.dbg["dropped"] += 1
                # Browsers report a tap twice: as a touch, then as an emulated mouse click. The
                # FINGERDOWN below already handled it (and Hint toggles, so twice would undo it).
                return True
            pos = (event.pos[0] / self.scale, event.pos[1] / self.scale - self.offset_y) if WEB else event.pos
            if self.scroller() is not None and self.scroll_area and self.scroll_area.collidepoint(pos):
                self.start_drag(pos, now, mouse=True)
            else:
                self.click(pos, now)
        elif event.type == pygame.MOUSEMOTION and self.drag and self.drag.get("mouse") and self.scroller() is not None:
            pos = (event.pos[0] / self.scale, event.pos[1] / self.scale - self.offset_y) if WEB else event.pos
            self.drag_to(pos, now)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.drag and self.drag.get("mouse"):
            self.end_drag(now)
        elif event.type == pygame.FINGERDOWN and WEB:
            # Phone taps: use the touch position itself (x/y are 0-1 across the canvas) rather than
            # the browser's emulated mouse, whose position can lag behind.
            self.last_touch = now
            self.dbg["fingers"] += 1
            self.dbg["last_tap"] = now
            pos = self.finger_pos(event)
            area = self.scroll_area if self.scroller() is not None else None
            if area and area.collidepoint(pos):
                # In the words-left list (or a definition) a finger can drag to scroll, so wait for it
                # to lift: a tap (little movement) picks the word under it, a drag only scrolls.
                self.start_drag(pos, now)
            else:
                self.click(pos, now)
        elif event.type == pygame.FINGERMOTION and WEB and self.drag and not self.drag.get("mouse") and self.scroller() is not None:
            self.drag_to(self.finger_pos(event), now)
        elif event.type == pygame.FINGERUP and WEB and self.drag and not self.drag.get("mouse"):
            self.last_touch = now
            self.drag_to(self.finger_pos(event), now)
            self.end_drag(now)
        elif event.type == pygame.MOUSEWHEEL and self.scroller() is not None:
            self.fling = None
            self.scroller()["scroll"] -= event.y * 24
        elif event.type == pygame.KEYDOWN:
            self.handle_key(event, now)
        return True

    def start_drag(self, pos, now, mouse=False):
        """A press inside a scrolling list: wait to see whether it's a tap (on release) or a drag. A press
        on a list still gliding fast catches it (it stops there, and the release picks nothing)."""
        info = self.scroller()
        fling, self.fling = self.fling, None
        caught = fling is not None and fling["info"] is info and abs(fling["v"]) > SCROLL_CATCH_SPEED
        scroll = info["scroll"]
        top = info.get("max", 0)
        if scroll < 0 or scroll > top:  # (caught past an end: carry on from where the rubber band is)
            d = self.scroll_area.h if self.scroll_area else 400
            scroll = -unrubber(-scroll, d) if scroll < 0 else top + unrubber(scroll - top, d)
        self.drag = {"start": pos, "scroll": scroll, "moved": False, "caught": caught, "info": info,
                     "samples": [(now, pos[1])], "slop": 0}
        if mouse:
            self.drag["mouse"] = True

    def drag_to(self, pos, now=0):
        """Scroll the open list with a dragging finger (or mouse), 1:1 from where it passed the slop,
        and with a rubber band past either end."""
        drag = self.drag
        dy = pos[1] - drag["start"][1]
        if not drag["moved"] and abs(dy) > DRAG_SLOP:
            drag["moved"] = True
            drag["slop"] = DRAG_SLOP if dy > 0 else -DRAG_SLOP  # (no jump as the list starts to move)
        samples = drag.setdefault("samples", [])
        samples.append((now, pos[1]))
        while len(samples) > 2 and samples[1][0] < now - SCROLL_SAMPLE_MS:
            samples.pop(0)
        info = self.scroller()
        if drag["moved"] and info is not None:
            top = info.get("max", 0)
            if top <= 0:  # (everything fits: nothing to scroll, so it doesn't stretch either; Alex, Nov 2026)
                info["scroll"] = 0
                return
            raw = drag["scroll"] - (dy - drag["slop"])
            d = self.scroll_area.h if self.scroll_area else 400
            if raw < 0:
                raw = -rubber(-raw, d)
            elif raw > top:
                raw = top + rubber(raw - top, d)
            info["scroll"] = raw

    def end_drag(self, now):
        """Lifting without having dragged is a tap: pick the row under it. Lifting after a drag lets the
        list glide on at the finger's speed (or spring back if it's past an end)."""
        drag, self.drag = self.drag, None
        info = self.scroller()
        if info is None:
            return
        if drag["moved"]:
            speed = flick_speed(drag.get("samples") or [], now) if info.get("max", 0) > 0 else 0.0
            self.fling = {"info": info, "v": speed, "at": now}
        elif not drag.get("caught"):
            self.click(drag["start"], now)

    def scroll_moving(self, info):
        """Is this list being dragged, gliding or springing back? (Then its scroll may be past an end.)"""
        drag, fling = self.drag, self.fling
        return bool((drag and drag.get("info") is info and drag["moved"]) or (fling and fling["info"] is info))

    def scroll_range(self, info, limit):
        """Called by each scrolling list as it draws: remembers how far it scrolls (`limit`, its content
        height minus its area's) and keeps the scroll inside 0..limit unless it's moving. Returns it."""
        top = info["max"] = max(0, limit)
        if not self.scroll_moving(info):
            info["scroll"] = max(0, min(info["scroll"], top))
        return info["scroll"]

    def step_scroll(self, now):
        """Move a gliding list on (once a frame): it slows down like an iPhone's, and past either end a
        critically damped spring pulls it back."""
        fling = self.fling
        if fling is None:
            return
        info = fling["info"]
        if info is not self.scroller() or (self.drag and self.drag.get("info") is info):
            self.fling = None
            return
        elapsed = min(64, max(0, now - fling["at"]))
        fling["at"] = now
        top = info.get("max", 0)
        x, v = float(info["scroll"]), fling["v"]
        while elapsed > 0:
            h = min(4, elapsed)
            elapsed -= h
            if 0 <= x <= top:
                v *= SCROLL_DECAY ** h
                x += v * h
                if x < 0 or x > top:  # (running past an end: the spring takes it from here)
                    v = max(-SPRING_ENTRY_SPEED, min(SPRING_ENTRY_SPEED, v))
            else:
                edge = 0 if x < 0 else top
                v += (-SPRING_W * SPRING_W * (x - edge) - 2 * SPRING_W * v) * h
                x += v * h
                if 0 <= x <= top:
                    x, v = edge, 0.0  # (back at the end: it stops there, no bounce the other way)
        fling["v"] = v
        info["scroll"] = x
        inside = 0 <= x <= top
        if inside and abs(v) < SCROLL_STOP_SPEED:
            self.fling = None
        elif not inside and abs(x - (0 if x < 0 else top)) < 0.5 and abs(v) < 0.02:
            info["scroll"] = 0 if x < 0 else top
            self.fling = None

    def finger_pos(self, event):
        """A touch event's position in points (event.x/y are 0-1 across the whole canvas)."""
        full_w, full_h = self.full_screen.get_size()
        return (event.x * full_w / self.scale, event.y * full_h / self.scale - self.offset_y)

    def click(self, pos, now):
        self.dbg["clicks"] += 1
        for rect, action, _name in reversed(self.clickables):
            if rect.collidepoint(pos):
                self.dbg["hits"] += 1
                self.last_tap_name = (_name, self.scene, time.perf_counter())
                if WEB:
                    try:
                        import platform
                        platform.window.wordleLastTap = "%s on %s" % (_name, self.scene)
                    except Exception:
                        pass
                action(now)
                break
        else:
            self.missed_tap(now)

    def missed_tap(self, now):
        """A tap that hit nothing. Several in a few seconds off the game screen (where nearly everything
        is a button) look like a screen that stopped answering: say so in the server's log, with how many
        targets the screen has (none would mean it didn't finish drawing), at most once a minute."""
        if self.scene == "game":
            return
        self.missed = [t for t in self.missed if now - t < 8000] + [now]
        if len(self.missed) >= 4 and (self.missed_noted is None or now - self.missed_noted >= 60 * 1000):
            self.missed_noted = now
            self.sync.note(now, "%d taps in 8 s hit nothing on %s (%d targets)" % (
                len(self.missed), self.scene, len(self.clickables)), important=True)

    def watch(self, now):
        """The page's watchdog (web/template.tmpl): tell it the game is alive (its frame and tap counts)
        every half second, and every 5 s pass what it noticed (frames stopped while on screen, the page
        blocked, taps that never reached the game, the page before this one stuck and then reloaded) to
        the server's log; once, how long this page took to start."""
        try:
            import platform
            if self.beat_at is None or now - self.beat_at >= 500:
                self.beat_at = now
                platform.window.wordleBeat = self.web_frames
                platform.window.wordleTaps = self.dbg["fingers"] + self.dbg["mouse"]
            first = self.watch_at is None
            if not first and now - self.watch_at < 5000:
                return
            self.watch_at = now
            if first:
                started = float(platform.window.performance.now()) / 1000
                steps = boot_steps(platform)
                try:
                    platform.window.wordleSplashDone()  # (the game has drawn: the loading screen goes)
                    taps = int(platform.window.wordleLoadingTaps or 0)
                except Exception:
                    taps = 0
                self.sync.note(now, "started: first frame %.1f s after the page opened%s%s" % (
                    started, " (%s)" % steps if steps else "",
                    ", %d taps while it was loading" % taps if taps else ""), important=started > 10 or taps > 0)
            notes = json.loads(str(platform.window.wordleWatchTake()))
        except Exception:
            return
        for text in notes[-10:] if isinstance(notes, list) else []:
            self.note_long(now, "watch: " + str(text))

    def note_long(self, now, text):
        """An important note for the server's log, in pieces that fit its 240-character lines (up to 3)."""
        for start in range(0, min(len(text), 3 * 210), 210):
            self.sync.note(now, ("... " if start else "") + text[start:start + 210], important=True)

    def handle_key(self, event, now):
        if self.dialog:
            if event.key == pygame.K_ESCAPE:
                self.dialog_answer(False, now)
            return
        if self.sync.auth_form and not WEB:
            self.auth_key(event, now)
            return
        if event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            return  # leave Cmd/Ctrl shortcuts (like Cmd+Q) to the system
        if pygame.K_a <= event.key <= pygame.K_z:
            char = chr(event.key)
        else:
            char = event.unicode.lower() if getattr(event, "unicode", "") else ""
        enter = event.key in (pygame.K_RETURN, pygame.K_KP_ENTER)

        panel = self.panel()
        if panel:
            if event.key in (pygame.K_DOWN, pygame.K_PAGEDOWN):
                panel["scroll"] += 24 if event.key == pygame.K_DOWN else 96
                return
            if event.key in (pygame.K_UP, pygame.K_PAGEUP):
                panel["scroll"] -= 24 if event.key == pygame.K_UP else 96
                return
            # Any other key puts the keyboard back; typing carries on as normal.
            self.close_panel()
            if event.key == pygame.K_ESCAPE:
                return

        if self.hint_picker and self.scene == "game":
            if char and char in "1234":
                if not self.game.boards[int(char) - 1].solved:
                    self.pick_hint(now, int(char) - 1)
                return  # a solved board's number does nothing
            if enter:
                self.pick_hint(now)
                return
            self.hint_picker = False  # any other key closes it; Esc does nothing else
            if event.key == pygame.K_ESCAPE:
                return

        if self.scene == "menu":
            if char in ("w", "q"):
                self.play_from_menu(char)
            elif char in ("d", "p"):
                self.set_menu_kind("daily" if char == "d" else "practice")
            elif char == "s":
                self.open_stats()
            elif char == "a":
                self.open_archive()
            elif char == "f" and self.sync.configured:
                self.open_friends()
            return

        if self.scene in ("sync", "friends", "make"):
            if self.scene == "make" and event.key == pygame.K_ESCAPE:
                self.go_to_menu()
                return
            if self.entry is not None:
                if event.key == pygame.K_ESCAPE:
                    self.entry = None
                elif event.key == pygame.K_BACKSPACE:
                    self.entry_key("back", now)
                elif enter:
                    self.entry_key("enter", now)
                elif event.key == pygame.K_SPACE:
                    self.entry_key("space", now)
                elif char:
                    typed = getattr(event, "unicode", "")
                    self.entry_key(typed if len(typed) == 1 and typed.isalnum() else char, now)
            elif self.scene == "friends" and char in ("w", "q"):
                self.friends_screen["mode"] = char
            elif self.scene == "friends" and event.key in (pygame.K_DOWN, pygame.K_UP):
                self.scroller()["scroll"] += 44 if event.key == pygame.K_DOWN else -44
            elif self.scene == "friends" and self.friend_view and (char == "m" or event.key == pygame.K_ESCAPE):
                self.friend_view = None  # (back to the Friends list)
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if self.scene == "settings":
            if char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if self.scene in ("stats", "archive"):
            archive = self.scene == "archive"
            if char in ("w", "q"):
                if archive:
                    self.open_archive(char)
                else:
                    self.stats_mode = char
            elif not archive and char in ("d", "p"):
                self.stats_kind = "daily" if char == "d" else "practice"
            elif char == "a" and not archive:
                self.open_archive()
            elif char == "s" and archive:
                self.open_stats()
            elif archive and event.key in (pygame.K_DOWN, pygame.K_UP, pygame.K_PAGEDOWN, pygame.K_PAGEUP):
                step = {pygame.K_DOWN: 52, pygame.K_UP: -52, pygame.K_PAGEDOWN: 260, pygame.K_PAGEUP: -260}
                self.archive["scroll"] += step[event.key]
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if self.result_at is not None:
            if char == "s":
                self.share(False, now)
            elif self.daily is not None:
                if enter:
                    self.open_stats(self.mode, "daily")
                elif char == "a":
                    self.open_archive(self.mode)
                elif char == "m" or event.key == pygame.K_ESCAPE:
                    self.go_to_menu()
            elif enter or char == "n":
                self.new_game()
            elif char == "r":
                self.start(self.mode, self.words, replay=True)
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if enter:
            self.submit(now)
        elif event.key == pygame.K_BACKSPACE:
            self.backspace(now)
        elif len(char) == 1 and "a" <= char <= "z":
            self.type_letter(char, now)

    def run(self):
        running = True
        while running:
            running = self.frame()
            self.clock.tick(FPS)
        pygame.quit()

    def safe_frame(self):
        """One frame, where a bug can't stop the game. In a browser an error escaping frame() ends the
        loop: the page keeps showing the last frame and ignores every tap until it's reloaded (seen on
        Alex's phone, Nov 2026). Instead the error goes to the server's log (sync.note) and the game
        carries on; one that keeps happening every frame sends the game back to the menu. web/main.py's
        loop calls this (test_web checks it)."""
        try:
            running = self.frame()
            self.frame_errors = 0
            return running
        except Exception as error:
            import sync as sync_module
            if sync_module.STRICT:
                raise
            self.frame_errors = getattr(self, "frame_errors", 0) + 1
            text = "frame error: " + frame_error_text(error)
            noted = getattr(self, "frame_errors_noted", set())
            self.frame_errors_noted = noted
            if text not in noted and len(noted) < 20:  # (each kind once: the log keeps only 40 lines)
                noted.add(text)
                try:
                    self.sync.note(pygame.time.get_ticks(), text, important=True)
                    self.history.save()  # (so the note survives a reload: sync.py "log_waiting")
                except Exception:
                    pass
            if self.frame_errors >= 3:  # (the same screen fails every time: leave it)
                self.frame_errors = 0
                try:
                    self.reveal = None
                    self.go_to_menu()
                except Exception:
                    pass
            return True

    def apply_web_canvas(self):
        if hasattr(self, "dbg"):
            self.dbg["rebuilds"] += 1
        points, self.web_scale, self.web_insets = web_canvas_size(self.web_view)
        self.web_points = points
        pygame.display.set_mode((round(points[0] * self.web_scale), round(points[1] * self.web_scale)))
        self.fit_web_canvas(self.web_view)

    def fit_web_canvas(self, view):
        """Size and center the canvas on the page ourselves, keeping its shape. pygbag's page does
        this too, but 100 ms after a resize, from whatever size the canvas has then: in Safari on a
        Mac (Nov 2026) that could be before the canvas took its new size, so the old shape stuck and
        the game showed stretched sideways (wide, blurry letters) until the window was resized."""
        size = web_canvas_css(view, self.web_points)
        if size is None:
            return
        try:
            import platform  # pygbag's bridge to the browser's JavaScript
            style = platform.window.canvas.style
            width, height = "%dpx" % size[0], "%dpx" % size[1]
            if str(style.width) != width or str(style.height) != height:
                style.width, style.height = width, height
                style.position, style.margin = "absolute", "auto"
                style.left = style.right = style.top = style.bottom = "0"
        except Exception:
            pass  # (no page: tests, or the canvas isn't there yet)

    def check_web_resize(self, now):
        """Rebuild the canvas when the browser window changes size (or moves to a screen with a
        different pixel ratio), once it has stayed put for a moment, so it stays sharp."""
        self.web_frames += 1
        if self.web_frames % 10:
            return  # asking the browser every frame is wasteful
        view = browser_view()
        self.fit_web_canvas(view)  # (undoes a stretched fit from the page, see fit_web_canvas)
        if view is None or view == self.web_view:
            self.web_resize = None
            return
        if self.web_resize is None or self.web_resize[0] != view:
            self.web_resize = (view, now)
        elif now - self.web_resize[1] >= 250:
            self.web_view, self.web_resize = view, None
            self.apply_web_canvas()
            try:
                import platform
                platform.window.window_resize()  # the page re-fits the canvas to the window
            except Exception:
                pass

    def frame(self):
        now = pygame.time.get_ticks()
        if self.debug:
            self.debug_frame(now)
        if WEB:
            self.check_web_resize(now)
            if BrowserStorage.inactive():
                # Opened in a newer tab: that one is the game now (the page covers this one with "Use it
                # here", which reloads). Nothing here may play, sync or save.
                pygame.event.get()
                return True
            self.watch(now)
        running = True
        self.laps = [("start", time.perf_counter())]
        for event in pygame.event.get():
            if not self.handle_event(event, now):
                running = False
        self.lap("taps and keys")
        self.run_timers(now)
        self.poll_hint(now)
        if WEB:
            self.poll_woke(now)
            self.publish_push()
            self.poll_push(now)
        self.lap("timers and push")
        self.tick_sync(now)
        self.lap("sync")
        if WEB:
            self.route_step(now)
            self.reload_for_release(now)
        self.step_scroll(now)
        drawing = time.perf_counter()
        self.lap("address", drawing)
        self.draw(now)
        if self.debug:
            self.draw_debug(now)
        showing = time.perf_counter()
        self.lap("drawing", showing)
        self.present()
        self.lap("showing")
        if WEB:
            self.measure_flip(now, (showing - drawing) * 1000, (time.perf_counter() - showing) * 1000)
            self.publish_share_targets()
            self.publish_say_targets()
            self.publish_nav_targets()
            self.poll_share(now)
            self.publish_auth_form()
            self.poll_auth_form(now)
        return running

    def lap(self, name, at=None):
        """One step of this frame done (for note_slow_frame)."""
        self.laps.append((name, time.perf_counter() if at is None else at))

    def note_slow_frame(self, before, inside, ticking):
        """The freeze hunt (Nov 2026): Alex's phone stopped the whole game a few seconds after it
        started, every timer on the page too, until the app was hidden and shown again, and nothing in
        the log said where. web/main.py times each frame in three parts: the browser's own time before
        it ran this frame (`before`), the frame itself (`inside`, with the slowest step from lap()) and
        clock.tick's wait (`ticking`). A long one goes to the server's log at once, so the next freeze
        shows whether the game's own code, the frame timer or the browser held it up. The page's
        watchdog (web/template.tmpl) notes the same stop from the page's side, with when it was hidden
        and the taps made meanwhile."""
        if not WEB or self.slow_noted >= 10:
            return
        try:
            texts = []
            if inside > 2:
                steps = [(b[1] - a[1], b[0]) for a, b in zip(self.laps, self.laps[1:])]
                slowest = max(steps) if steps else (0, "?")
                texts.append("a game frame took %.1f s (slowest step: %s, %.1f s; on %s)" % (
                    inside, slowest[1], slowest[0], self.scene))
            if ticking > 1:
                texts.append("the frame timer (clock.tick) waited %.1f s" % ticking)
            if BrowserStorage.slowest is not None:
                took, size = BrowserStorage.slowest
                BrowserStorage.slowest = None
                texts.append("saving the games to the browser took %.1f s (%d characters)" % (took, size))
            if before > 3 and self.stayed_on_screen(before):
                texts.append("the browser ran no game frame for %.1f s while the page stayed on screen" % before)
            if not texts:
                return
            tap = self.last_tap_name
            if tap is not None:
                texts.append("last tap: %s on %s, %.1f s before" % (tap[0], tap[1], time.perf_counter() - tap[2]))
            self.slow_noted += 1
            self.note_long(pygame.time.get_ticks(), "; ".join(texts))
            self.history.save()  # (so it survives a reload: sync.py "log_waiting")
        except Exception:
            pass

    def stayed_on_screen(self, seconds):
        """The page is on screen and wasn't hidden or shown in the last `seconds` (the page's
        wordleShownAt), so a gap that long between frames wasn't the usual stop in the background."""
        try:
            import platform
            window = platform.window
            since = (float(window.performance.now()) - float(window.wordleShownAt or 0)) / 1000
            return since > seconds and str(window.document.visibilityState) == "visible"
        except Exception:
            return False

    def measure_flip(self, now, draw_ms, show_ms):
        """Once per launch, how smoothly the first flip ran, for the server's log: frames per second,
        the slowest frame, and how long each frame took to draw and to put on the screen, with the
        canvas size (flips can only be judged on the phone itself; Nov 2026)."""
        if self.flip_noted:
            return
        stats = self.flip_stats
        if self.reveal is not None:
            if stats is None:
                stats = self.flip_stats = {"start": now, "prev": now, "frames": 0, "slowest": 0,
                                           "draw": 0.0, "show": 0.0}
            stats["slowest"] = max(stats["slowest"], now - stats["prev"])
            stats["prev"] = now
            stats["frames"] += 1
            stats["draw"] += draw_ms
            stats["show"] += show_ms
        elif stats is not None:
            self.flip_noted = True
            frames = max(1, stats["frames"])
            seconds = max(0.001, (stats["prev"] - stats["start"]) / 1000)
            w, h = self.full_screen.get_size()
            self.sync.note(now, "first flip: %d fps (%d frames in %.1f s), slowest frame %d ms, drawing %.0f ms + "
                           "showing %.0f ms a frame, canvas %dx%d" % (
                               round((frames - 1) / seconds), frames, seconds, stats["slowest"],
                               stats["draw"] / frames, stats["show"] / frames, w, h), important=True)

    def tick_sync(self, now):
        """Send and take in synced games (never waits: see sync.py)."""
        on_screen = self.scene == "game" and self.game and not self.game.over
        self.sync.keep = (self.mode, self.daily) if on_screen else None  # (daily None = a practice game)
        self.sync.keep_custom = custom_words.key(self.custom) if on_screen and self.custom else None
        view = (self.scene, self.mode if self.scene == "game" else None, self.daily if self.scene == "game" else None)
        if view != self.last_view:
            # Moved to another screen (or game): get the latest from the server straight away.
            self.last_view = view
            self.sync.fresh(now)
            if self.scene in ("menu", "friends") and self.sync.signed_in:
                self.sync.refresh_friends(now, max_age=15 * 1000)
        if self.pending and now >= self.pending["at"]:
            self.finish_pending(now)
        import sync as sync_module
        try:
            if self.scene == "friends":
                self.sync.refresh_friends(now)  # (at most once a minute)
            elif self.scene == "menu" and self.sync.signed_in:
                self.sync.refresh_friends(now, max_age=5 * 60 * 1000)  # (for the Friends button's count)
            if self.sync.tick(now):
                self.follow_wanted = True  # (checked once the tiles stop flipping)
        except Exception as error:
            # A bug in syncing must never stop the game: note it (?debug=1 shows it, and it goes to the
            # server's log) and try again soon. The request on its way is left alone: its answer still counts.
            self.sync.note(now, "sync error: " + sync_module.describe(error))
            if sync_module.STRICT:
                raise
            self.sync.next_at = now + 5 * 1000
        try:
            kicked, self.sync.kicked = self.sync.kicked, None
            if kicked:
                self.signed_out_elsewhere(kicked)
            if self.follow_wanted and not self.reveal:
                self.follow_wanted = False
                self.follow_other_device(now)
        except Exception as error:
            self.sync.note(now, "game error: " + sync_module.describe(error))
            if sync_module.STRICT:
                raise

    def follow_other_device(self, now):
        """Another device played further in the game on screen, or finished it: show that, so the board
        here never lets you play on from an old position."""
        if self.scene != "game" or not self.game or self.game.over or not self.record or self.replay:
            return
        mine = self.record
        if self.daily is not None:
            saved, _finished = self.history.daily_game(self.mode, self.daily)
        elif self.custom:
            saved, _finished = self.history.custom_game(self.custom)  # (this link, played on another device)
        else:
            saved = next((g for g in reversed(self.history.games) if g["id"] == mine["id"]), None)
            if saved is None:
                saved = self.history.practice_game(self.mode)
                if saved is not None and saved.get("id") != mine.get("id"):
                    saved = None  # (a different practice game: leave this one alone)
        if saved is None or saved is mine:
            return
        split = split_from(saved, mine)  # (each played a different guess: the server's came first)
        if "finished" not in saved and not split and len(saved.get("guesses") or []) <= len(mine["guesses"]):
            return
        self.start(self.mode, number=self.daily, record=saved)
        if "finished" in saved:
            self.toast("Finished on another device", now, 2600)
        elif split:
            self.toast("Your other device's guess got there first", now, 3200)
        else:
            self.toast("Carried on from another device", now, 2600)

    # ----- sharing -------------------------------------------------------

    def share_link(self):
        """The link in a shared result: the site, or for a custom Wordle its own link (so others can play it)."""
        return custom_words.link(self.link, self.custom) if self.custom else self.link

    def share_message(self, spoilers):
        record, link = self.record, self.share_link()
        squares = self.costume()
        key = ("share", record["id"], len(record["guesses"]), record.get("hints", 0), spoilers, link,
               tuple(sorted(squares.items())) if squares else None)
        return self.turkey_squares(self.memo(key, lambda: share_text(
            record, self.game.max_guesses, spoilers, link, self.answers_left() if spoilers else None, squares=squares)))

    def answers_left(self):
        """For Share spoilers: the answers still possible after each guess, per board, like the counts
        next to each row (None for a board solved by an earlier guess; Alex, Nov 2026)."""
        guesses = self.game.guesses
        if list(guesses) != list(self.record["guesses"]):
            return None
        return [[len(self.game.possible_after(b, i + 1)) if i < len(board.history()) else None
                 for b, board in enumerate(self.game.boards)] for i in range(len(guesses))]

    def share(self, spoilers, now, clicked=False):
        """Copy the result (computer), or hand it to the page to share (browser)."""
        text = self.share_message(spoilers)
        if WEB:
            if clicked:
                return  # the page shares on the click itself (see publish_share_targets)
            try:
                import platform
                platform.window.wordleShareText(text)  # the S key
            except Exception:
                self.toast("Couldn't share from here", now)
            return
        try:
            pygame.scrap.put_text(text)
        except Exception:
            self.toast("Couldn't copy to the clipboard", now)
            return
        self.toast(self.copied_message(), now)

    def counts_message(self):
        record, link = self.record, self.share_link()
        squares = self.costume()
        key = ("counts", record["id"], len(record["guesses"]), link, tuple(sorted(squares.items())) if squares else None)
        return self.turkey_squares(self.memo(key, lambda: counts_text(record, self.game.max_guesses, link, squares)))

    def share_counts(self, now, clicked=False):
        """The result as tile counts: copied (computer), or the page shares it on the tap (browser)."""
        if WEB:
            return  # (the page shares on the click itself: publish_share_targets)
        try:
            pygame.scrap.put_text(self.counts_message())
        except Exception:
            self.toast("Couldn't copy to the clipboard", now)
            return
        self.toast(self.copied_message(), now)

    def publish_share_targets(self):
        """Tell the page where the Share buttons are, in canvas pixels, with their text.

        Browsers only open the share sheet (or write to the clipboard) during the tap or click
        itself, and Python sees a tap a frame later, so web/template.tmpl's click handler does the
        sharing when a click lands on one of these."""
        targets = [[round(rect.x * self.scale), round((rect.y + self.offset_y) * self.scale),
                    round(rect.w * self.scale), round(rect.h * self.scale), text] for rect, text in self.share_targets]
        data = json.dumps(targets)
        if data != self.published_share:
            try:
                import platform
                platform.window.wordleShareTargets = data
                if not targets:
                    platform.window.wordleShareStatus = ""  # a late "copied" mustn't pop up on the next result
                self.published_share = data
            except Exception:
                pass

    def publish_say_targets(self):
        """Tell the page where the spots that say a word are ("?" buttons, the open definition's word),
        in canvas pixels, with their words: like Share, iPhone Safari only speaks from inside the tap,
        so web/template.tmpl's handler says the word (wordleSay) when a tap lands on one."""
        targets = [[round(rect.x * self.scale), round((rect.y + self.offset_y) * self.scale),
                    round(rect.w * self.scale), round(rect.h * self.scale), word] for rect, word in self.say_targets]
        data = json.dumps(targets)
        if data != self.published_say:
            try:
                import platform
                platform.window.wordleSayTargets = data
                self.published_say = data
            except Exception:
                pass

    def poll_woke(self, now):
        """The page sets wordleWoke when the tab or home-screen app comes back into view or the
        phone gets back online (web/template.tmpl): sync at once."""
        try:
            import platform
            woke = bool(platform.window.wordleWoke)
            if woke:
                platform.window.wordleWoke = False
        except Exception:
            return
        if woke:
            self.woke_at = now
            self.sync.woke(now)

    def reload_for_release(self, now):
        """A newer release is out (the page checks version.json: web/template.tmpl wordleNewRelease):
        reload to it at a quiet moment, so a tab left open never runs an old version for long. Only on
        the menu with nothing open, typed or on its way to the server, and either just back in view or
        after RELEASE_IDLE_MS without a tap (a reload takes a second; the player shouldn't be mid-tap)."""
        if self.release_checked is not None and now - self.release_checked < 1000:
            return
        self.release_checked = now
        quiet = (self.scene == "menu" and not self.dialog and not self.pending and not self.entry
                 and not self.sync.auth_form and not self.sync.busy and not self.sync.wanted
                 and not self.sync.signing_out() and not self.thinking)
        just_back = self.woke_at is not None and now - self.woke_at < 3000
        if not quiet or not (just_back or now - self.last_input >= RELEASE_IDLE_MS):
            return
        try:
            import platform
            version = str(platform.window.wordleNewRelease() or "")
            if version:
                platform.window.wordleReloadFor(version)
        except Exception:
            pass

    def publish_push(self):
        """Push updates: tell the page which channel to listen on (sync.push_channel), or to stop."""
        channel = self.sync.push_channel()
        spec = json.dumps({"url": channel[0], "key": channel[1], "topic": channel[2]}) if channel else ""
        if spec == self.published_push:
            return
        try:
            import platform
            platform.window.wordlePush(spec)
            self.published_push = spec
        except Exception:
            pass

    def poll_push(self, now):
        """Nudges the page heard (web/template.tmpl wordleNudgeTake): sync now."""
        if not self.published_push:
            return
        try:
            import platform
            text = str(platform.window.wordleNudgeTake() or "")
            nudges = json.loads(text) if text else []
        except Exception:
            return
        for nudge in nudges if isinstance(nudges, list) else []:
            if isinstance(nudge, dict):
                self.sync.nudged(now, str(nudge.get("event", "")), str(nudge.get("from", "")))

    def copied_message(self):
        if self.scene == "friends":
            return "Invite link copied. Paste it in a text to your friend"
        return "Result copied. Paste it in a text to share it"

    def poll_share(self, now):
        """Show how the page's share went ("copied" etc.)."""
        if not self.share_targets:
            return
        try:
            import platform
            status = str(platform.window.wordleShareStatus or "")
            if status:
                platform.window.wordleShareStatus = ""
        except Exception:
            return
        if status == "copied":
            self.toast(self.copied_message(), now)
        elif status == "failed":
            self.toast("Couldn't share from this browser", now)

    def debug_frame(self, now):
        """?debug=1: count frames per second and remember slow frames (a frozen game shows up here)."""
        d = self.dbg
        if d.get("prev") is not None:
            d["slow"] = [(at, ms) for at, ms in d["slow"] if now - at < 10000]
            if now - d["prev"] > 100:
                d["slow"].append((now, now - d["prev"]))
        d["prev"] = now
        d["frames"] += 1
        if now - d["second"] >= 1000:
            d["fps"], d["frames"], d["second"] = d["frames"], 0, now

    def draw_debug(self, now):
        d = self.dbg
        try:
            import platform
            page_touches = int(platform.window.wordleTouchCount or 0)
        except Exception:
            page_touches = -1
        slowest = max((ms for _at, ms in d["slow"]), default=0)
        view = self.web_view if WEB else None
        lines = ["up %.1fs  fps %d  slowest frame %d ms (last 10 s)" % (now / 1000, d["fps"], slowest),
                 "page touches %d  game taps %d  mouse %d (dropped %d)  clicks %d (hit %d)"
                 % (page_touches, d["fingers"], d["mouse"], d["dropped"], d["clicks"], d["hits"]),
                 "canvas rebuilds %d  view %s  scene %s  sync %s" % (
                     d["rebuilds"], "x".join(str(round(v, 1)) for v in view[:3]) if view else "-", self.scene,
                     "busy" if self.sync.busy else "idle")]
        s = self.sync
        lines.append("signed in %s  joining %s  hold %ds  next %ds  queue %s  busy %s" % (
            "yes" if s.signed_in else "no", "yes" if s.state().get("attach_pending") else "no",
            max(0, (s.hold_until - now) // 1000), max(0, ((s.next_at or now) - now) // 1000),
            ",".join(w["kind"] for w in s.wanted) or "-",
            "%s %ds" % (s.busy["kind"], (now - s.busy.get("at", now)) // 1000) if s.busy else "-"))
        for at, text in list(s.trace)[-7:]:
            lines.append("%5.1fs ago  %s" % ((now - at) / 1000, text[:90]))
        w, h = self.size
        box = pygame.Rect(4, h - 4 - 16 * len(lines) - 6, w - 8, 16 * len(lines) + 6)
        self.rrect((0, 0, 0), box, 6)
        for i, line in enumerate(lines):
            self.text(line, 11, (255, 255, 0), bold=False, topleft=(box.x + 6, box.y + 3 + 16 * i))

    def present(self):
        if self.window is not None:
            self.window.flip()
        else:
            pygame.display.flip()

    # ----- drawing helpers -----------------------------------------------
    # Callers work in points; these helpers convert to real pixels with self.scale.

    def begin_frame(self):
        """Grab the window surface (it changes on resize) and work out pixels per point."""
        if self.window is not None:
            self.screen = self.window.get_surface()
            points_w = self.window.size[0]
        else:
            self.screen = pygame.display.get_surface()
            points_w = self.screen.get_width() / (self.web_scale if WEB else 1)
        self.scale = self.screen.get_width() / points_w if points_w else 1.0
        self.full_screen = self.screen
        self.offset_y = 0
        if WEB and any(self.web_insets):
            # Draw everything inside the iPhone safe area: a sub-surface below the notch and above
            # the home indicator. Layout code never knows; clicks are shifted to match.
            top = round(self.web_insets[0] * self.scale)
            bottom = round(self.web_insets[1] * self.scale)
            w, h = self.screen.get_size()
            self.screen = self.screen.subsurface((0, top, w, max(1, h - top - bottom)))
            self.offset_y = top / self.scale
        pixels_w, pixels_h = self.screen.get_size()
        self.size =(round(pixels_w / self.scale), round(pixels_h / self.scale))

    def mouse(self):
        """Mouse position in points (in the browser, pygame reports canvas pixels), used for hover
        effects. Touch screens have no hover: the browser parks the "mouse" where the last tap was,
        which would leave something lit up, so report it as nowhere (taps use event positions)."""
        if self.touch:
            return (-10000, -10000)
        x, y = pygame.mouse.get_pos()
        return (x / self.scale, y / self.scale - self.offset_y) if WEB else (x, y)

    def px(self, value):
        return int(round(value * self.scale))

    def px_rect(self, rect):
        """A rect in points -> the same rect in pixels (edges rounded, so neighbors don't gap)."""
        x, y, w, h = rect
        s = self.scale
        left, top = round(x * s), round(y * s)
        return pygame.Rect(left, top, max(1, round((x + w) * s) - left), max(1, round((y + h) * s) - top))

    def rrect(self, color, rect, radius, width=0, **corners):
        corners = {k: self.px(v) for k, v in corners.items()}
        pygame.draw.rect(self.screen, color, self.px_rect(rect), max(1, self.px(width)) if width else 0,
                         border_radius=self.px(radius), **corners)

    def text(self, text, size, color, center=None, bold=True, **anchor):
        surface = self.fonts.render(text, size * self.scale, color, bold)
        if center:
            rect = surface.get_rect(center=(self.px(center[0]), self.px(center[1])))
        else:
            (name, value), = anchor.items()
            value = tuple(self.px(v) for v in value) if isinstance(value, tuple) else self.px(value)
            rect = surface.get_rect(**{name: value})
        self.screen.blit(surface, rect)
        # Where it landed, back in points.
        return pygame.Rect(rect.x / self.scale, rect.y / self.scale, rect.w / self.scale, rect.h / self.scale)

    def button(self, rect, label, action, size=17, primary=False, enabled=True, note=None, name=None):
        """note: a small second line under the label (like the Friends button's "2 played today"). name: the
        click target's name when it isn't "button:" + the label."""
        rect = pygame.Rect(rect)
        hovered = enabled and rect.collidepoint(self.mouse())
        color = ACCENT if primary else BUTTON
        if not enabled:
            color = PANEL
        elif hovered:
            color = lighten(color, 0.12)
        self.rrect(color, rect, 10)
        if note:
            self.text(label, size, TEXT if enabled else MUTED, center=(rect.centerx, rect.centery - 7))
            self.text(note, 11, SOLVED_TEXT, bold=False, center=(rect.centerx, rect.centery + 10))
        else:
            self.text(label, size, TEXT if enabled else MUTED, center=rect.center)
        if enabled:
            self.clickables.append((rect, action, name or "button:" + label))
        return rect

    def draw_dashed_tile(self, cell):
        """An optional letter's box (Make a Wordle): a dashed outline."""
        s = self.scale
        rect = pygame.Rect(round(cell.x * s), round(cell.y * s), round(cell.w * s), round(cell.h * s))
        border = self.px(max(2, cell.w // 24))
        dash, inset = self.px(max(4, cell.w // 7)), self.px(max(3, cell.w // 7))
        for horizontal, fixed in ((True, rect.top), (True, rect.bottom - border), (False, rect.left),
                                  (False, rect.right - border)):
            start, end = (rect.left, rect.right) if horizontal else (rect.top, rect.bottom)
            length = end - start - 2 * inset
            count = max(1, round(length / (2 * dash)))
            step = length / count
            for k in range(count):
                a = start + inset + k * step + (step - dash) / 2
                piece = (round(a), fixed, dash, border) if horizontal else (fixed, round(a), border, dash)
                pygame.draw.rect(self.screen, EMPTY_BORDER, piece)

    def draw_tile_cursor(self, cell, now):
        """The box the next letter goes in (Make a Wordle): a blue tinted box with a thick outline and a
        blinking cursor, unlike the grey filled and empty boxes around it."""
        s = self.scale
        rect = pygame.Rect(round(cell.x * s), round(cell.y * s), round(cell.w * s), round(cell.h * s))
        radius = self.px(max(3, cell.w // 7))
        pygame.draw.rect(self.screen, CURSOR_FILL, rect, border_radius=radius)
        pygame.draw.rect(self.screen, CURSOR_BORDER, rect, self.px(max(3, cell.w // 16)), border_radius=radius)
        if (now // 530) % 2 == 0:
            bar = pygame.Rect(0, 0, self.px(max(2, cell.w // 22)), round(cell.h * s * 0.5))
            bar.center = rect.center
            pygame.draw.rect(self.screen, CURSOR_BORDER, bar)

    def costume(self):
        """The signed-in account's tile costume (emoji per colour, costume.py), or None."""
        sync = getattr(self, "sync", None)
        if not sync or not sync.signed_in:
            return None
        if getattr(self, "turkey_preview", None) is not None and self.festive():
            return None  # Thanksgiving: everyone gets the turkey (Alex); the costume is back the next day
        return costume.costume_for(sync.auth().get("user"))

    def costume_picture(self, emoji, size):
        """The emoji's picture at `size` pixels (cached), or None if it can't be loaded."""
        cache = self.__dict__.setdefault("costume_pictures", {})
        key = (emoji, size)
        if key not in cache:
            if len(cache) > 40:
                cache.clear()
            try:
                original = cache.get(emoji) or pygame.image.load(
                    resource_path(os.path.join("Media", costume.picture_name(emoji)))).convert_alpha()
                cache[emoji] = original
                cache[key] = pygame.transform.smoothscale(original, (size, size))
            except Exception:
                cache[key] = None
        return cache[key]

    def draw_tile(self, cell, letter, state, scale=1.0, scale_y=1.0):
        """state: "empty", "typed", or a score color ("green", "yellow", "black")."""
        # Work straight in pixels here so flips and pops animate smoothly at Retina resolution.
        s = self.scale
        rect = pygame.Rect(0, 0, max(1, int(cell.w * s * scale)), max(1, int(cell.h * s * scale * scale_y)))
        rect.center = (round(cell.centerx * s), round(cell.centery * s))
        radius = self.px(max(3, cell.w // 7))
        border = self.px(max(2, cell.w // 24))
        if state == "empty":
            pygame.draw.rect(self.screen, EMPTY_BORDER, rect, border, border_radius=radius)
        elif state == "typed":
            pygame.draw.rect(self.screen, PANEL, rect, border_radius=radius)
            pygame.draw.rect(self.screen, TYPED_BORDER, rect, border, border_radius=radius)
        else:
            pygame.draw.rect(self.screen, TILE_COLORS[state], rect, border_radius=radius)
        dressed = self.costume() if state in TILE_COLORS and scale_y > 0.12 else None
        dressed = dressed if dressed and state in dressed else None
        if letter and scale_y > 0.12:
            surface = self.fonts.render(letter.upper(), cell.h * (0.5 if dressed else 0.56) * s, TEXT)
            if scale_y < 1:
                size = (surface.get_width(), max(1, int(surface.get_height() * scale_y)))
                surface = pygame.transform.smoothscale(surface, size)
            center = rect.center
            if dressed:  # (moved down-left a little, out of the emoji's way)
                center = (rect.centerx - int(rect.w * 0.08), rect.centery + int(rect.h * 0.07))
            self.screen.blit(surface, surface.get_rect(center=center))
        if dressed:
            # The costume: the colour's emoji in the tile's top-right corner (letter and colour stay).
            size = max(1, int(rect.w * 0.38))
            picture = self.costume_picture(dressed[state], size)
            if picture:
                if scale_y < 1:
                    picture = pygame.transform.smoothscale(picture, (size, max(1, int(size * scale_y))))
                pad = max(1, int(rect.w * 0.04))
                self.screen.blit(picture, picture.get_rect(topright=(rect.right - pad, rect.top + int(pad * scale_y))))

    # ----- menu ----------------------------------------------------------

    def draw(self, now):
        self.clickables = []
        self.share_targets = []
        self.say_targets = []
        self.scroll_area = None  # set by whatever scrollable list is drawn this frame
        self.begin_frame()
        self.full_screen.fill(BG)
        if self.scene == "menu":
            self.draw_menu(now)
        elif self.scene == "stats":
            self.draw_stats(now)
        elif self.scene == "archive":
            self.draw_archive(now)
        elif self.scene == "sync":
            self.draw_sync(now)
        elif self.scene == "friends":
            self.draw_friends(now)
        elif self.scene == "settings":
            self.draw_settings(now)
        elif self.scene == "make":
            self.draw_make(now)
        else:
            self.draw_game(now)
        if self.scene != "game":
            self.draw_pending(now)
        if self.sync.auth_form and not WEB:
            self.draw_auth_form(now)
        if self.dialog:
            self.draw_dialog(now)
        self.draw_toasts(now)

    def segmented(self, rect, options, selected, choose, name):
        """A row of options with one selected (like Daily | Practice). Targets are "name:value"."""
        rect = pygame.Rect(rect)
        self.rrect(PANEL, rect, 12)
        width = rect.w / len(options)
        for i, (value, label) in enumerate(options):
            seg = pygame.Rect(round(rect.x + i * width) + 4, rect.y + 4, round(width) - 8, rect.h - 8)
            on = value == selected
            if on:
                self.rrect(BUTTON, seg, 9)
            elif seg.collidepoint(self.mouse()):
                self.rrect(lighten(PANEL, 0.08), seg, 9)
            self.text(label, 16, TEXT if on else MUTED, center=seg.center)
            self.clickables.append((seg, lambda now, value=value: choose(value), "%s:%s" % (name, value)))

    def daily_status(self, mode, number):
        """How a daily puzzle stands, as (text, color): "Solved in 4/6", "In progress, 2/6"..."""
        game, finished = self.history.daily_game(mode, number)
        limit = WORDLE_GUESSES if mode == "w" else QUORDLE_GUESSES
        helped = "".join(note for used, note in ((game and game.get("hints"), " · hint"),
                                                 (game and game.get("lists"), " · word list")) if used)
        if finished:
            if game.get("won"):
                return "Solved in %d/%d%s" % (len(game["guesses"]), limit, helped), SOLVED_TEXT
            text = "Lost"
            answers = game.get("answers") or []
            if len(answers) > 1:  # Quordle: how many boards it got
                guessed = {guess.lower() for guess in game.get("guesses") or []}
                text += ", %d of %d solved" % (sum(1 for word in answers if word.lower() in guessed), len(answers))
            return text + helped, LOST_TEXT
        if game and game["guesses"]:
            return "In progress, %d/%d%s" % (len(game["guesses"]), limit, helped), TEXT
        return "Not played yet", MUTED

    # ----- Thanksgiving (thanksgiving.py) ---------------------------------

    def festive(self):
        """Thanksgiving where the player is (or UAT's ?turkey=1 preview): the turkey and the leaves."""
        return self.turkey_preview or thanksgiving.is_thanksgiving(self.today())

    def turkey_squares(self, text):
        """A daily from Thanksgiving (or any daily with UAT's ?turkey=1) shares 🦃 for 🟩."""
        if self.daily is not None and (self.turkey_preview
                                       or thanksgiving.is_thanksgiving(daily.puzzle_date(self.daily))):
            return thanksgiving.turkey_squares(text)
        return text

    def tap_turkey(self, now):
        """The turkey hops and gobbles. Its target is registered before every button (clickables.insert(0)),
        and a tap goes to the last target under it, so a button on top of it always wins."""
        self.turkey_tap = now
        if self.scene == "game":
            self.toast("Gobble gobble!", now, 1500)  # (no bubble here: it would cover the board)

    def since_turkey_tap(self, now):
        return None if self.turkey_tap is None else now - self.turkey_tap

    def draw_leaves(self, now):
        w, h = self.size
        thanksgiving.draw_leaves(self.screen, self.scale, now, w, h, BG)

    def turkey_bubble(self, text, x, y):
        """What the turkey says, in a small bubble above its head (kept on screen)."""
        w = self.size[0]
        width = self.fonts.get(12 * self.scale, True).size(text)[0] / self.scale + 16
        box = pygame.Rect(0, 0, round(width), 24)
        box.midbottom = (round(x), round(y) - 6)
        box.x = max(6, min(box.x, w - 6 - box.w))
        self.rrect(PANEL, box, 10)
        tip_x = max(box.x + 10, min(round(x), box.right - 10))
        pygame.draw.polygon(self.screen, PANEL, [(self.px(tip_x - 5), self.px(box.bottom - 1)),
                                                 (self.px(tip_x + 5), self.px(box.bottom - 1)),
                                                 (self.px(tip_x), self.px(box.bottom + 6))])
        self.text(text, 12, TEXT, center=box.center)

    def draw_menu(self, now):
        w, h = self.size
        if self.festive():
            # Behind everything on the menu, and never a click target, so it can't cover or take a button.
            self.draw_leaves(now)
            turkey = thanksgiving.draw_turkey(self.screen, self.scale, now, 8, w - 8, h - 6, 1.25, BG,
                                              bubble=self.turkey_bubble, since_tap=self.since_turkey_tap(now))
            self.clickables.insert(0, (turkey, self.tap_turkey, "turkey:tap"))
        title = "WORDLE"
        colors = ["green", "black", "yellow", "black", "green", "yellow"]
        tile, gap = 62, 8
        card_w, card_h = min(420, w - 64), 96
        nudge = self.sync.configured and not self.sync.signed_in  # (a card suggesting an account)
        content_h = (tile + 62 + 40 + 18 + 2 * (card_h + 16) + 44 + (40 if not self.touch else 0)
                     + (104 if nudge else 0) + 48)
        top = max(24, int((h - content_h) * 0.42))
        total = len(title) * tile + (len(title) - 1) * gap
        for i, (letter, color) in enumerate(zip(title, colors)):
            bob = math.sin(now / 420 + i * 0.7) * 5
            cell = pygame.Rect(w // 2 - total // 2 + i * (tile + gap), top + bob, tile, tile)
            self.draw_tile(cell, letter, color)
        self.text("& QUORDLE", 22, MUTED, center=(w // 2, top + tile + 30))

        kinds = pygame.Rect(w // 2 - 130, top + tile + 62, 260, 40)
        self.segmented(kinds, [("daily", "Daily"), ("practice", "Practice")], self.menu_kind, self.set_menu_kind,
                       "kind")
        number = daily.puzzle_number(self.today())
        y = kinds.bottom + 18
        for key, name, detail in (("w", "Wordle", "One word, six guesses"),
                                  ("q", "Quordle", "Four words at once, nine guesses")):
            rect = pygame.Rect(w // 2 - card_w // 2, y, card_w, card_h)
            hovered = rect.collidepoint(self.mouse())
            self.rrect(lighten(PANEL, 0.08) if hovered else PANEL, rect, 16)
            if hovered:
                self.rrect(ACCENT, rect, 16, 2)
            self.text(name, 28, TEXT, topleft=(rect.x + 26, rect.y + 18))
            color = MUTED
            if self.menu_kind == "daily":
                status, color = self.daily_status(key, number)
                detail = "#%d  \u00b7  %s" % (number, status)
            elif self.history.practice_game(key):
                limit = WORDLE_GUESSES if key == "w" else QUORDLE_GUESSES
                detail = "In progress, %d/%d" % (len(self.history.practice_game(key)["guesses"]), limit)
                color = TEXT
            room = rect.w - 52 - (0 if self.touch else 60)  # (left of the W/Q badge)
            font = self.fonts.get(16 * self.scale, False)
            while " · " in detail and font.size(detail)[0] > room * self.scale:
                detail = detail.rsplit(" · ", 1)[0]  # a narrow card drops "· word list", then "· hint"
            self.text(detail, 16, color, bold=False, topleft=(rect.x + 26, rect.y + 58))
            if not self.touch:  # keyboard shortcut badge; no keyboard on a phone
                badge = pygame.Rect(0, 0, 44, 44)
                badge.midright = (rect.right - 24, rect.centery)
                self.rrect(BUTTON, badge, 10)
                self.text(key.upper(), 20, TEXT, center=badge.center)
            self.clickables.append((rect, lambda now, key=key: self.play_from_menu(key), "menu:" + key))
            y += card_h + 16

        buttons = [("Stats", lambda now: self.open_stats()), ("Archive", lambda now: self.open_archive())]
        if self.sync.configured:
            played = self.friends_played_today() if self.sync.signed_in else 0
            buttons.append(("Friends", lambda now: self.open_friends()))
            buttons.append(("Account", lambda now: self.open_sync()))
        # The Friends button's count: how many friends finished today's puzzle (not how many friends you
        # have). Each button is as wide as its words need plus an equal share of what's left, so the
        # note fits on most phones; the narrowest get the short version.
        row_w = min(420, w - 32)  # (on a phone, a little wider than the cards above it)
        room = row_w - 12 * (len(buttons) - 1)

        def width(text, size, bold):
            return self.fonts.get(size * self.scale, bold).size(text)[0] / self.scale

        def needs(label, note):
            return max(width(label, 16, True), width(note, 11, False) if note else 0) + 14

        notes = {}
        if self.sync.configured and played:
            notes["Friends"] = "%d played today" % played
            if sum(needs(label, notes.get(label)) for label, _a in buttons) > room:
                notes["Friends"] = "%d today" % played
        wants = [needs(label, notes.get(label)) for label, _a in buttons]
        even = room // len(buttons)
        if max(wants) <= even or sum(wants) > room:
            widths = [even] * len(buttons)  # (all the same when that fits)
        else:
            spare = (room - sum(wants)) / len(buttons)
            widths = [int(want + spare) for want in wants]
        x = w // 2 - row_w // 2
        for (label, action), each in zip(buttons, widths):
            self.button((x, y, each, 44), label, action, size=16, note=notes.get(label))
            x += each + 12
        y += 44
        if nudge:
            note = "Keep your stats on all your devices and play with friends"
            lines = len(self.wrap(note, 13, card_w - 36))
            card = pygame.Rect(w // 2 - card_w // 2, y + 16, card_w, 52 + 18 * lines)
            hovered = card.collidepoint(self.mouse())
            self.rrect(lighten(PANEL, 0.08) if hovered else PANEL, card, 14)
            self.rrect(ACCENT, card, 14, 2)
            self.text("Sign in or create an account", 16, TEXT, topleft=(card.x + 18, card.y + 14))
            self.paragraph(note, 13, MUTED, card.inflate(-36, 0), card.y + 38)
            self.clickables.append((card, lambda now: self.sign_in_from_menu(), "button:Sign in from menu"))
            y = card.bottom
        self.button((w // 2 - 156, y + 12, 170, 36), "Make a Wordle", lambda now: self.open_make(), size=15)
        self.button((w // 2 + 26, y + 12, 130, 36), "Settings", lambda now: self.open_settings(), size=15)
        y += 48
        if not self.touch:
            self.text("W or Q: play     D / P: daily or practice     S: stats     A: archive", 13, MUTED,
                      bold=False, center=(w // 2, y + 28))

    def sign_in_from_menu(self):
        """The menu's account card: the Account screen with the sign-in form open."""
        self.open_sync()
        self.sync.open_account_form()

    # ----- stats and archive ---------------------------------------------

    def draw_screen_header(self, title):
        w = self.size[0]
        bw = 84 if w >= 640 else 62
        self.button((16, 14, bw, 36), "Home", lambda now: self.go_to_menu(), size=16)
        shown = self.text(title, 26, TEXT, center=(w // 2, 32))
        if self.release:
            self.draw_release_badge((shown.right + 8, shown.centery), "midleft")
        self.rrect(EMPTY_BORDER, (0, 64, w, 1), 0)

    def draw_stats(self, now):
        w, h = self.size
        self.draw_screen_header("STATS")
        mode = self.stats_mode
        self.segmented((w // 2 - 130, 80, 260, 40), [("w", "Wordle"), ("q", "Quordle")], mode,
                       lambda value: setattr(self, "stats_mode", value), "stats")
        kind = self.stats_kind
        self.segmented((w // 2 - 150, 128, 300, 36), [("daily", "Daily"), ("practice", "Practice"), ("all", "All")],
                       kind, lambda value: setattr(self, "stats_kind", value), "stats-kind")
        today = self.today()
        stats = self.memo(("stats", mode, kind, today), lambda: self.history.stats(mode, kind, today))
        col = pygame.Rect(max(24, w // 2 - 260), 0, min(520, w - 48), 0)

        y = 184
        if kind == "daily":
            y = self.stat_row(col, y, [(stats.played, "Played"), (stats.win_percent, "Win %"),
                                       (stats.current_streak, "Streak"), (stats.best_streak, "Best streak")])
        else:
            solved = sum(n * count for n, count in stats.distribution.items())
            average = "%.1f" % (solved / stats.won) if stats.won else "-"
            y = self.stat_row(col, y, [(stats.played, "Played"), (stats.win_percent, "Win %"),
                                       (average, "Avg guesses")])
        highlight = None
        if kind != "practice":  # today's daily puzzle, if solved, shows in green
            game, finished = self.history.daily_game(mode, daily.puzzle_number(today))
            highlight = len(game["guesses"]) if finished and game.get("won") else None
        self.text("GUESSES TO SOLVE", 13, MUTED, topleft=(col.x, y + 6))
        y = self.draw_distribution(col, y + 28, stats, mode, highlight)
        if stats.hinted:
            note = "Hints used in %d of these game%s" % (stats.hinted, "" if stats.hinted == 1 else "s")
            self.text(note, 14, MUTED, bold=False, topleft=(col.x, y + 6))

    def stat_row(self, col, y, items):
        """Big numbers with small labels under them, spread across the column. Returns the bottom."""
        width = col.w / len(items)
        for i, (value, label) in enumerate(items):
            center = col.x + width * i + width / 2
            self.text(str(value), 30, TEXT, center=(center, y + 18))
            self.text(label, 13, MUTED, bold=False, center=(center, y + 46))
        return y + 62

    def draw_distribution(self, col, y, stats, mode, highlight):
        """A bar per number of guesses (1-6 in Wordle, 4-9 in Quordle) for the games won."""
        counts = range(1, WORDLE_GUESSES + 1) if mode == "w" else range(4, QUORDLE_GUESSES + 1)
        biggest = max([stats.distribution.get(n, 0) for n in counts] + [1])
        for n in counts:
            count = stats.distribution.get(n, 0)
            self.text(str(n), 15, TEXT, center=(col.x + 8, y + 11))
            bar = pygame.Rect(col.x + 24, y, 30 + (col.w - 24 - 30) * count / biggest, 22)
            self.rrect(ACCENT if n == highlight else BUTTON, bar, 5)
            self.text(str(count), 13, TEXT, midright=(bar.right - 8, bar.centery))
            y += 28
        return y

    def draw_archive(self, now):
        w, h = self.size
        self.draw_screen_header("ARCHIVE")
        mode = self.archive["mode"]
        self.segmented((w // 2 - 130, 80, 260, 40), [("w", "Wordle"), ("q", "Quordle")], mode,
                       lambda value: self.open_archive(value), "archive-mode")
        box = pygame.Rect(16, 136, w - 32, h - 136 - 16)
        self.rrect(PANEL, box, 14)
        area = self.scroll_area = box.inflate(-16, -16)
        today = self.today()
        latest = daily.puzzle_number(today)
        row_h = 52
        content_h = latest * row_h
        info = self.archive
        scroll = self.scroll_range(info, content_h - area.h)

        self.screen.set_clip(self.px_rect(area))
        mouse = self.mouse()
        first = max(0, int(scroll // row_h))
        for i in range(first, min(latest, first + area.h // row_h + 2)):
            number = latest - i  # newest first
            row = FRect(area.x, area.y + i * row_h - scroll, area.w, row_h - 6)
            hit = row.clip(area)
            if hit.collidepoint(mouse):
                self.rrect(lighten(PANEL, 0.08), row, 10)
            self.text("#%d" % number, 18, TEXT, midleft=(row.x + 12, row.centery))
            self.text(daily.describe(number, today), 15, MUTED, bold=False, midleft=(row.x + 78, row.centery))
            status, color = self.daily_status(mode, number)
            if status == "Not played yet":
                pill = pygame.Rect(0, 0, 64, 30)
                pill.midright = (row.right - 10, row.centery)
                self.rrect(BUTTON, pill, 8)
                self.text("Play", 15, TEXT, center=pill.center)
            elif " · " in status:  # (a hint or the word list was used: a small second line)
                main, helped = status.split(" · ", 1)
                self.text(main, 15, color, bold=False, midright=(row.right - 12, row.centery - 8))
                self.text(helped, 12, MUTED, bold=False, midright=(row.right - 12, row.centery + 11))
            else:
                self.text(status, 15, color, bold=False, midright=(row.right - 12, row.centery))
            if hit.h > 0:
                self.clickables.append((hit, lambda now, n=number: self.start(mode, number=n), "archive:%d" % number))
        self.screen.set_clip(None)
        self.draw_scrollbar(box, area, content_h, scroll)

    # ----- account (sync) and friends --------------------------------------------
    # Two different things, explained on both screens: Account keeps your OWN games on all your
    # devices; Friends only shows daily results side by side, and never mixes anyone's games.
    # Anything hard to take back waits UNDO_MS with an Undo button (self.pending).

    PRIVACY_NOTE = "Games are saved online to keep them safe and improve the game."
    FRIENDS_NOTE = ("Compare daily puzzles with friends. Pick a name, then send friends an invite link. "
                    "Friends only see your daily results (guesses, streak, win %): never your words, your "
                    "practice games, or anything on your devices. Your games never mix with theirs.")
    ENTRY_HINTS = {
        "friend": "Ask your friend for the code on their Friends screen. You can remove a friend any time.",
        "name": "Up to 16 letters, numbers or spaces. It doesn't have to be unique: friends are matched by code.",
    }

    def undoable(self, text, action, now, key=None):
        """Do action in UNDO_MS unless Undo is tapped (a pending one goes ahead first)."""
        self.finish_pending(now)
        self.pending = {"text": text, "action": action, "at": now + UNDO_MS, "key": key}

    def finish_pending(self, now):
        pending, self.pending = self.pending, None
        if pending:
            pending["action"](now)

    def undo(self, now):
        self.pending = None

    def pending_key(self):
        return self.pending["key"] if self.pending else None

    def draw_pending(self, now):
        """The "...  Undo" bar along the bottom while an action waits."""
        if not self.pending:
            return
        w, h = self.size
        bar = pygame.Rect(12, h - 76, w - 24, 64)
        self.rrect(TEXT, bar, 14)
        left = max(0, -(-(self.pending["at"] - now) // 1000))
        label = "%s in %d s" % (self.pending["text"], left)
        size = 16
        while size > 12 and self.fonts.get(size * self.scale).size(label)[0] > (bar.w - 250) * self.scale:
            size -= 1
        self.text(label, size, DARK_TEXT, midleft=(bar.x + 18, bar.centery))
        # Confirm is the green one (green means "go" everywhere else); Undo stays right next to it.
        self.button((bar.right - 112, bar.y + 10, 100, 44), "Undo", self.undo, size=16)
        self.button((bar.right - 222, bar.y + 10, 100, 44), "Confirm", self.finish_pending, size=16, primary=True)

    def paragraph(self, text, size, color, col, y, center=False):
        """Wrapped text across the column; returns the y below it."""
        line_h = round(size * 1.4)
        for line in self.wrap(text, size, col.w):
            if center:
                self.text(line, size, color, bold=False, center=(col.centerx, y + line_h / 2))
            else:
                self.text(line, size, color, bold=False, topleft=(col.x, y))
            y += line_h
        return y

    def show_message(self, message, col, y):
        if not message:
            return y
        text, ok = message
        return self.paragraph(text, 15, SOLVED_TEXT if ok else ERROR_TEXT, col, y + 4, center=True)

    def column(self):
        w = self.size[0]
        return pygame.Rect(max(24, w // 2 - 260), 0, min(520, w - 48), 0)

    def entry_keyboard_area(self):
        w, h = self.size
        rows = 4 if self.entry and self.entry["kind"] == "name" else 3
        return pygame.Rect(16, h - rows * 52 - (rows - 1) * 6 - 16, w - 32, rows * 52 + (rows - 1) * 6)

    def draw_entry(self, col, y, label, message):
        """The code or name being typed, with big Cancel and Save/Link/Add buttons (phones have no
        Enter key), a hint, and the letter keyboard at the bottom."""
        entry = self.entry
        kind = entry["kind"]
        self.text(label, 16, MUTED, center=(col.centerx, y + 10))
        y += 30
        y = self.draw_name_box(col, y, entry["text"]) if kind == "name" else self.draw_code_boxes(col, y, entry["text"])
        text = entry["text"].strip()
        ready = bool(text) if kind == "name" else len(text) == 8
        done = {"friend": "Add friend", "name": "Save"}[kind]
        half = min(150, (col.w - 12) // 2)
        self.button((col.centerx - half - 6, y, half, 46), "Cancel", lambda now: setattr(self, "entry", None), size=16)
        self.button((col.centerx + 6, y, half, 46), done, lambda now: self.entry_key("enter", now), size=16,
                    primary=True, enabled=ready)
        y = self.show_message(message, col, y + 52)
        self.paragraph(self.ENTRY_HINTS[kind], 14, MUTED, col, y + 8, center=True)
        self.draw_entry_keyboard(self.entry_keyboard_area())

    def draw_sync(self, now):
        """The Account screen: signed in (with Sign out / Delete account) or the optional sign-in."""
        w, h = self.size
        self.draw_screen_header("ACCOUNT")
        sync = self.sync
        col = self.column()
        y = self.paragraph(sync.status(now), 15, TEXT, col, 84, center=True) + 18
        busy = self.pending_key() == "sign out" or sync.waiting("account_delete") or sync.signing_out()
        if sync.signed_in:
            self.text("Signed in as", 13, MUTED, topleft=(col.x, y))
            self.text(sync.signed_in, 20, TEXT, topleft=(col.x, y + 18))
            y = self.paragraph("Your games are saved to your account. Sign in on your other phones and computers "
                               "to see them there too.", 15, MUTED, col, y + 50) + 10
            half = (col.w - 12) // 2
            if not busy:
                self.button((col.x, y, half, 44), "Sign out", self.sign_out, size=16)
                self.button((col.x + half + 12, y, half, 44), "Delete account", self.delete_account, size=16)
            elif sync.signing_out():
                self.text("Signing out...", 16, MUTED, bold=False, center=(col.centerx, y + 22))
            y = self.paragraph("Signing out takes your games off this device; they stay safe in your account.", 13,
                               MUTED, col, y + 54)
            if not busy:
                self.button((col.centerx - 130, y + 6, 260, 36), "Sign out everywhere", self.sign_out_everywhere,
                            size=14)
            y += 44
        else:
            self.text("SAVE YOUR STATS", 13, MUTED, topleft=(col.x, y))
            y = self.paragraph("Sign in and your games are kept in your account: sign in on your phone, tablet "
                               "and computer to see them everywhere, and a new phone or a cleared browser gets "
                               "them back. It's optional: you can keep playing without one.", 15, MUTED, col,
                               y + 22) + 10
            if not busy:
                self.button((col.x, y, col.w, 46), "Sign in or create account",
                            lambda now: self.sync.open_account_form(), size=16, primary=True)
            y += 46
        y = self.show_message(sync.message, col, y + 8)
        self.button((col.centerx - 160, y + 60, 320, 38), "Settings", lambda now: self.open_settings(), size=14)
        self.button((col.centerx - 160, y + 14, 320, 38), "Comparing with friends? Open Friends",
                    lambda now: self.open_friends(), size=14)
        lines = self.wrap(self.PRIVACY_NOTE, 13, col.w)
        self.paragraph(self.PRIVACY_NOTE, 13, MUTED, col, max(y + 110, h - 16 - len(lines) * 18))

    def sign_out(self, now):
        self.undoable("Signing out", self.sync.sign_out, now, key="sign out")

    def signed_out_elsewhere(self, why):
        """The server signed this device out (Sign out everywhere on another device, or this device was
        signed out in another tab): its games are gone from here, so back to the menu, and say why."""
        if self.scene in ("game", "stats", "archive", "friends"):
            self.go_to_menu()
        self.friend_view = None
        self.entry = None
        self.dialog = {"title": "Signed out", "text": why, "yes": "Sign in", "cancel": lambda now: None,
                       "action": lambda now: self.sign_in_from_menu()}

    def sign_out_everywhere(self, now):
        """Ask first (a popup), then sign out on every device and browser on the account."""
        self.dialog = {"title": "Sign out everywhere?",
                       "text": "Signs %s out on every phone, computer and browser, this one included. Each one "
                               "saves its games to your account first. Other accounts aren't affected."
                               % (self.sync.signed_in or "this account"),
                       "yes": "Sign out all",
                       "action": lambda now: self.sync.sign_out(now, everywhere=True)}

    def delete_account(self, now):
        """Ask first (a popup, not an Undo bar: this can't be taken back)."""
        self.dialog = {"title": "Delete your account?",
                       "text": "This deletes your account, its email and password, your friends and every game in it, "
                               "from the server and from this device. It can't be undone. To make sure it's you, "
                               "we'll email you a code to confirm.",
                       "yes": "Email me a code", "action": self.sync.delete_account}

    def dialog_answer(self, yes, now):
        dialog, self.dialog = self.dialog, None
        if yes and dialog:
            dialog["action"](now)
        elif dialog and dialog.get("cancel"):
            dialog["cancel"](now)

    def draw_dialog(self, now):
        """A confirmation popup over everything (self.dialog)."""
        w, h = self.size
        self.clickables.append((pygame.Rect(0, 0, w, h), lambda now: None, "dialog:backdrop"))
        shade = pygame.Surface(self.full_screen.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 160))
        self.full_screen.blit(shade, (0, 0))
        panel_w = min(440, w - 32)
        col = pygame.Rect(w // 2 - panel_w // 2 + 22, 0, panel_w - 44, 0)
        lines = self.wrap(self.dialog["text"], 15, col.w)
        panel_h = 70 + len(lines) * 21 + 80
        panel = pygame.Rect(w // 2 - panel_w // 2, (h - panel_h) // 2, panel_w, panel_h)
        self.rrect(PANEL, panel, 16)
        self.text(self.dialog["title"], 20, TEXT, topleft=(col.x, panel.y + 20))
        y = self.paragraph(self.dialog["text"], 15, MUTED, col, panel.y + 56)
        half = (col.w - 12) // 2
        self.button((col.x, y + 16, half, 46), "Not now" if self.dialog.get("cancel") else "Cancel",
                    lambda now: self.dialog_answer(False, now), size=16)
        if self.dialog.get("cancel"):  # (a friendly question, not a warning)
            self.button((col.x + half + 12, y + 16, half, 46), self.dialog["yes"],
                        lambda now: self.dialog_answer(True, now), size=16, primary=True)
            return
        rect = pygame.Rect(col.x + half + 12, y + 16, half, 46)
        self.rrect(ERROR_TEXT if not rect.collidepoint(self.mouse()) else lighten(ERROR_TEXT, 0.1), rect, 10)
        self.text(self.dialog["yes"], 16, DARK_TEXT, center=rect.center)
        self.clickables.append((rect, lambda now: self.dialog_answer(True, now), "button:" + self.dialog["yes"]))

    # The sign-in form. In a browser it's a real HTML form (web/template.tmpl), so Safari can fill in
    # the email, password and emailed code; on a computer it's drawn here.

    def publish_auth_form(self):
        form = self.sync.auth_form
        spec = json.dumps(form, sort_keys=True) if form else ""
        if spec == self.published_auth:
            return
        try:
            import platform
            if form:
                platform.window.wordleAuthShow(spec)
            else:
                platform.window.wordleAuthHide()
            self.published_auth = spec
        except Exception:
            pass

    def poll_auth_form(self, now):
        if not self.sync.auth_form:
            return
        try:
            import platform
            text = str(platform.window.wordleAuthTake() or "")
            event = json.loads(text) if text else None
        except Exception:
            return
        if isinstance(event, dict):
            self.sync.account_action(str(event.get("action", "")), str(event.get("email", "")),
                                     str(event.get("password", "")), str(event.get("code", "")), now)
            self.published_auth = None  # (shown again even if unchanged: typing hid its red error box)

    AUTH_TITLES = {"signin": "Sign in to save your stats", "signup": "Create an account", "code": "Email me a code",
                   "verify": "Enter the code", "newpassword": "Choose a new password", "delete": "Delete your account"}
    AUTH_FIELDS = {"signin": [("email", "Email"), ("password", "Password")],
                   "signup": [("email", "Email"), ("password", "New password (6 or more characters)")],
                   "code": [("email", "Email")], "verify": [("code", "6-digit code from the email")],
                   "newpassword": [("password", "New password (6 or more characters)")],
                   "delete": [("code", "6-digit code from the email")]}
    AUTH_SUBMIT = {"signin": ("Sign in", "signin"), "signup": ("Create account", "signup"),
                   "code": ("Email me a code", "send_code"), "verify": ("Continue", "verify"),
                   "newpassword": ("Save password", "set_password"), "delete": ("Delete my account", "confirm_delete")}
    AUTH_LINKS = {"signin": [("Email me a code instead", "mode:code"), ("Forgot password?", "mode:reset"),
                             ("Create an account", "mode:signup")],
                  "signup": [("I already have an account", "mode:signin")],
                  "code": [("Use my password instead", "mode:signin")],
                  "verify": [("Send a new code", "resend"), ("Use a different email", "mode:code")],
                  "newpassword": [], "delete": [("Send a new code", "resend_delete")]}

    def auth_state(self):
        """The Mac form's typed values, reset when the form changes screens."""
        form = self.sync.auth_form
        key = (form.get("opened"), form["mode"], form.get("purpose"))  # (a reopened form starts empty)
        if self.auth_input.get("mode") != key:
            fields = [name for name, _label in self.AUTH_FIELDS[form["mode"]]]
            self.auth_input = {"mode": key, "email": form.get("email", ""), "password": "", "code": "",
                               "field": next((f for f in fields if not (f == "email" and form.get("email"))),
                                             fields[0])}
        return self.auth_input

    def auth_do(self, action, now):
        state = self.auth_state()
        self.sync.account_action(action, state["email"], state["password"], state["code"], now)

    def auth_key(self, event, now):
        state = self.auth_state()
        fields = [name for name, _label in self.AUTH_FIELDS[self.sync.auth_form["mode"]]]
        if event.key == pygame.K_ESCAPE:
            self.auth_do("cancel", now)
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.auth_do(self.AUTH_SUBMIT[self.sync.auth_form["mode"]][1], now)
        elif event.key == pygame.K_TAB:
            at = fields.index(state["field"]) if state["field"] in fields else -1
            state["field"] = fields[(at + 1) % len(fields)]
        elif event.key == pygame.K_BACKSPACE:
            state[state["field"]] = state[state["field"]][:-1]
        elif event.key == pygame.K_v and event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            try:
                pasted = pygame.scrap.get_text() or ""
            except Exception:
                pasted = ""
            state[state["field"]] = (state[state["field"]] + pasted.strip())[:200]
        elif not event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            char = getattr(event, "unicode", "")
            if len(char) == 1 and char.isprintable() and len(state[state["field"]]) < 200:
                if state["field"] != "code" or char.isdigit():
                    state[state["field"]] += char

    def draw_auth_form(self, now):
        """The Mac app's sign-in form (a browser shows a real HTML form instead)."""
        form = self.sync.auth_form
        state = self.auth_state()
        w, h = self.size
        mode = form["mode"]
        self.clickables.append((pygame.Rect(0, 0, w, h), lambda now: None, "auth:backdrop"))
        shade = pygame.Surface(self.full_screen.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 150))
        self.full_screen.blit(shade, (0, 0))
        panel_w = min(460, w - 32)
        col = pygame.Rect(w // 2 - panel_w // 2 + 20, 0, panel_w - 40, 0)
        fields = self.AUTH_FIELDS[mode]
        links = self.AUTH_LINKS[mode]
        if mode == "verify" and form.get("purpose") == "signup":
            links = [("Send a new code", "resend"), ("Used the link in the email? Sign in", "mode:signin"),
                     ("Use a different email", "mode:signup")]
        notes = [t for t in (form.get("error"), form.get("note")) if t]
        panel_h = 70 + 64 * len(fields) + 24 * sum(len(self.wrap(t, 14, col.w)) for t in notes) + 58 + 46 * (
            len(links) + 1) + 16
        panel = pygame.Rect(w // 2 - panel_w // 2, max(16, (h - panel_h) // 2), panel_w, panel_h)
        self.rrect(PANEL, panel, 16)
        title = self.AUTH_TITLES[mode] if form.get("purpose") != "reset" or mode != "code" else "Reset your password"
        self.text(title, 20, TEXT, topleft=(col.x, panel.y + 18))
        y = panel.y + 56
        for name, label in fields:
            box = pygame.Rect(col.x, y + 18, col.w, 40)
            self.text(label, 13, MUTED, topleft=(col.x, y))
            focused = state["field"] == name
            self.rrect(BG, box, 8)
            self.rrect(TYPED_BORDER if focused else EMPTY_BORDER, box, 8, 2)
            shown = "•" * len(state[name]) if name == "password" else state[name]
            cursor = "|" if focused and (pygame.time.get_ticks() // 500) % 2 else ""
            self.text((shown + cursor)[-40:], 16, TEXT, bold=False, midleft=(box.x + 10, box.centery))
            self.clickables.append((box, lambda now, n=name: state.update(field=n), "auth:" + name))
            y += 64
        if form.get("error"):
            y = self.paragraph(form["error"], 14, ERROR_TEXT, col, y)
        if form.get("note"):
            y = self.paragraph(form["note"], 14, SOLVED_TEXT, col, y)
        label, submit = self.AUTH_SUBMIT[mode]
        if mode == "delete" and not form.get("busy"):  # (red: it can't be undone)
            rect = pygame.Rect(col.x, y + 8, col.w, 46)
            self.rrect(ERROR_TEXT if not rect.collidepoint(self.mouse()) else lighten(ERROR_TEXT, 0.1), rect, 10)
            self.text(label, 17, DARK_TEXT, center=rect.center)
            self.clickables.append((rect, lambda now: self.auth_do("confirm_delete", now), "button:" + label))
        else:
            self.button((col.x, y + 8, col.w, 46), "One moment..." if form.get("busy") else label,
                        lambda now, a=submit: self.auth_do(a, now), size=17, primary=True, enabled=not form.get("busy"))
        y += 62
        for label, action in links + [("Cancel", "cancel")]:
            self.button((col.x, y, col.w, 38), label, lambda now, a=action: self.auth_do(a, now), size=15)
            y += 46

    def draw_code_boxes(self, col, y, typed):
        box, gap, dash = 40, 6, 18
        total = 8 * box + 6 * gap + dash
        x = col.centerx - total / 2
        for i in range(8):
            cell = pygame.Rect(round(x), y, box, 48)
            self.rrect(EMPTY_BORDER if i >= len(typed) else TYPED_BORDER, cell, 8, 2)
            if i < len(typed):
                self.text(typed[i], 24, TEXT, center=cell.center)
            x += box + (dash if i == 3 else gap)
        self.text("-", 24, MUTED, center=(col.centerx, y + 24))
        return y + 48 + 14

    def draw_name_box(self, col, y, typed):
        box = pygame.Rect(col.centerx - 160, y, 320, 48)
        self.rrect(TYPED_BORDER if typed else EMPTY_BORDER, box, 10, 2)
        self.text(typed + ("|" if (pygame.time.get_ticks() // 500) % 2 else " "), 22, TEXT, center=box.center)
        return box.bottom + 14

    def draw_entry_keyboard(self, area):
        """Letters (and a space bar for names) for whatever self.entry is typing."""
        kind = self.entry["kind"]
        rows = KEY_ROWS + ([["space"]] if kind == "name" else [])
        gap = 6
        key_h = int(min(52, (area.h - (len(rows) - 1) * gap) / len(rows)))
        width = min(area.w, 640)
        key_w = (width - 9 * gap) / 10
        top = area.bottom - len(rows) * key_h - (len(rows) - 1) * gap
        text = self.entry["text"].strip()
        ready = bool(text) if kind == "name" else len(text) == 8
        if kind == "word":
            ready = self.made_word()[0] is not None
        enter_label = {"friend": "ADD", "name": "SAVE", "word": "SEND" if WEB else "COPY"}[kind]
        for r, row in enumerate(rows):
            widths = [key_w * 1.55 if k in ("enter", "back") else key_w * 5 if k == "space" else key_w for k in row]
            x = area.centerx - (sum(widths) + gap * (len(row) - 1)) / 2
            y = top + r * (key_h + gap)
            for key, key_width in zip(row, widths):
                rect = pygame.Rect(round(x), y, round(key_width), key_h)
                color = ACCENT if key == "enter" and ready else KEY
                if rect.collidepoint(self.mouse()):
                    color = lighten(color, 0.14)
                self.rrect(color, rect, 8)
                label = {"enter": enter_label, "back": "DEL", "space": "SPACE"}.get(key, key.upper())
                self.text(label, min(16 if len(label) > 1 else 22, key_h * 0.4), TEXT, center=rect.center)
                self.clickables.append((rect, lambda now, key=key: self.entry_key(key, now), "key:" + key))
                if key == "enter" and kind == "word" and ready:
                    self.share_targets.append((rect, self.made_link_text(self.made_word()[0])))
                x += key_width + gap

    # Friends

    def invite_text(self):
        code = str((self.sync.friends_data()["profile"] or {}).get("code", ""))
        return "Let's compare Wordle scores! Tap to add me as a friend: %s?friend=%s" % (self.link, code)

    def send_invite(self, now):
        """Share the invite link: in a browser the page does it on the tap itself (share_targets); a
        computer copies it."""
        if WEB:
            return
        try:
            pygame.scrap.put_text(self.invite_text())
            self.toast(self.copied_message(), now)
        except Exception:
            self.toast("Couldn't copy the link. Give your friend your code instead", now)

    def accept_invite(self, now):
        code = self.sync.state().pop("invite", None)
        self.history.save()
        if code:
            self.sync.add_friend(code, now)

    def drop_invite(self):
        self.sync.state().pop("invite", None)
        self.history.save()

    def stop_sharing(self, now):
        """Remove every friend and the friends name: asked in a popup first, then the usual Undo bar."""
        friends = self.sync.friends_data().get("list") or []
        name = str(friends[0].get("name") or "") if len(friends) == 1 and isinstance(friends[0], dict) else ""
        who = ("all %d friends" % len(friends) if len(friends) > 1 else "your friend " + name if name
               else "your friend" if friends else "your friends")
        self.dialog = {"title": "Remove all friends?",
                       "text": "This removes %s and your friends name. You stop seeing each other's daily results, "
                               "and getting them back takes new invite links. Your own games aren't affected." % who,
                       "yes": "Remove all", "action": self.remove_all_friends}

    def remove_all_friends(self, now):
        self.sync.stop_sharing(now)
        self.friend_view = None

    def remove_friend(self, friend_id, name, now):
        """From a friend's page: asked in a popup (no Undo bar), then done at once."""
        self.dialog = {"title": "Remove %s?" % name,
                       "text": "You'll stop seeing each other's daily results. To be friends again, one of you sends "
                               "the other a new invite link.",
                       "yes": "Remove", "action": lambda now: self.confirm_remove_friend(friend_id, name, now)}

    def confirm_remove_friend(self, friend_id, name, now):
        self.sync.remove_friend(friend_id, now)
        self.removing_friends.add(friend_id)
        self.friend_view = None
        self.sync.friends_message = ("Removed %s" % name, True)

    def friends_played_today(self):
        """How many friends finished a daily puzzle today (the Friends button's count; no scores)."""
        today = self.today()

        def compute():
            number = daily.puzzle_number(today)
            return sum(1 for f in self.sync.friends_data().get("list") or []
                       if any(isinstance(g, list) and len(g) > 1 and g[1] == number for g in f.get("games") or []))
        return self.memo(("friends played", today), compute)

    def open_friend_page(self, friend_id):
        self.friend_view = {"id": friend_id, "scroll": 0}

    def my_daily_done(self, mode, number):
        return bool(self.history.daily_game(mode, number)[1])

    def friend_rows(self, mode, today):
        """[(name, today's result, Stats, friend id or None for you)], you first. Names needn't be
        unique (friends are matched by code), so a name shared in the list gets a short tag."""
        def compute():
            data = self.sync.friends_data()
            mine = [g for g in self.history.games if g.get("daily") is not None]
            me = data["profile"]["name"] if data["profile"] else "You"
            names = [str(f.get("name", "?")) for f in data["list"]]
            counts = {}
            for name in names + [me]:
                counts[name.lower()] = counts.get(name.lower(), 0) + 1
            rows = [("%s (you)" % me,) + friend_summary(mine, mode, today) + (None,)]
            number = daily.puzzle_number(today)
            done = self.my_daily_done(mode, number)
            friends = []
            ranks = {}
            for friend, name in zip(data["list"], names):
                if counts[name.lower()] > 1:
                    name = "%s · %s" % (name, str(friend["id"]).replace("-", "")[:3].upper())
                games = friend_games(friend.get("games") or [], mode, friend.get("help"), friend.get("details"))
                result, stats = friend_summary(games, mode, today)
                friends.append((name, result, stats, friend["id"]))
                todays = next((g for g in games if g["daily"] == number), None)
                ranks[friend["id"]] = (result_rank(todays) if todays else (2, 0, 0)) + (name.lower(),)
            if done:
                # Today's scoreboard: solved first, fewest guesses (a guess with help counts as two),
                # then not solved, then not played yet.
                friends.sort(key=lambda row: ranks[row[3]])
            else:
                # (no spoilers: only whether they've played, until you finish today's puzzle too)
                friends = [(n, "played" if r != "-" else "-", s, i) for n, r, s, i in friends]
            return rows + friends
        return [r for r in self.memo(("friends", mode, today), compute) if r[3] not in self.removing_friends]

    def draw_friends(self, now):
        w, h = self.size
        if self.friend_view and self.sync.enabled and self.sync.signed_in and self.sync.friends_data()["profile"] \
                and not self.entry:
            self.draw_friend_page(now)  # (its own header: Back and the friend's name)
            return
        self.draw_screen_header("FRIENDS")
        sync, screen = self.sync, self.friends_screen
        col = self.column()
        data = sync.friends_data()
        profile = data["profile"]
        if not sync.enabled:
            self.paragraph("Friends needs the server, which isn't set up in this version.", 16, MUTED, col, 100,
                           center=True)
            return
        if self.entry and self.entry["kind"] in ("name", "friend") and not sync.signed_in:
            self.entry = None  # (signed out meanwhile, maybe from another tab: offer Sign in instead)
        if self.entry and self.entry["kind"] in ("name", "friend"):
            label = "Your name (friends see it)" if self.entry["kind"] == "name" else "Your friend's code"
            self.draw_entry(col, 80, label, sync.friends_message)
            return
        waiting = sync.waiting("profile", "friend_add", "friend_remove")
        invite = sync.state().get("invite")
        if not sync.signed_in:
            y = 88
            if invite:
                y = self.paragraph("You opened a friend's invite. Sign in or create an account and pick a name, and "
                                   "they'll be added.", 15, SOLVED_TEXT, col, y) + 12
            y = self.paragraph("Compare daily puzzles with friends. Friends works with an account, so your friends "
                               "see the same you on every device, and only see your daily results: never your words "
                               "or practice games.", 15, MUTED, col, y)
            self.button((col.x, y + 16, col.w, 46), "Sign in or create account",
                        lambda now: self.sync.open_account_form(), size=16, primary=True)
            self.show_message(sync.friends_message, col, y + 70)
            return
        if profile is None:
            y = 88
            if invite:
                y = self.paragraph("Pick a name and we'll add the friend who invited you.", 15, SOLVED_TEXT, col,
                                   y) + 12
            y = self.paragraph(self.FRIENDS_NOTE, 15, MUTED, col, y)
            if waiting or sync.friends_loading():  # (not "Choose a name" before the account's answer is in)
                self.text("Asking the server...", 16, MUTED, bold=False, center=(col.centerx, y + 30))
            else:
                self.button((col.centerx - 110, y + 16, 220, 46), "Choose a name",
                            lambda now: self.start_entry("name"), size=16, primary=True)
            self.show_message(sync.friends_message, col, y + 70)
            return
        if invite and not waiting and not self.dialog:
            if invite == str(profile.get("code", "")):
                sync.state().pop("invite", None)
                sync.friends_message = ("That's your own invite link: send it to a friend", True)
            else:
                self.dialog = {"title": "Add a friend?", "text": "You opened a friend's invite link. Add them as a "
                               "friend? You'll each see the other's daily results.", "yes": "Add friend",
                               "action": lambda now: self.accept_invite(now), "cancel": lambda now: self.drop_invite()}

        # Your name and code.
        self.text("Sharing as", 13, MUTED, topleft=(col.x, 78))
        self.text(profile.get("name", ""), 20, TEXT, topleft=(col.x, 96))
        self.button((col.right - 120, 82, 120, 36), "Change name", lambda now: self.start_entry("name"), size=14)
        ready = sync.invite_ready(now) and not waiting
        invite_rect = self.button((col.x, 136, col.w, 46), "Invite a friend" if ready else "Getting a fresh invite...",
                                  lambda now: self.send_invite(now), size=16, primary=True, enabled=ready)
        if ready:
            self.share_targets.append((invite_rect, self.invite_text()))
        self.text("Send it by message. Invite links work for a few minutes, so send a new one if it's old.", 13,
                  MUTED, center=(col.centerx, 196))
        self.segmented((col.centerx - 130, 218, 260, 38), [("w", "Wordle"), ("q", "Quordle")], screen["mode"],
                       lambda value: screen.update(mode=value), "friends")
        y = self.show_message(sync.friends_message, col, 260)

        # The table: you, then friends.
        top = max(y + 6, 276)
        cols = [("TODAY", 0.45), ("STREAK", 0.59), ("WIN %", 0.72), ("PLAYED", 0.84)]
        self.text("NAME", 12, MUTED, midleft=(col.x + 8, top + 8))
        for label, at in cols:
            self.text(label, 12, MUTED, center=(col.x + col.w * at, top + 8))
        bottom = h - 72
        box = pygame.Rect(col.x - 8, top + 20, col.w + 16, bottom - top - 28)
        self.rrect(PANEL, box, 12)
        area = self.scroll_area = box.inflate(-8, -8)
        rows = self.friend_rows(screen["mode"], self.today())
        row_h = 44
        content_h = len(rows) * row_h + (60 if len(rows) == 1 else 0)
        self.scroll_range(screen, content_h - area.h)
        self.screen.set_clip(self.px_rect(area))
        for i, (name, result, stats, friend_id) in enumerate(rows):
            row = FRect(area.x, area.y + i * row_h - screen["scroll"], area.w, row_h - 4)
            if row.bottom < area.y or row.y > area.bottom:
                continue
            if friend_id is None:
                self.rrect(lighten(PANEL, 0.06), row, 8)
            shown = name if len(name) <= 22 else name[:21] + "..."
            self.text(shown, 16, TEXT, midleft=(row.x + 10, row.centery))
            result, _, helped = str(result).partition(" ")  # ("4/6 +1": a small "+1" after it, for the help)
            values = [result, stats.current_streak, "%d" % stats.win_percent if stats.played else "-", stats.played]
            for (label, at), value in zip(cols, values):
                color = TEXT
                if label == "TODAY" and "/" in str(value):  # "4/6" green, "X/6" (lost) red
                    color = LOST_TEXT if str(value).startswith("X") else SOLVED_TEXT
                spot = self.text(str(value), 16, color, center=(col.x + col.w * at, row.centery))
                if label == "TODAY" and helped:
                    self.text(helped, 12, MUTED, bold=False, midleft=(spot.right + 2, row.centery))
            if friend_id is not None:
                self.text("›", 18, MUTED, midright=(row.right - 10, row.centery))
                hit = row.clip(area)
                if hit.h > 0:
                    self.clickables.append((hit, lambda now, f=friend_id: self.open_friend_page(f), "friend:%s" % name))
        if len(rows) == 1:
            self.paragraph("No friends yet. Tap Invite a friend and send the link.", 14, MUTED,
                           pygame.Rect(area.x + 10, 0, area.w - 20, 0), area.y + row_h + 8)
        self.screen.set_clip(None)
        self.draw_scrollbar(box, area, content_h, screen["scroll"])
        if len(rows) > 1:
            self.text("Tap a friend for their results and how you compare", 12, MUTED, bold=False,
                      center=(col.centerx, h - 62))
        if not waiting:
            # A small link, not a big button: it removes every friend (after a popup).
            hovered = pygame.Rect(col.centerx - 90, h - 50, 180, 32).collidepoint(self.mouse())
            spot = self.text("Remove all friends", 14, TEXT if hovered else MUTED, bold=False,
                             center=(col.centerx, h - 34))
            pygame.draw.line(self.screen, TEXT if hovered else MUTED, (self.px(spot.x), self.px(spot.bottom)),
                             (self.px(spot.right), self.px(spot.bottom)), max(1, int(self.scale)))
            self.clickables.append((spot.inflate(24, 16), self.stop_sharing, "button:Remove all friends"))

    def draw_friend_page(self, now):
        """One friend: today's result (only once you've finished it too), how you two compare, their
        stats and recent puzzles, and, tucked at the bottom, Remove (asked in a popup)."""
        w, h = self.size
        view = self.friend_view
        data = self.sync.friends_data()
        friend = next((f for f in data.get("list") or [] if f.get("id") == view["id"]), None)
        if friend is None or view["id"] in self.removing_friends:
            self.friend_view = None
            return
        name = str(friend.get("name") or "?")
        short = name if len(name) <= 16 else name[:15] + "..."
        bw = 84 if w >= 640 else 62
        self.button((16, 14, bw, 36), "Back", lambda now: setattr(self, "friend_view", None), size=16)
        self.text(short, 26, TEXT, center=(w // 2, 32))
        self.rrect(EMPTY_BORDER, (0, 64, w, 1), 0)
        col = self.column()
        mode = self.friends_screen["mode"]
        self.segmented((col.centerx - 130, 78, 260, 38), [("w", "Wordle"), ("q", "Quordle")], mode,
                       lambda value: self.friends_screen.update(mode=value), "friends")
        game_name = "Wordle" if mode == "w" else "Quordle"
        limit = WORDLE_GUESSES if mode == "w" else QUORDLE_GUESSES
        today = self.today()
        number = daily.puzzle_number(today)
        details = friend.get("details") if isinstance(friend.get("details"), dict) else {}
        theirs = {g["daily"]: g for g in friend_games(friend.get("games") or [], mode, friend.get("help"), details)}
        mine = {g["daily"]: g for g in self.history.games if g.get("mode") == mode and g.get("daily") is not None}

        def score(game):
            return result_text(game, limit)

        area = self.scroll_area = pygame.Rect(col.x - 8, 128, col.w + 16, h - 140)
        if "content_h" in view:  # (keep the scroll in range before drawing, using last frame's height)
            self.scroll_range(view, view["content_h"] - area.h)
        col = pygame.Rect(col.x, col.y, col.w - 12, col.h)  # (room for the scrollbar on the right)
        self.screen.set_clip(self.px_rect(area))
        # (this page's tiles and bars are whole-point rects, so it moves in whole points to keep them
        # lined up with their text)
        y = area.y + 6 - round(view["scroll"])

        def heading(text, y):
            self.text(text, 12, MUTED, topleft=(col.x, y))
            return y + 22

        def visible(rect):
            return area.contains(rect)

        # Today.
        y = heading("TODAY · %s #%d" % (game_name.upper(), number), y)
        today_theirs = theirs.get(number)
        if today_theirs is None:
            y = self.paragraph("%s hasn't finished today's %s yet." % (name, game_name), 15, TEXT, col, y)
        elif not self.my_daily_done(mode, number):
            y = self.paragraph("%s has played today's %s. Finish yours to see how they did." % (name, game_name),
                               15, TEXT, col, y)
            play = pygame.Rect(col.x, y + 10, min(260, col.w), 42)
            if visible(play):
                self.button(play, "Play today's %s" % game_name, lambda now, m=mode: self.start(m, number=number),
                            size=15, primary=True)
            y = play.bottom
        else:
            y = self.draw_friend_result(today_theirs, details.get("%s:%d" % (mode, number)), col, y, limit)
        y += 22

        # Head to head: the dailies you've both finished (any win beats a loss; fewer guesses wins, a
        # guess with a hint or the word list counting as two; then less help: history.result_rank).
        y = heading("HEAD TO HEAD", y)
        both = sorted(set(mine) & set(theirs))
        if not both:
            y = self.paragraph("No %s dailies you've both finished yet." % game_name, 15, MUTED, col, y)
        else:
            me_won = sum(1 for n in both if result_rank(mine[n]) < result_rank(theirs[n]))
            they_won = sum(1 for n in both if result_rank(mine[n]) > result_rank(theirs[n]))
            tied = len(both) - me_won - they_won
            y = self.paragraph("You %d  ·  %s %d  ·  tied %d   (%d puzzle%s)" % (
                me_won, name, they_won, tied, len(both), "" if len(both) == 1 else "s"), 16, TEXT, col, y)

            def average(games):
                wins = [len(g["guesses"]) for g in games if g.get("won")]
                return "%.1f" % (sum(wins) / len(wins)) if wins else "-"
            y = self.paragraph("Average guesses on those: you %s  ·  %s %s" % (
                average([mine[n] for n in both]), name, average([theirs[n] for n in both])), 14, MUTED, col, y + 4)
            y = self.paragraph("Guesses with help: you %d  ·  %s %d" % (
                sum(helped_guesses(mine[n]) for n in both), name, sum(helped_guesses(theirs[n]) for n in both)),
                14, MUTED, col, y + 4)
            y = self.paragraph("A guess with a hint or the word list counts as two.", 13, MUTED, col, y + 2)
        y += 22

        # Custom Wordles between you two (Alex, Nov 2026: they count only here, in the 1-on-1).
        if mode == "w":
            y = self.draw_friend_custom(friend_custom(friend.get("custom")), name, short, col, y, visible,
                                        friend.get("makers"))

        # Their stats.
        stats = friend_summary(list(theirs.values()), mode, today)[1]
        y = heading("%s'S %s STATS" % (short.upper(), game_name.upper()), y)
        tiles = [(str(stats.played), "played"), ("%d%%" % stats.win_percent if stats.played else "-", "won"),
                 (str(stats.current_streak), "streak"), (str(stats.best_streak), "best")]
        each = (col.w - 3 * 8) // 4
        for i, (value, label) in enumerate(tiles):
            tile = pygame.Rect(col.x + i * (each + 8), y, each, 58)
            self.rrect(PANEL, tile, 10)
            self.text(value, 20, TEXT, center=(tile.centerx, tile.y + 22))
            self.text(label, 12, MUTED, bold=False, center=(tile.centerx, tile.y + 44))
        y += 70
        first = 1 if mode == "w" else 4
        most = max([stats.distribution.get(n, 0) for n in range(first, limit + 1)] + [1])
        for n in range(first, limit + 1):
            count = stats.distribution.get(n, 0)
            self.text(str(n), 13, MUTED, midleft=(col.x, y + 9))
            bar = pygame.Rect(col.x + 20, y, max(22, round((col.w - 20) * count / most)), 18)
            self.rrect(ACCENT if count else BUTTON, bar, 4)
            self.text(str(count), 12, TEXT, midright=(bar.right - 6, bar.centery))
            y += 22
        y += 18

        # Recent puzzles: theirs only for ones you've finished (no spoilers for ones you haven't).
        y = heading("RECENT DAILIES", y)
        recent = sorted(set(mine) | set(theirs), reverse=True)[:10]
        if not recent:
            y = self.paragraph("No %s dailies yet." % game_name, 15, MUTED, col, y)
        for n in recent:
            row = pygame.Rect(col.x - 4, y, col.w + 8, 30)
            self.rrect(PANEL, row, 8)
            self.text("#%d" % n, 14, MUTED, midleft=(row.x + 10, row.centery))
            self.text("You " + (score(mine[n]) if n in mine else "-"), 14, TEXT, bold=False,
                      center=(col.x + col.w * 0.42, row.centery))
            if n not in theirs:
                shown = "-"
            elif n in mine:
                shown = score(theirs[n])
            else:
                shown = "played"
            self.text("%s %s" % (short if len(short) <= 10 else short[:9] + ".", shown), 14, TEXT, bold=False,
                      center=(col.x + col.w * 0.76, row.centery))
            y += 34
        y += 26

        # Tucked away at the bottom: remove (asked in a popup, done at once).
        spot = self.text("Remove %s as a friend" % short, 14, MUTED, bold=False, center=(col.centerx, y + 10))
        if visible(spot):
            pygame.draw.line(self.screen, MUTED, (self.px(spot.x), self.px(spot.bottom)),
                             (self.px(spot.right), self.px(spot.bottom)), max(1, int(self.scale)))
            self.clickables.append((spot.inflate(24, 16), lambda now, f=view["id"], n=name: self.remove_friend(f, n, now),
                                    "button:Remove friend"))
        y += 40
        content_h = view["content_h"] = y + round(view["scroll"]) - area.y
        self.scroll_range(view, content_h - area.h)
        self.screen.set_clip(None)
        self.draw_scrollbar(area, area, content_h, view["scroll"])

    def friend_custom_games(self, makers):
        """This device's custom Wordles on a friend's words (`makers` = the friend's tags from the server):
        (unfinished games, newest first, {word: [finished games, newest first]}), so the friend page can open them again
        (Alex, Nov 2026). A link made before its maker ever synced has no tag, so only the link opens it."""
        tags = {t for t in makers if isinstance(t, str)} if isinstance(makers, list) else set()
        if not tags:
            return [], {}
        playing = sorted((g for g in self.history.custom.values() if g["custom"].get("by") in tags),
                         key=lambda g: g.get("started") or "", reverse=True)
        done = {}
        for g in sorted(self.history.games, key=lambda g: g.get("finished") or "", reverse=True):
            if g.get("custom") and g["custom"].get("by") in tags:
                done.setdefault(g["answers"][0], []).append(g)
        return playing, done

    def draw_friend_custom(self, games, name, short, col, y, visible, makers=None):
        """The friend page's custom Wordles: any of theirs you haven't finished (Continue), how each of you
        did on the other's words, then the latest (a row for a word of theirs you played opens that game)."""
        self.text("CUSTOM WORDLES", 12, MUTED, topleft=(col.x, y))
        y += 22
        playing, done = self.friend_custom_games(makers)
        for game in playing[:5]:
            spot = pygame.Rect(col.x, y, min(300, col.w), 42)
            if visible(spot):
                left = WORDLE_GUESSES - len(game["guesses"])
                self.button(spot, "Continue %s · %d left" % (custom_words.title({"from": short}), left),
                            lambda now, g=game: self.start("w", [g["answers"][0]], custom=g["custom"]),
                            size=15, primary=True, name="button:Continue custom")
            y = spot.bottom + 8
        if playing:
            y += 6
        if not games:
            y = self.paragraph("No custom Wordles between you yet. Tap Make a Wordle on the home screen to send "
                               "%s a word." % name, 15, MUTED, col, y)
            return y + 22
        theirs = [g for g in games if g["mine"]]  # (your words, which they played)
        yours = [g for g in games if not g["mine"]]

        def summary(played):
            if not played:
                return "none yet"
            wins = [len(g["guesses"]) for g in played if g["won"]]
            text = "solved %d of %d" % (len(wins), len(played))
            return text + (", avg %.1f" % (sum(wins) / len(wins)) if wins else "")
        y = self.paragraph("You on %s's words: %s" % (name, summary(yours)), 15, TEXT, col, y)
        y = self.paragraph("%s on your words: %s" % (name, summary(theirs)), 15, TEXT, col, y + 2)
        y += 8
        seen = {}
        for game in games[:10]:
            row = pygame.Rect(col.x - 4, y, col.w + 8, 30)
            self.rrect(PANEL, row, 8)
            saved = None
            if not game["mine"]:  # (the same word sent twice: the server's rows and ours are both newest first)
                i = seen[game["word"]] = seen.get(game["word"], -1) + 1
                mine = done.get(game["word"], [])
                saved = mine[i] if i < len(mine) else None
            if saved is not None and visible(row):
                self.clickables.append((row, lambda now, g=saved: self.start("w", record=g),
                                        "custom:" + game["word"]))
            self.text(game["word"].upper(), 14, TEXT, midleft=(row.x + 10, row.centery))
            who = "your word" if game["mine"] else "%s's word" % (short if len(short) <= 10 else short[:9] + ".")
            self.text(who, 13, MUTED, bold=False, center=(col.x + col.w * 0.42, row.centery))
            player = (short if len(short) <= 10 else short[:9] + ".") if game["mine"] else "You"
            self.text("%s %s" % (player, result_text(game, WORDLE_GUESSES)), 14, TEXT, bold=False,
                      center=(col.x + col.w * 0.78, row.centery))
            y += 34
        return y + 22

    def draw_friend_result(self, game, detail, col, y, limit):
        """A friend's finished daily like a shared result, without the words: Wordle's coloured rows
        (and which guesses had a hint or the word list), or the guess that solved each Quordle board."""
        detail = detail if isinstance(detail, dict) else {}
        won = game.get("won")
        text = "Solved in %d/%d" % (len(game["guesses"]), limit) if won else "Lost"
        helped = helped_guesses(game)
        if helped:
            text += " · help on %d guess%s" % (helped, "" if helped == 1 else "es")
        self.text(text, 16, SOLVED_TEXT if won else LOST_TEXT, topleft=(col.x, y))
        y += 28
        marks = detail.get("marks") if isinstance(detail.get("marks"), list) else []
        rows = detail.get("rows")
        boards = detail.get("boards")
        colors = {"g": TILE_COLORS["green"], "y": TILE_COLORS["yellow"], "b": TILE_COLORS["black"]}
        if isinstance(rows, list):
            size, gap = 24, 4
            for i, row in enumerate(rows):
                for j, letter in enumerate(str(row)[:5]):
                    self.rrect(colors.get(letter, TILE_COLORS["black"]),
                               (col.x + j * (size + gap), y, size, size), 4)
                note = {"hint": "hint", "list": "word list"}.get(marks[i] if i < len(marks) else "")
                if note:
                    self.text(note, 12, MUTED, bold=False, midleft=(col.x + 5 * (size + gap) + 6, y + size // 2))
                y += size + gap
        elif isinstance(boards, list):
            size = 46
            for i, solved in enumerate(boards[:4]):
                tile = pygame.Rect(col.x + (i % 2) * (size + 8), y + (i // 2) * (size + 8), size, size)
                self.rrect(TILE_COLORS["green"] if solved else TILE_COLORS["black"], tile, 8)
                self.text(str(solved) if solved else "X", 18, TEXT, center=tile.center)
            y += 2 * size + 8
            helped = [i + 1 for i, m in enumerate(marks) if m in ("hint", "list")]
            if helped:
                y = self.paragraph("Help on guess %s" % ", ".join(str(n) for n in helped), 12, MUTED, col, y + 6)
        return y

    # ----- game screen ---------------------------------------------------

    def draw_game(self, now):
        w, h = self.size
        header_h = 64
        self.draw_header(w, header_h)

        # Messages get their own strip under the header so they never cover a board.
        strip = pygame.Rect(16, header_h + 6, w - 32, 30)
        keyboard_h = self.keyboard_height(h, pygame.Rect(16, strip.bottom + 14, w - 32, h - 16 - strip.bottom - 28))
        keyboard = pygame.Rect(16, h - keyboard_h - 16, w - 32, keyboard_h)
        area = pygame.Rect(16, strip.bottom + 14, w - 32, keyboard.y - strip.bottom - 28)
        if self.daily is not None and self.festive():
            self.draw_game_festive(now, area, strip, keyboard)
        self.draw_boards(now, area)
        self.draw_message_strip(now, strip)

        # The words-left list and definitions take the keyboard's spot (like the result panel) so
        # the boards stay visible.
        if self.word_list:
            self.draw_word_list(keyboard)
        elif self.definition:
            self.draw_definition(keyboard)
        elif self.result_at is not None:
            self.draw_result(now, keyboard)
        else:
            self.draw_keyboard(keyboard)
        if self.celebrate is not None:
            # A daily solved on Thanksgiving: over everything for a couple of seconds, never a target.
            thanksgiving.draw_celebration(self.screen, self.scale, now - self.celebrate, w, h, keyboard.y - 3,
                                          area.center, BG)

    def draw_game_festive(self, now, area, strip, keyboard):
        """Thanksgiving on a daily puzzle: leaves behind everything, kept off the boards, the message strip
        and the keyboard (empty tiles are only outlines), and the turkey walking in the room between the
        boards and the keyboard, shrunk to fit (left out where there's too little)."""
        self.draw_leaves(now)
        boards, tile, _gap = self.board_layout(area)
        for rect in boards:
            # (a little wider for the "?" buttons and words-left counts beside each board)
            self.rrect(BG, rect.inflate(round(tile * 1.9) * 2, 8), 0)
        self.rrect(BG, strip.inflate(8, 8), 0)
        self.rrect(BG, keyboard.inflate(8, 8), 0)
        floor = keyboard.y - 3
        room = floor - max(rect.bottom for rect in boards) - 4
        size = min(1.0, room / thanksgiving.TURKEY_H)
        running = self.celebrate is not None and 0 <= now - self.celebrate < thanksgiving.RUN_MS
        if size * thanksgiving.TURKEY_H >= 24 and not running:  # (while it runs across, that's the turkey)
            turkey = thanksgiving.draw_turkey(self.screen, self.scale, now, 16, self.size[0] - 16, floor, size, BG,
                                              since_tap=self.since_turkey_tap(now))
            self.clickables.insert(0, (turkey, self.tap_turkey, "turkey:tap"))

    def keyboard_height(self, h, space):
        """The keyboard's height (also the result panel's and word list's). A tall screen (a phone) gets
        keys up to KEY_MAX_H tall, like the real Wordle's, but only from room the boards don't need:
        the tiles never get smaller for it (Quordle on a short screen keeps the old size).
        `space`: the boards' area plus the keyboard's, before they're split."""
        small = min(186, int(h * 0.25))
        big = min(3 * KEY_MAX_H + 2 * KEY_GAP, int(h * 0.22))
        if big <= small:
            return small
        grid = getattr(self, "board_grid", None)

        def tile(keyboard_h):
            return self.board_layout(pygame.Rect(space.x, space.y, space.w, space.h - keyboard_h))[1]

        try:
            needed = tile(small)
            for keyboard_h in range(big, small, -6):
                if tile(keyboard_h) >= needed:
                    return keyboard_h
            return small
        finally:
            if grid is not None:
                self.board_grid = grid

    def draw_word_list(self, panel):
        """Every answer that was still possible after one guess on one board, in place of the keyboard."""
        info = self.word_list
        board, row = info["board"], info["row"]
        words = self.game.possible_after(board, row + 1)
        guess = self.game.boards[board].history()[row][0]

        self.rrect(PANEL, panel, 14)
        where = "Board %d, after " % (board + 1) if len(self.game.boards) > 1 else "After "
        title = self.text(where + guess.upper(), 17, TEXT, topleft=(panel.x + 16, panel.y + 14))
        noun = "word" if len(words) == 1 else "words"
        self.text("%d possible %s" % (len(words), noun), 14, MUTED, bold=False,
                  midleft=(title.right + 12, title.centery))
        self.button((panel.right - 16 - 72, panel.y + 9, 72, 30), "Close", self.close_panel, size=14)

        area = self.scroll_area = pygame.Rect(panel.x + 16, panel.y + 48, panel.w - 40, panel.h - 48 - 8)
        col_w, line_h = 74, 24
        cols = max(1, area.w // col_w)
        col_w = area.w / cols
        lines = (len(words) + cols - 1) // cols
        content_h = lines * line_h
        scroll = self.scroll_range(info, content_h - area.h)

        self.screen.set_clip(self.px_rect(area))
        first = max(0, int(scroll // line_h))
        mouse = self.mouse()
        pickable = self.accepting_input()
        for n in range(first * cols, min(len(words), (first + area.h // line_h + 2) * cols)):
            word = words[n]
            x = area.x + (n % cols) * col_w
            y = area.y + (n // cols) * line_h - scroll
            cell = FRect(x - 6, y + 1, col_w - 6, line_h - 2)
            hit = cell.clip(area)
            chosen = self.typed == word
            hovered = pickable and hit.collidepoint(mouse)
            if chosen or hovered:
                self.rrect(ACCENT if chosen else BUTTON, cell, 6)
            self.text(word.upper(), 15, TEXT, bold=chosen, topleft=(x, y + 3))
            if pickable and hit.h > 0:
                # Clicking a word types it in, like a hint; Enter plays it.
                self.clickables.append((hit, lambda now, word=word: self.pick_word(word, now), "word:" + word))
        self.screen.set_clip(None)
        self.draw_scrollbar(panel, area, content_h, scroll)

    def draw_scrollbar(self, panel, area, content_h, scroll):
        """A scrollbar at the panel's right edge when the content is taller than its area."""
        if content_h > area.h:
            track = pygame.Rect(panel.right - 12, area.y, 4, area.h)
            thumb_h = max(24, area.h * area.h / content_h)
            top = content_h - area.h
            past = max(-scroll, scroll - top, 0)  # (past an end: the thumb squeezes, like iOS)
            thumb_h = max(10, thumb_h - past)
            at = max(0, min(1, scroll / top))
            thumb = FRect(track.x, area.y + (area.h - thumb_h) * at, 4, thumb_h)
            self.rrect(BUTTON, track, 2)
            self.rrect(MUTED, thumb, 2)

    def draw_definition(self, panel):
        """What a guessed word means, in place of the keyboard."""
        info = self.definition
        definition = define(info["word"])
        self.rrect(PANEL, panel, 14)
        title = self.text(info["word"].upper(), 17, TEXT, topleft=(panel.x + 16, panel.y + 14))
        if self.speak_words():
            # A speaker after the word: tap either to hear it again.
            icon = pygame.Rect(title.right + 8, 0, 20, 18)
            icon.centery = title.centery
            hit = title.union(icon).inflate(12, 14)
            self.draw_speaker(icon, TEXT if hit.collidepoint(self.mouse()) else MUTED)
            word = info["word"]
            self.clickables.append((hit, lambda now: self.say(word), "say:" + word))
            self.say_targets.append((hit, word))
            title = title.union(icon)
        if definition.base:
            # "plural of bird", trimmed so it never runs under the Close button.
            note = definition.note
            room = panel.right - 16 - 72 - 12 - (title.right + 12)
            while note and self.fonts.get(14 * self.scale, False).size(note)[0] > room * self.scale:
                note = note[:-2].rstrip() + "…"
            self.text(note, 14, MUTED, bold=False, midleft=(title.right + 12, title.centery))
        self.button((panel.right - 16 - 72, panel.y + 9, 72, 30), "Close", self.close_panel, size=14)

        area = self.scroll_area = pygame.Rect(panel.x + 16, panel.y + 48, panel.w - 40, panel.h - 48 - 8)
        size, line_h, label_w = 15, 20, 98
        if not definition.found:
            message = ("No definition in the game's dictionary. It has every possible answer and "
                       "most other words, but not every rare one.")
            for n, line in enumerate(self.wrap(message, 14, area.w)):
                self.text(line, 14, MUTED, bold=False, topleft=(area.x, area.y + n * line_h))
            return
        # Lay out every sense: its part of speech in a narrow column, the meaning wrapped beside it,
        # and an example sentence (if there is one) under the meaning.
        lines = []  # (y, x, text, color)
        y, last_pos = 0, None
        for pos, meaning, example in definition.senses:
            if pos and pos != last_pos:  # "verb" once for a run of verb meanings
                lines.append((y, 0, pos, MUTED))
            last_pos = pos
            for line in self.wrap(meaning, size, area.w - label_w):
                lines.append((y, label_w, line, TEXT))
                y += line_h
            if example:
                for line in self.wrap("\u201c%s\u201d" % example, size, area.w - label_w):
                    lines.append((y, label_w, line, MUTED))
                    y += line_h
            y += 8
        content_h = y - 8
        scroll = self.scroll_range(info, content_h - area.h)

        self.screen.set_clip(self.px_rect(area))
        for line_y, x, line, color in lines:
            top = area.y + line_y - scroll
            if area.y - line_h < top < area.bottom:
                self.text(line, size if x else 14, color, bold=False, topleft=(area.x + x, top + (0 if x else 1)))
        self.screen.set_clip(None)
        self.draw_scrollbar(panel, area, content_h, scroll)

    def draw_speaker(self, rect, color):
        """A small speaker with two sound waves, in rect (points)."""
        x, y, w, h = rect
        cy = y + h / 2
        body = [(x, cy - h * 0.18), (x + w * 0.2, cy - h * 0.18), (x + w * 0.45, y + h * 0.05),
                (x + w * 0.45, y + h * 0.95), (x + w * 0.2, cy + h * 0.18), (x, cy + h * 0.18)]
        pygame.draw.polygon(self.screen, color, [(self.px(px), self.px(py)) for px, py in body])
        for reach in (0.28, 0.5):
            r = h * reach
            arc = pygame.Rect(0, 0, self.px(2 * r), self.px(2 * r))
            arc.center = (self.px(x + w * 0.45), self.px(cy))
            pygame.draw.arc(self.screen, color, arc, -0.9, 0.9, max(1, self.px(1.6)))

    def wrap(self, text, size, width, bold=False):
        """Split text into lines that fit width points at this font size."""
        key = (text, size, round(width), bold, self.scale)
        lines = self.wrap_cache.get(key)
        if lines is None:
            font = self.fonts.get(size * self.scale, bold)
            lines, line = [], ""
            for word in text.split():
                trial = line + " " + word if line else word
                if line and font.size(trial)[0] > width * self.scale:
                    lines.append(line)
                    line = word
                else:
                    line = trial
            lines.append(line)
            if len(self.wrap_cache) > 300:
                self.wrap_cache.clear()
            self.wrap_cache[key] = lines
        return lines

    def draw_header(self, w, h):
        game = self.game
        bw = 84 if w >= 640 else 62
        self.button((16, 14, bw, 36), "Home", lambda now: self.go_to_menu(), size=16)
        # A new practice game. On a daily it says so ("New" there read as a new daily; Alex, Nov 2026).
        label, nw, size = ("New", bw, 16) if self.daily is None else (("Practice", bw, 16) if bw >= 84 else
                                                                      ("Practice", bw + 14, 15))
        self.button((w - 16 - nw, 14, nw, 36), label, lambda now: self.new_game(), size=size)
        if not self.accepting_input():
            self.hint_picker = False
        # "Solve" once the answer is certain (one board left, one word possible): it fills in the answer.
        # While tiles flip and once the game is over it keeps what it said before the last guess, so a
        # game won from "Solve" ends on a greyed-out "Solve", not "Hint" (Alex, Nov 2026). Only with Answers
        # remaining shown in Settings (solving()): otherwise "Solve" would say one word is left.
        solve = self.show_counts() and (game.known_answer() if self.accepting_input()
                                        else game.known_before_last()) is not None
        hint_rect = self.hint_rect = self.button((w - 24 - nw - bw, 14, bw, 36), "Solve" if solve else "Hint",
                                                 self.hint_button, size=16, primary=self.hint_picker,
                                                 enabled=self.accepting_input() and not self.thinking)
        self.hint_hover = (len(game.boards) > 1 and self.accepting_input() and not self.thinking and not solve
                           and not self.hint_picker and hint_rect.collidepoint(self.mouse()))

        name = "WORDLE" if self.mode == "w" else "QUORDLE"
        if self.daily is not None:
            name += " #%d" % self.daily
        title = self.text(name, 26, TEXT, center=(w // 2, 25))
        if self.release:
            self.draw_release_badge((title.right + 8, title.centery), "midleft")
        if game.over:
            status = ""
        elif game.remaining_guesses == 1:
            status = "1 guess left. Don't get nervous!"
        else:
            status = "%d guesses left" % game.remaining_guesses
        if self.daily is None:  # (a daily shows its number in the title; say when it's practice or a replay)
            kind = ("Your Wordle" if self.own_word else custom_words.title(self.custom) if self.custom
                    else "Replay" if self.replay else "Practice")
            status = kind + " · " + status if status else kind
        if status:
            self.text(status, 14, MUTED, bold=False, center=(w // 2, 50))
        self.rrect(EMPTY_BORDER, (0, h, w, 1), 0)

    def draw_message_strip(self, now, strip):
        """The hint chooser if it's open, else the newest message, else a quiet line about what's hovered."""
        if self.hint_picker:
            self.draw_hint_picker(strip)
            return
        # The Answers left switch sits at the strip's right end. Messages stay centered when they clear
        # it, else they center in the room left of it.
        switch = self.draw_counts_switch(strip)
        room = pygame.Rect(strip.x, strip.y, switch.x - 8 - strip.x, strip.h)
        live = [t for t in self.toasts if now - t[1] < t[2]]
        if live:
            text, start, duration = live[-1]
            pill = self.make_pill(text, room.w)
            fade = duration - (now - start)
            if fade < 300:
                pill.set_alpha(int(255 * fade / 300))
            centered = pill.get_rect(center=self.px_rect(strip).center)
            if centered.right > self.px(room.right):
                centered = pill.get_rect(center=self.px_rect(room).center)
            self.screen.blit(pill, centered)
            return
        if self.thinking:
            label = "Thinking..."
        elif self.hint_hover:
            label = "Hint: choose all boards or just one"
        elif self.own_word and not self.game.over:
            # (your own custom Wordle: you know the word, so it's never saved; the result panel says so too)
            fits = [t for t in OWN_WORD_STRIP if self.fonts.render(t, 14 * self.scale, MUTED, bold=False).get_width()
                    / self.scale <= room.w]
            if not fits:
                return
            centered = pygame.Rect(0, 0, self.fonts.render(fits[0], 14 * self.scale, MUTED, bold=False).get_width()
                                   / self.scale, strip.h)
            centered.center = strip.center
            self.text(fits[0], 14, MUTED, bold=False, center=strip.center if centered.right <= room.right
                      else room.center)
            return
        else:
            return
        self.text(label, 14, MUTED, bold=False, center=strip.center)

    def draw_counts_switch(self, strip):
        """The game screen's Answers left switch (target "button:Answers left"): shows or hides the
        answers-remaining numbers for this game only; Settings keeps the default (toggle_game_counts)."""
        on = self.show_counts()
        size = 13
        label_w = self.fonts.render("Answers left", size * self.scale, MUTED).get_width() / self.scale
        track_w, track_h = 28, 16
        rect = pygame.Rect(0, 0, round(label_w + track_w + 30), 28)
        rect.midright = (strip.right, strip.centery)
        if rect.collidepoint(self.mouse()):
            self.rrect(BUTTON, rect, rect.h // 2)
        else:
            self.rrect(EMPTY_BORDER, rect, rect.h // 2, 1.5)
        self.text("Answers left", size, TEXT if on else MUTED, midleft=(rect.x + 11, rect.centery))
        track = pygame.Rect(rect.right - 10 - track_w, rect.centery - track_h // 2, track_w, track_h)
        self.rrect(ACCENT if on else EMPTY_BORDER, track, track_h // 2)
        knob = pygame.Rect(0, 0, track_h - 4, track_h - 4)
        knob.center = (track.right - track_h // 2 if on else track.x + track_h // 2, track.centery)
        self.rrect(TEXT if on else MUTED, knob, knob.h // 2)
        self.clickables.append((rect.inflate(4, 6), lambda now: self.toggle_game_counts(), "button:Answers left"))
        return rect

    def draw_hint_picker(self, strip):
        """Hint for: [All boards] [1] [2] [3] [4] [Cancel], centered in the message strip."""
        h = 28
        items = [("All boards", 96, lambda now: self.pick_hint(now), True)]
        for i, board in enumerate(self.game.boards):
            items.append((str(i + 1), 38, lambda now, i=i: self.pick_hint(now, i), not board.solved))
        items.append(("Cancel", 72, lambda now: setattr(self, "hint_picker", False), True))
        label_w, gap = 66, 6
        total = label_w + sum(width for _, width, _, _ in items) + gap * len(items)
        x = strip.centerx - total // 2
        self.text("Hint for", 14, MUTED, bold=False, midleft=(x, strip.centery))
        x += label_w + gap
        for label, width, action, enabled in items:
            self.button((x, strip.centery - h // 2, width, h), label, action, size=14,
                        primary=label == "All boards", enabled=enabled)
            x += width + gap

    def board_layout(self, area):
        game = self.game
        n, rows, cols = len(game.boards), game.max_guesses, game.word_length
        gap_ratio, board_gap = 0.12, 26
        count_ratio = 1.0  # room right of each board for the "words left" counts, in tiles
        define_ratio = 0.8  # room left of each board for the "?" (definition) buttons, in tiles
        cap = 66 if n == 1 else 46
        grids = [(1, 1)] if n == 1 else [(2, 2), (4, 1)]

        best = None
        for gx, gy in grids:
            tile_w = (area.w - board_gap * (gx - 1)) / gx / (cols + gap_ratio * (cols - 1) + count_ratio + define_ratio)
            tile_h = (area.h - board_gap * (gy - 1)) / gy / (rows + gap_ratio * (rows - 1))
            tile = int(min(tile_w, tile_h, cap))
            # Prefer the 2x2 grid unless the single row gives clearly bigger tiles.
            if best is None or tile > best[0] * 1.15:
                best = (tile, gx, gy)
        tile, gx, gy = best

        gap = max(3, round(tile * gap_ratio))
        board_w = cols * tile + (cols - 1) * gap
        board_h = rows * tile + (rows - 1) * gap
        count_w = round(tile * count_ratio)
        define_w = round(tile * define_ratio)
        slot_w = define_w + board_w + count_w
        total_w = gx * slot_w + (gx - 1) * board_gap
        total_h = gy * board_h + (gy - 1) * board_gap
        # Wordle keeps its board centered with the buttons hanging off the sides; Quordle centers
        # each "?" + board + counts slot.
        x0 = area.centerx - (board_w // 2 if n == 1 else total_w // 2 - define_w)
        y0 = area.centery - total_h // 2
        rects = [pygame.Rect(x0 + (i % gx) * (slot_w + board_gap), y0 + (i // gx) * (board_h + board_gap),
                             board_w, board_h) for i in range(n)]
        self.board_grid = (gx, gy)
        return rects, tile, gap

    def bouncing(self, board_index, now):
        start = self.bounces.get(board_index)
        return start is not None and now - start < BOUNCE_MS + BOUNCE_STAGGER_MS * self.game.word_length

    def board_done(self, board_index):
        """Solved, and its winning row has finished flipping."""
        revealing = self.reveal is not None and board_index in self.reveal["rows"]
        return self.game.boards[board_index].solved and not revealing

    def draw_boards(self, now, area):
        rects, tile, gap = self.board_layout(area)
        multi = len(rects) > 1
        mouse = self.mouse()
        hint = self.shown_hint if self.shown_hint and self.typed == self.shown_hint.word else None
        if hint is None:
            self.shown_hint = None
        for i, (board, rect) in enumerate(zip(self.game.boards, rects)):
            hit = rect.inflate(gap * 2 + 10, gap * 2 + 10)
            if multi and self.accepting_input() and not board.solved:
                thinking_here = self.thinking and self.thinking["board"] == i
                if self.hint_picker or thinking_here:
                    # While choosing a hint, every open board is a target (tap one for a hint on just it).
                    self.rrect(PANEL, hit, 12)
                    if self.hint_picker and hit.collidepoint(mouse):
                        self.rrect(TYPED_BORDER, hit, 12, 2)
                if self.hint_picker:
                    self.clickables.append((hit, lambda now, i=i: self.pick_hint(now, i), "board:%d" % (i + 1)))
            if multi and hint and i in (hint.sure_boards or hint.possible):
                # Outline the boards the hint in the typed row was chosen for.
                self.rrect(ACCENT, hit, 12, 2)

            self.draw_board(now, i, board, rect, tile, gap)

            # Dim finished boards while play continues; show everything at full strength once it's over.
            if multi and self.board_done(i) and not self.bouncing(i, now) and self.result_at is None:
                area_px = self.px_rect(rect.inflate(8, 8))
                shade = pygame.Surface(area_px.size, pygame.SRCALPHA)
                shade.fill(BG + (150,))
                self.screen.blit(shade, area_px)

    def draw_board(self, now, board_index, board, rect, tile, gap):
        game = self.game
        rows = board.rows()
        reveal_row = self.reveal["rows"].get(board_index) if self.reveal else None
        input_row = len(rows) if not board.solved and not game.over else None

        shake = 0
        if self.shake_start is not None:
            p = (now - self.shake_start) / SHAKE_MS
            if p < 1:
                shake = math.sin(p * math.pi * 6) * tile * 0.18 * (1 - p)
            else:
                self.shake_start = None

        for r in range(game.max_guesses):
            y = rect.y + r * (tile + gap)
            for c in range(game.word_length):
                cell = pygame.Rect(rect.x + c * (tile + gap), y, tile, tile)
                if r < len(rows):
                    letter, color = rows[r][c]
                    if r == reveal_row:
                        p = clamp01((now - self.reveal["start"] - c * self.flip_ms(FLIP_STAGGER_MS)) / self.flip_ms(FLIP_MS))
                        if p <= 0:
                            self.draw_tile(cell, letter, "typed")
                        else:
                            self.draw_tile(cell, letter, "typed" if p < 0.5 else color,
                                           scale_y=abs(math.cos(math.pi * p)) if p < 1 else 1)
                    else:
                        if r == len(rows) - 1 and self.bouncing(board_index, now):
                            p = clamp01((now - self.bounces[board_index] - c * BOUNCE_STAGGER_MS) / BOUNCE_MS)
                            cell = cell.move(0, -math.sin(math.pi * p) * tile * 0.3)
                        self.draw_tile(cell, letter, color)
                elif r == input_row:
                    letter = self.typed[c] if c < len(self.typed) else ""
                    scale = 1.0
                    if self.pop and self.pop[0] == c:
                        p = (now - self.pop[1]) / POP_MS
                        if p < 1:
                            scale = 1 + 0.1 * math.sin(math.pi * p)
                    self.draw_tile(cell.move(shake, 0), letter, "typed" if letter else "empty", scale=scale)
                else:
                    self.draw_tile(cell, "", "empty")

            if r < len(rows) and r != reveal_row:
                if self.show_counts():
                    self.draw_count(board_index, r, rect.right + gap, y, tile)
                self.draw_define(board_index, r, rect.x - gap, y, tile)

    def draw_define(self, board_index, row, right, y, tile):
        """A small "?" button left of a guessed row that shows what its word means."""
        size = min(18, max(11, round(tile * 0.42)))
        button = pygame.Rect(0, 0, size + 8, size + 8)
        button.midright = (right, y + tile // 2)
        hovered = button.collidepoint(self.mouse())
        active = self.definition and (self.definition["board"], self.definition["row"]) == (board_index, row)
        if active or hovered:
            self.rrect(ACCENT if active else BUTTON, button, button.h // 2)
        else:
            self.rrect(EMPTY_BORDER, button, button.h // 2, 1.5)
        self.text("?", size - 1, TEXT if active or hovered else MUTED, center=button.center)
        self.clickables.append((button.inflate(4, 4), lambda now: self.open_definition(board_index, row),
                                "define:%d:%d" % (board_index + 1, row + 1)))
        if not active and self.speak_words():
            self.say_targets.append((button.inflate(4, 4), self.game.boards[board_index].history()[row][0]))

    def draw_count(self, board_index, row, x, y, tile):
        """How many answers were still possible after this row's guess; click to list them."""
        count = len(self.game.possible_after(board_index, row + 1))
        size = min(18, max(11, round(tile * 0.42)))
        label = str(count)
        text_w = self.fonts.render(label, size * self.scale, MUTED).get_width() / self.scale
        pill = pygame.Rect(x, 0, max(text_w + 10, size * 1.7), size + 8)
        pill.centery = y + tile // 2
        hovered = pill.collidepoint(self.mouse())
        active = self.word_list and (self.word_list["board"], self.word_list["row"]) == (board_index, row)
        if active or hovered:
            self.rrect(ACCENT if active else BUTTON, pill, pill.h // 2)
        self.text(label, size, TEXT if active or hovered else MUTED, center=pill.center)
        self.clickables.append((pill.inflate(4, 4), lambda now: self.open_word_list(board_index, row),
                                "count:%d:%d" % (board_index + 1, row + 1)))

    def key_colors(self):
        """For each board, letter -> best color seen so far (ignoring tiles still flipping)."""
        result = []
        for i, board in enumerate(self.game.boards):
            rows = board.rows()
            if self.reveal and i in self.reveal["rows"]:
                rows = rows[:self.reveal["rows"][i]]
            colors = {}
            for row in rows:
                for letter, color in row:
                    if PRIORITY[color] > PRIORITY[colors.get(letter, "gray")]:
                        colors[letter] = color
            result.append(colors)
        return result

    def draw_keyboard(self, area):
        gap = KEY_GAP
        key_h = int(min(KEY_MAX_H, (area.h - 2 * gap) / 3))
        width = min(area.w, 640)
        key_w = (width - 9 * gap) / 10
        top = area.bottom - 3 * key_h - 2 * gap
        colors = self.key_colors()
        enabled = self.accepting_input()

        for r, row in enumerate(KEY_ROWS):
            widths = [key_w * 1.55 if k in ("enter", "back") else key_w for k in row]
            x = area.centerx - (sum(widths) + gap * (len(row) - 1)) / 2
            y = top + r * (key_h + gap)
            for key, key_width in zip(row, widths):
                rect = pygame.Rect(round(x), y, round(key_width), key_h)
                self.draw_key(rect, key, colors, enabled)
                x += key_width + gap

    def draw_key(self, rect, key, colors, enabled):
        hovered = enabled and rect.collidepoint(self.mouse())
        radius = 8

        def shade(color):
            return lighten(color, 0.14) if hovered else color

        if key in ("enter", "back"):
            self.rrect(shade(KEY), rect, radius)
            self.text("ENTER" if key == "enter" else "DEL", min(16 if rect.h <= 58 else 18, rect.h * 0.3), TEXT,
                      center=rect.center)
            action = self.submit if key == "enter" else self.backspace
        else:
            boards = self.game.boards
            # In Quordle, a finished board's slice goes back to plain once its last row has flipped.
            per_board = [None if len(boards) > 1 and self.board_done(i) else colors[i].get(key)
                         for i in range(len(boards))]
            if len(boards) == 1:
                self.rrect(shade(key_color(per_board[0])), rect, radius)
            else:
                # One slice per board, laid out like the boards on screen.
                gx, gy = self.board_grid
                for i, color in enumerate(per_board):
                    cx, cy = i % gx, i // gx
                    x0, x1 = rect.x + rect.w * cx // gx, rect.x + rect.w * (cx + 1) // gx
                    y0, y1 = rect.y + rect.h * cy // gy, rect.y + rect.h * (cy + 1) // gy
                    self.rrect(
                        shade(key_color(color)), (x0, y0, x1 - x0, y1 - y0), 0,
                        border_top_left_radius=radius if cx == 0 and cy == 0 else 0,
                        border_top_right_radius=radius if cx == gx - 1 and cy == 0 else 0,
                        border_bottom_left_radius=radius if cx == 0 and cy == gy - 1 else 0,
                        border_bottom_right_radius=radius if cx == gx - 1 and cy == gy - 1 else 0,
                    )
            # Dim the letter when it's ruled out everywhere it still matters.
            live = [c for c in per_board if c is not None] or per_board
            ruled_out = all(c == "black" for c in live)
            # (keys of the old size, a computer's, keep the old letters; a phone's taller keys get bigger ones)
            self.text(key.upper(), min(22 if rect.h <= 58 else 28, rect.h * 0.4), KEY_RULED_OUT_TEXT if ruled_out else TEXT,
                      center=rect.center)
            action = lambda now, key=key: self.type_letter(key, now)

        if enabled:
            self.clickables.append((rect, action, "key:" + key))

    def draw_result(self, now, area):
        game = self.game
        slide = ease_out(clamp01((now - self.result_at) / RESULT_SLIDE_MS))
        card = area.move(0, int((1 - slide) * 30))
        self.rrect(PANEL, card, 18)

        used = len(game.guesses)
        if game.won:
            if len(game.boards) == 1:
                title, detail = win_message(game), "Solved in %d of %d guesses" % (used, game.max_guesses)
            else:
                title, detail = "All four solved!", "Finished with %d guesses to spare" % game.remaining_guesses
        else:
            solved = sum(board.solved for board in game.boards)
            title = "Out of guesses"
            if len(game.boards) == 1:
                detail = "The word was %s" % game.words[0].upper()
            else:
                detail = "Solved %d of 4.  Answers: %s" % (solved, "  ".join(
                    "%d %s" % (i + 1, word.upper()) for i, word in enumerate(game.words)))

        # A taller panel (the bigger keyboard's spot on a phone) gets bigger, wider buttons, and the
        # whole lot centered in it; a computer keeps the old 150 x 38 (wider there looked squat: Alex).
        gap = 12
        grow = max(0, min(10, (card.h - 186) // 4))
        bh = 38 + grow
        bw = int(max(150, min(150 + grow * 2.2, (card.w - 40 - 2 * gap) // 3)))
        size = 17 if bh >= 46 else 16
        top = card.y + max(0, (card.h - (72 + 2 * bh + 8 + 30)) // 2)
        note = OWN_WORD_NOTE if self.own_word else REPLAY_NOTE if self.replay else None
        note_below = note and card.bottom - (top + 72 + 2 * bh + 8) > 24
        if note and not note_below:
            detail = note  # (no room for it under the buttons: it matters more than the guess count here)

        self.text(title, 26, TEXT, center=(card.centerx, top + 28))
        self.text(detail, 15, MUTED, bold=False, center=(card.centerx, top + 54))

        row_w = 3 * bw + 2 * gap
        x, y = card.centerx - row_w // 2, top + 72
        # Three share buttons lined up with the row under them (the spoilers one's target keeps its old name)
        plain = self.button((x, y, bw, bh), "Share", lambda now: self.share(False, now, clicked=True), size=size,
                            primary=True)
        spoilers = self.button((x + bw + gap, y, bw, bh), "Share spoilers",
                               lambda now: self.share(True, now, clicked=True), size=size,
                               name="button:Share with spoilers")
        counts = self.button((x + 2 * (bw + gap), y, bw, bh), "Share counts",
                             lambda now: self.share_counts(now, clicked=True), size=size)
        self.share_targets = [(plain, self.share_message(False)), (spoilers, self.share_message(True)),
                              (counts, self.counts_message())]

        y += bh + 8
        if self.daily is not None:
            buttons = [("Stats", lambda now: self.open_stats(self.mode, "daily")),
                       ("Archive", lambda now: self.open_archive(self.mode)),
                       ("Home", lambda now: self.go_to_menu())]
            shortcuts = "S: share   Enter: stats   A: archive   Esc: home"
        else:
            replay = "Replay word" if len(game.words) == 1 else "Replay words"
            buttons = [("New game", lambda now: self.new_game()),
                       (replay, lambda now: self.start(self.mode, self.words, replay=True)),
                       ("Home", lambda now: self.go_to_menu())]
            shortcuts = "Enter: new game   R: replay   S: share   Esc: home"
        for i, (label, action) in enumerate(buttons):
            self.button((x + i * (bw + gap), y, bw, bh), label, action, size=size)
        y += bh
        if note_below:
            self.text(note, 13, MUTED, bold=False, center=(card.centerx, y + 17))
            y += 22
        if card.bottom - y > 24 and not self.touch:  # keyboard shortcuts: no keyboard on a phone
            self.text(shortcuts, 13, MUTED, bold=False, center=(card.centerx, y + 17))

    def draw_toasts(self, now):
        """Floating messages for the menu (the game screen shows them in its message strip)."""
        self.toasts = [t for t in self.toasts if now - t[1] < t[2]]
        if self.release and self.scene == "menu":
            self.draw_release_badge((self.size[0] - 16, 16), "topright")
        if self.scene == "game":
            return
        w, y = self.size[0], 20
        for text, start, duration in self.toasts:
            pill = self.make_pill(text, w - 32)
            fade = duration - (now - start)
            if fade < 300:
                pill.set_alpha(int(255 * fade / 300))
            self.screen.blit(pill, pill.get_rect(midtop=(self.px(w / 2), self.px(y))))
            y += pill.get_height() / self.scale + 8

    def draw_release_badge(self, at, anchor):
        """A small orange "UAT" tag so the testing site is never mistaken for the real one."""
        label = self.fonts.render(self.release, 12 * self.scale, TEXT)
        badge = pygame.Rect(0, 0, label.get_width() / self.scale + 12, 20)
        setattr(badge, anchor, at)
        self.rrect(UAT_COLOR, badge, 6)
        self.text(self.release, 12, TEXT, center=badge.center)

    def make_pill(self, text, max_w):
        """A message pill in pixels, shrinking the font if needed so it fits max_w points."""
        size = 16
        while True:
            label = self.fonts.render(text, size * self.scale, DARK_TEXT)
            if label.get_width() + self.px(30) <= self.px(max_w) or size <= 11:
                break
            size -= 1
        pill = pygame.Surface((label.get_width() + self.px(30), self.px(28)), pygame.SRCALPHA)
        pygame.draw.rect(pill, TEXT, pill.get_rect(), border_radius=pill.get_height() // 2)
        pill.blit(label, label.get_rect(center=pill.get_rect().center))
        return pill

if __name__ == "__main__":
    App().run()
