"""Graphical version of the game, built with pygame.

Run:  .venv/bin/python gui.py      (one-time setup: pip install -r requirements.txt)
The terminal version (python3 main.py) still works without pygame.

Controls: type letters, Enter to guess, Backspace to delete. The Hint button fills in the
guess that narrows things down the most; press Enter to play it. In Quordle, Hint first asks
which: all boards (1 guess for every unsolved board) or one board (also: keys 1-4, or tap a board
while choosing). Boards never give a hint from a tap alone. Next to each guessed row: "?" (left) shows what the
word means, and the count (right) lists the answers still possible.

The menu offers today's daily puzzle (the same words for everyone that day, see daily.py) or
practice games, plus stats and an archive of past daily puzzles. Games are saved on the device
(history.py); a daily puzzle in progress picks up where it was left. After a game, Share copies the
result (or opens the phone's share sheet), with or without the words (share.py). Once the server is
set up (sync.py), the Sync screen links devices so they all show the same games.
"""
import asyncio
import datetime
import json
import math
import os
import random
import sys
import threading

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
try:
    import pygame
except ImportError:
    sys.exit("The GUI needs pygame: pip install -r requirements.txt\n"
             "(or play the terminal version with: python3 main.py)")

import daily
from Board import PRIORITY
from definitions import define
from Game import QUORDLE_GUESSES, WORDLE_GUESSES, Game, InvalidGuess, board_names
from history import History, default_storage
from share import PROD_LINK, share_text
from Solver import Solver
from seeding import seed_random
from sync import Sync, default_transport, format_code, friend_games, friend_summary
from words import load_dictionary, load_word_bank

# Running in a web browser (built with pygbag, see web/). No threads, no system fonts there.
WEB = sys.platform == "emscripten"
WEB_WIDTH = 600  # points; the page scales the canvas to fit the browser window
WEB_STATUS_BLUR = 40  # CSS px below the iPhone status bar that iOS blurs in home-screen web apps
UAT_COLOR = (230, 120, 40)  # the testing site's badge and icon background

WINDOW_SIZE = (740, 840)
MIN_SIZE = (520, 640)
FPS = 60

# Palette
BG = (21, 25, 36)
PANEL = (33, 38, 54)
TEXT = (236, 239, 244)
DARK_TEXT = (21, 25, 36)
MUTED = (140, 148, 170)
EMPTY_BORDER = (50, 56, 76)
TYPED_BORDER = (112, 120, 146)
KEY = (104, 112, 138)             # keyboard: letter not guessed yet (clearly lighter than...)
KEY_RULED_OUT = (33, 37, 50)       # ...a letter ruled out, which looks switched off
KEY_RULED_OUT_TEXT = (98, 105, 126)
BUTTON = (50, 57, 80)
ACCENT = (46, 160, 107)
SOLVED_TEXT = (96, 200, 145)  # "Solved in 4/6" on the menu and in the archive
ERROR_TEXT = (238, 150, 100)  # "That code didn't work" on the Sync screen
TILE_COLORS = {
    "green": (46, 160, 107),
    "yellow": (222, 168, 52),
    "black": (56, 60, 76),
}

# Animation timings (milliseconds)
FLIP_MS = 280
FLIP_STAGGER_MS = 140
POP_MS = 110
SHAKE_MS = 450
BOUNCE_MS = 420
BOUNCE_STAGGER_MS = 80
TOAST_MS = 1800
HINT_TOAST_MS = 4500
RESULT_SLIDE_MS = 300
UNDO_MS = 5000  # how long Unlink, Remove friend, Stop sharing and Delete wait for an Undo

KEY_ROWS = [list("qwertyuiop"), list("asdfghjkl"), ["enter"] + list("zxcvbnm") + ["back"]]

WIN_MESSAGES = {1: "Unreal!", 2: "Brilliant!", 3: "Superb!", 4: "Nice work!", 5: "Solid!", 6: "Phew, close one!"}


def clamp01(x):
    return max(0.0, min(1.0, x))


def ease_out(p):
    return 1 - (1 - p) ** 3


def lighten(color, amount):
    return tuple(min(255, int(v + (255 - v) * amount)) for v in color)


ICON_LETTERS = "ALEX"
APP_NAME = "Wordle"


def set_macos_app_name(name):
    """Show `name` instead of "Python" in the macOS menu bar.

    The game runs inside Python.app, so macOS uses that bundle's name. Changing the name in the
    bundle's info dictionary before the window (and NSApplication) exists makes the menu bar use
    ours. Uses ctypes to call the Objective-C runtime, so it needs no extra packages. Best effort:
    any failure just leaves the name as "Python".
    """
    if sys.platform != "darwin":
        return
    try:
        import ctypes
        import ctypes.util

        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        ctypes.cdll.LoadLibrary(ctypes.util.find_library("Foundation"))
        objc.objc_getClass.restype = ctypes.c_void_p
        objc.objc_getClass.argtypes = [ctypes.c_char_p]
        objc.sel_registerName.restype = ctypes.c_void_p
        objc.sel_registerName.argtypes = [ctypes.c_char_p]
        msg_send = ctypes.cast(objc.objc_msgSend, ctypes.c_void_p).value

        def send(receiver, selector, *args, restype=ctypes.c_void_p, argtypes=()):
            # objc_msgSend must be called through a prototype matching each call (required on Apple silicon).
            fn = ctypes.CFUNCTYPE(restype, ctypes.c_void_p, ctypes.c_void_p, *argtypes)(msg_send)
            return fn(receiver, objc.sel_registerName(selector), *args)

        def ns_string(text):
            return send(objc.objc_getClass(b"NSString"), b"stringWithUTF8String:", text.encode(),
                        argtypes=(ctypes.c_char_p,))

        bundle = send(objc.objc_getClass(b"NSBundle"), b"mainBundle")
        info = send(bundle, b"infoDictionary")
        if info:
            send(info, b"setObject:forKey:", ns_string(name), ns_string("CFBundleName"),
                 restype=None, argtypes=(ctypes.c_void_p, ctypes.c_void_p))
    except Exception:
        pass


def make_icon(fonts, size=512, full_bleed=False, background=BG):
    """App icon drawn in code: a 2x2 grid of game tiles spelling ICON_LETTERS on a dark rounded square.

    full_bleed: an opaque square with no border, for phones (iOS rounds the corners itself and
    turns transparent corners black). background: UAT_COLOR for the testing site's icon."""
    icon = pygame.Surface((size, size), pygame.SRCALPHA)
    if full_bleed:
        body = icon.get_rect()
        icon.fill(background)
    else:
        margin = round(size * 0.09)  # macOS icons leave a little transparent border
        body = pygame.Rect(margin, margin, size - 2 * margin, size - 2 * margin)
        pygame.draw.rect(icon, BG, body, border_radius=round(body.w * 0.22))
        pygame.draw.rect(icon, EMPTY_BORDER, body, max(2, size // 128), border_radius=round(body.w * 0.22))

    gap = round(body.w * 0.06)
    tile = (body.w - 2 * round(body.w * 0.13) - gap) // 2
    x0 = body.centerx - tile - gap // 2
    y0 = body.centery - tile - gap // 2
    for i, (letter, color) in enumerate(zip(ICON_LETTERS, ("green", "yellow", "black", "green"))):
        cell = pygame.Rect(x0 + (i % 2) * (tile + gap), y0 + (i // 2) * (tile + gap), tile, tile)
        pygame.draw.rect(icon, TILE_COLORS[color], cell, border_radius=round(tile * 0.16))
        label = fonts.render(letter, tile * 0.62, TEXT)
        icon.blit(label, label.get_rect(center=cell.center))
    return icon


def key_color(state):
    """Keyboard color for a letter's state on a board (None/"gray" = not guessed yet)."""
    if state == "black":
        return KEY_RULED_OUT
    return TILE_COLORS.get(state, KEY)


class Fonts:
    NAMES = "avenirnext,helveticaneue,helvetica,arial"

    def __init__(self):
        self._fonts = {}
        self._text = {}

    def get(self, size, bold=True):
        key = (max(8, int(size)), bold)
        if key not in self._fonts:
            self._fonts[key] = pygame.font.SysFont(self.NAMES, key[0], bold=bold)
        return self._fonts[key]

    def render(self, text, size, color, bold=True):
        key = (text, int(size), color, bold)
        surface = self._text.get(key)
        if surface is None:
            if len(self._text) > 3000:
                self._text.clear()
            surface = self.get(size, bold).render(text, True, color)
            self._text[key] = surface
        return surface


def release_label(pathname, search=""):
    """"UAT" on the testing site (its address has -uat in the path, or ?uat=1 to fake it), else None.

    UAT and prod run the very same files (publish_web.py promote copies UAT to prod unchanged), so
    the address is how the game knows where it is."""
    if "-uat/" in pathname or "uat=1" in search.lstrip("?").split("&"):
        return "UAT"
    return None


def sync_site(host, pathname, search=""):
    """Which of the server's sites games sync to: "prod" for the real website, "uat" for the testing
    site and any other address (like a local test build at localhost), so tests never mix with
    real players' games."""
    if host == "apeckman.github.io" and release_label(pathname, search) is None:
        return "prod"
    return "uat"


def browser_sync_site():
    if not WEB:
        return "desktop"
    try:
        import platform
        location = platform.window.location
        return sync_site(str(location.host), str(location.pathname), str(location.search))
    except Exception:
        return "uat"


def browser_release_label():
    if not WEB:
        return None
    try:
        import platform
        location = platform.window.location
        return release_label(str(location.pathname), str(location.search))
    except Exception:
        return None


_safe_area_probe = None


def safe_area():
    """(top, bottom) CSS pixels the game must stay clear of: the notch/status bar and the home
    indicator when it runs full-screen from an iPhone home screen (zero in a normal browser tab).
    Add ?safe=47,34 to the URL to fake them for testing on a computer."""
    global _safe_area_probe
    import platform
    win = platform.window
    fake = str(win.location.search)
    if "safe=" in fake:
        top, bottom = fake.split("safe=")[1].split("&")[0].split(",")
        return float(top), float(bottom)
    if _safe_area_probe is None:
        # CSS knows the insets (env(safe-area-inset-*)); JavaScript can only read them off an element.
        _safe_area_probe = win.document.createElement("div")
        _safe_area_probe.style.cssText = ("position:fixed;top:0;left:0;visibility:hidden;pointer-events:none;"
                                          "padding-top:env(safe-area-inset-top);"
                                          "padding-bottom:env(safe-area-inset-bottom)")
        win.document.body.appendChild(_safe_area_probe)
    style = win.getComputedStyle(_safe_area_probe)
    return float(str(style.paddingTop).replace("px", "") or 0), float(str(style.paddingBottom).replace("px", "") or 0)


def touch_screen():
    """True in a browser on a phone or tablet (no mouse to hover, no keyboard to press W or Q)."""
    if not WEB:
        return False
    try:
        import platform
        return bool(platform.window.matchMedia("(pointer: coarse)").matches)
    except Exception:
        return False


def local_date():
    """Today's date where the player is. In a browser it comes from JavaScript's clock (web/template.tmpl
    defines wordleToday), which follows the phone's time zone."""
    if WEB:
        try:
            import platform
            year, month, day = (int(part) for part in str(platform.window.wordleToday()).split("-"))
            return datetime.date(year, month, day)
        except Exception:
            pass
    return datetime.date.today()


def site_link():
    """The address to put in shared results: this site in a browser (UAT shares UAT), else prod."""
    if WEB:
        try:
            import platform
            location = platform.window.location
            return str(location.origin) + str(location.pathname)
        except Exception:
            pass
    return PROD_LINK


def home_screen_app(win):
    """True when launched from an iPhone home-screen icon (add ?standalone=1 to fake it)."""
    try:
        return bool(win.navigator.standalone) or "standalone=1" in str(win.location.search)
    except Exception:
        return False


def browser_view():
    """(width, height, pixel ratio, safe top, safe bottom) of the browser window in CSS pixels,
    or None outside a browser."""
    try:
        import platform  # pygbag's bridge to JavaScript
        win = platform.window
        try:
            top, bottom = safe_area()
        except Exception:
            top = bottom = 0.0
        if home_screen_app(win):
            # iOS blurs and fades a band below the status bar in home-screen web apps, so keep
            # the header clear of it (the page may start below the status bar, so top can be 0).
            top += WEB_STATUS_BLUR
        return win.innerWidth, win.innerHeight, win.devicePixelRatio or 1, top, bottom
    except Exception:
        return None


def web_canvas_size(view):
    """Layout size in points for the browser (WEB_WIDTH wide, shaped like the browser window), pixels
    per point so the canvas has as many pixels as it covers on screen (sharp on Retina), and the
    safe-area insets (top, bottom) in points."""
    if not view or view[0] <= 0 or view[1] <= 0:
        view = None  # a hidden or background tab can report a 0-size window; check_web_resize fixes it later
    css_w, css_h, dpr, top, bottom = view or (WEB_WIDTH, WEB_WIDTH * 1.4, 1, 0, 0)
    points =(WEB_WIDTH, int(min(1300, max(MIN_SIZE[1] * 1.25, WEB_WIDTH * css_h / css_w))))
    shown = min(css_w / points[0], css_h / points[1])  # the page scales the canvas to fit
    return points, max(1.0, min(3.0, shown * dpr)), (top / shown, bottom / shown)


class App:
    def __init__(self):
        set_macos_app_name(APP_NAME)  # must happen before pygame sets up the window system
        if WEB:
            seed_random()  # the browser's Python starts from the same random state on every load
            # Just graphics and text: starting the sound system makes browsers show a "playing audio" icon.
            pygame.display.init()
            pygame.font.init()
        else:
            pygame.init()
        # Use a taller window when the screen has room (bigger Quordle tiles).
        screen_h = pygame.display.Info().current_h
        size = (WINDOW_SIZE[0], max(MIN_SIZE[1], min(960, screen_h - 120)) if screen_h > 0 else WINDOW_SIZE[1])
        self.fonts = Fonts()
        icon = make_icon(self.fonts)

        # All layout below is in "points" (what the window size and mouse use). On a Retina screen
        # pygame-ce gives us a surface with 2 pixels per point; self.scale converts at draw time.
        if WEB:
            # A fixed canvas shaped like the browser window (tall on a phone), scaled to fit by the page.
            self.window = None
            self.web_view = browser_view()
            self.web_resize = None  # (new view, when first seen) while the browser window is changing
            self.web_frames = 0
            self.apply_web_canvas()
        elif hasattr(pygame, "Window"):  # pygame-ce
            self.window = pygame.Window("Wordle / Quordle", size, resizable=True, allow_high_dpi=True)
            self.window.minimum_size = MIN_SIZE
            self.window.set_icon(icon)
        else:  # original pygame: works, but draws at 1x (soft on Retina)
            self.window = None
            pygame.display.set_caption("Wordle / Quordle")
            pygame.display.set_icon(icon)
            pygame.display.set_mode(size, pygame.RESIZABLE)
        self.begin_frame()
        pygame.key.set_repeat(350, 40)
        self.clock = pygame.time.Clock()

        self.word_bank = load_word_bank()
        dictionary = load_dictionary(self.word_bank)
        self.dictionary = set(dictionary)
        self.solver = Solver(self.word_bank)

        self.history = History(default_storage(WEB))
        self.sync = Sync(self.history, default_transport(WEB), browser_sync_site())
        self.friends_screen = {"mode": "w", "scroll": 0}
        self.pending = None  # {"text", "action", "at", "key"}: an action waiting for its Undo time to pass
        self.entry = None  # {"kind": "friend" / "name", "text"} while typing on the Friends screen
        self.menu_kind = self.history.prefs.get("menu", "daily")  # the menu's Daily / Practice switch
        self.stats_mode = "w"
        self.stats_kind = "daily"  # the Stats screen's Daily / Practice / All switch
        self.archive = {"mode": "w", "scroll": 0}
        self.record = None       # the history entry for the game on screen
        self.daily = None        # its daily puzzle number (None for practice)
        self.link = site_link()
        self.share_targets = []  # (rect, text) for each Share button drawn this frame (the browser needs them)
        self.published_share = None
        self.published_auth = None  # the sign-in form spec last handed to the page (browser)
        self.auth_input = {"mode": None}  # the Mac app's own sign-in form: typed fields and the focused one
        self.today_cache = None
        self.memo_cache = {}

        self.clickables = []  # (rect, action(now), name) registered by the last draw
        self.shown_enter_tip = False
        self.touch = touch_screen()
        self.release = browser_release_label()  # "UAT" on the testing site
        self.last_touch = -10000  # when the last FINGERDOWN arrived (to drop its emulated mouse click)
        self.drag = None          # a finger scrolling the words-left list
        self.scroll_area = None   # where the open panel (words-left list or definition) scrolls
        self.wrap_cache = {}
        self.mode = None
        self.words = None
        self.go_to_menu()

    # ----- state changes -------------------------------------------------

    def go_to_menu(self):
        self.scene = "menu"
        self.game = None
        self.thinking = None
        self.word_list = None
        self.definition = None
        self.hint_picker = False
        self.timers = []
        self.toasts = []

    def start(self, mode, words=None, number=None, resume=False):
        """Start a practice game (random words, or `words` to replay them; `resume` carries on with the
        one left unfinished, if any), or daily puzzle `number`, which carries on from where it was left
        (or shows the finished game)."""
        saved = None
        if number is not None:
            saved, _finished = self.history.daily_game(mode, number)
            words = saved["answers"] if saved else daily.daily_words(self.word_bank, mode, number)
        elif resume:
            saved = self.history.practice_game(mode)
            words = saved["answers"] if saved else None
        self.mode = mode
        self.daily = number
        count = 1 if mode == "w" else 4
        self.words = list(words) if words else random.sample(self.word_bank, count)
        self.game = Game(self.words, self.dictionary, self.solver)
        self.scene = "game"
        self.typed = ""
        self.toasts = []
        self.timers = []
        self.reveal = None       # {"start": ms, "rows": {board_index: row_index}} while tiles flip
        self.shake_start = None
        self.pop = None          # (tile_index, start_ms) for the letter just typed
        self.bounces = {}        # board_index -> start_ms of its "solved" bounce
        self.result_at = None    # when the end-of-game panel appeared
        self.board_grid = (1, 1)
        self.thinking = None     # {"board", "guesses", "result"} while a hint is computed off-thread
        self.shown_hint = None   # the Hint whose word is in the typed row, for highlighting its boards
        self.hint_hover = False  # mouse is over the Hint button (Quordle previews which boards it covers)
        self.word_list = None    # {"board", "row", "scroll"} while the words-left list replaces the keyboard
        self.definition = None   # {"board", "row", "word", "scroll"} while a definition replaces the keyboard
        self.hint_picker = False  # Quordle: the "hint for which board?" chooser is open
        self.drag = None
        if saved:
            self.record = saved
            for guess in saved["guesses"]:
                try:
                    self.game.submit(guess)
                except (InvalidGuess, RuntimeError):
                    break
            if self.game.over:
                self.history.finish(saved, self.game.won, self.today())  # (does nothing if already recorded)
                self.result_at = -RESULT_SLIDE_MS  # already over: show the result without sliding it in
        else:
            self.record = self.history.start(mode, self.words, number)

    def play_from_menu(self, mode):
        if self.menu_kind == "daily":
            self.start(mode, number=daily.puzzle_number(self.today()))
        else:
            self.start(mode, resume=True)

    def set_menu_kind(self, kind):
        self.menu_kind = kind
        self.history.set_pref("menu", kind)

    def open_stats(self, mode=None, kind=None):
        """Stats for mode ("w"/"q") and kind ("daily", "practice" or "all"); unset = as last shown,
        except that from the menu they follow its Daily / Practice switch."""
        if self.scene == "menu" and kind is None:
            kind = self.menu_kind
        self.scene = "stats"
        self.stats_mode = mode or self.stats_mode
        self.stats_kind = kind or self.stats_kind
        self.close_panel()
        self.toasts = []

    def open_sync(self):
        self.scene = "sync"
        self.entry = None
        self.sync.message = None
        self.toasts = []

    def open_friends(self):
        self.scene = "friends"
        self.friends_screen = dict(self.friends_screen, scroll=0)
        self.entry = None
        self.sync.friends_message = None
        self.toasts = []

    def start_entry(self, kind):
        """Start typing a link code, a friend's code or a name (or stop, if already typing that)."""
        if self.entry and self.entry["kind"] == kind:
            self.entry = None
            return
        self.entry = {"kind": kind, "text": ""}
        self.sync.message = None
        self.sync.friends_message = None

    def entry_key(self, key, now):
        """A key for the code or name being typed (a letter, digit, "space", "back" or "enter")."""
        entry = self.entry
        if entry is None:
            return
        name = entry["kind"] == "name"
        if key == "back":
            entry["text"] = entry["text"][:-1]
        elif key == "enter":
            text = entry["text"].strip()
            if name and text:
                self.sync.set_name(text, now)
                self.entry = None
            elif len(text) == 8:
                self.sync.add_friend(text, now)
                self.entry = None
        elif key == "space":
            if name and entry["text"] and not entry["text"].endswith(" ") and len(entry["text"]) < 16:
                entry["text"] += " "
        elif len(key) == 1 and key.isalnum() and key.isascii() and (name or key.isalpha()):
            if len(entry["text"]) < (16 if name else 8):
                if not name or not entry["text"] or entry["text"].endswith(" "):
                    key = key.upper()  # (names: each word starts with a capital; the keyboard has no Shift)
                entry["text"] += key

    def open_archive(self, mode=None):
        self.scene = "archive"
        if mode and mode != self.archive["mode"]:
            self.archive = {"mode": mode, "scroll": 0}
        self.close_panel()
        self.toasts = []

    def today(self):
        """The local date, asked at most once a second (the browser asks JavaScript)."""
        now = pygame.time.get_ticks()
        if self.today_cache is None or now - self.today_cache[0] > 1000 or now < self.today_cache[0]:
            self.today_cache = (now, local_date())
        return self.today_cache[1]

    def memo(self, key, compute):
        """compute(), remembered until the saved games change (stats are drawn every frame)."""
        key = (self.history.revision, key)
        if key not in self.memo_cache:
            if len(self.memo_cache) > 60:
                self.memo_cache.clear()
            self.memo_cache[key] = compute()
        return self.memo_cache[key]

    def later(self, when, callback):
        self.timers.append((when, callback))

    def run_timers(self, now):
        due = [t for t in self.timers if t[0] <= now]
        self.timers = [t for t in self.timers if t[0] > now]
        for _, callback in due:
            callback(now)

    def toast(self, text, now, duration=TOAST_MS):
        self.toasts = [t for t in self.toasts if now - t[1] < t[2]][-2:] + [(text, now, duration)]

    def accepting_input(self):
        return self.scene == "game" and not self.game.over and self.reveal is None

    def type_letter(self, letter, now):
        if self.accepting_input() and len(self.typed) < self.game.word_length:
            self.typed += letter
            self.pop = (len(self.typed) - 1, now)

    def backspace(self, now=None):
        if self.accepting_input():
            self.typed = self.typed[:-1]

    def submit(self, now):
        if not self.accepting_input():
            return
        game = self.game
        try:
            guess = game.check(self.typed)
        except InvalidGuess as error:
            self.toast(str(error), now)
            self.shake_start = now
            return

        rows_before = [len(board.guesses) for board in game.boards]
        newly_solved = game.submit(guess)
        # Saved straight away (not after the tiles flip), so reloading can't undo a guess.
        self.record["guesses"] = list(game.guesses)
        if game.over:
            self.history.finish(self.record, game.won, self.today())
            self.sync.soon(now)
        else:
            self.history.update(self.record)
            if self.daily is not None:
                self.sync.soon(now, 5000)  # so another device carries on from here
        self.reveal = {
            "start": now,
            "rows": {i: rows_before[i] for i, board in enumerate(game.boards) if len(board.guesses) > rows_before[i]},
        }
        self.typed = ""
        self.pop = None
        self.hint_picker = False
        done = now + FLIP_STAGGER_MS * (game.word_length - 1) + FLIP_MS
        self.later(done, lambda t: self.finish_reveal(t, newly_solved))

    def finish_reveal(self, now, newly_solved):
        self.reveal = None
        for i in newly_solved:
            self.bounces[i] = now
        multi = len(self.game.boards) > 1
        if self.game.over:
            delay = BOUNCE_MS + BOUNCE_STAGGER_MS * self.game.word_length if newly_solved else 350
            self.later(now + delay, self.show_result)
        elif newly_solved and multi:
            names = " and ".join(str(i + 1) for i in newly_solved)
            self.toast("Board %s solved!" % names, now)

    def show_result(self, now):
        self.result_at = now

    def hint(self, now, board_index=None):
        """Ask the solver for a hint. It can take up to a second, so it runs on a thread
        (in a browser, where there are no threads, it runs right after "Thinking..." is drawn)."""
        if not self.accepting_input() or self.thinking:
            return
        job = {"board": board_index, "guesses": len(self.game.guesses), "game": self.game,
               "result": None, "done": False, "polls": 0}
        self.thinking = job

        def work():
            try:
                job["result"] = job["game"].hint(board_index)
            except Exception:
                pass  # treated like no hint; never leave the button stuck on "thinking"
            finally:
                job["done"] = True

        if self.game.known_answer():
            work()  # "Solve": nothing to search for, so it's filled in at once
            self.poll_hint(now)
        elif WEB:
            job["work"] = work
        else:
            threading.Thread(target=work, daemon=True).start()

    def hint_button(self, now):
        """Wordle: hint straight away. Quordle: open (or close) the chooser, so a board-only hint
        never comes from a stray tap on a board."""
        if len(self.game.boards) == 1 or self.game.known_answer():
            self.hint(now)
        elif self.accepting_input() and not self.thinking:
            self.hint_picker = not self.hint_picker
            self.toasts = []  # the chooser uses the message strip

    def pick_hint(self, now, board_index=None):
        """From the chooser: None = best guess for all unsolved boards, else just that board."""
        self.hint_picker = False
        self.hint(now, board_index)

    def panel(self):
        """The scrollable panel open in the keyboard's spot (words-left list or definition), or None."""
        return self.word_list or self.definition

    def open_word_list(self, board_index, row):
        """Show (or, clicking the same count again, hide) the words left after a row."""
        current = self.word_list
        self.definition = None
        if current and (current["board"], current["row"]) == (board_index, row):
            self.word_list = None
        else:
            self.word_list = {"board": board_index, "row": row, "scroll": 0}
            if not self.game.over:
                self.record["lists"] = self.record.get("lists", 0) + 1
                self.history.update(self.record)

    def open_definition(self, board_index, row):
        """Show (or, clicking the same "?" again, hide) what a guessed row's word means."""
        current = self.definition
        self.word_list = None
        if current and (current["board"], current["row"]) == (board_index, row):
            self.definition = None
        else:
            word = self.game.boards[board_index].history()[row][0]
            self.definition = {"board": board_index, "row": row, "word": word, "scroll": 0}

    def pick_word(self, word, now):
        if self.accepting_input():
            self.typed = word
            self.pop = None

    def close_panel(self, now=None):
        self.word_list = None
        self.definition = None

    def scroller(self):
        """What scrolls right now (a dict with "scroll"): the archive list, or the panel open over
        the keyboard. None if nothing does."""
        if self.scene == "archive":
            return self.archive
        if self.scene == "friends":
            return self.friends_screen
        return self.panel() if self.scene == "game" else None

    def poll_hint(self, now):
        job = self.thinking
        if job and "work" in job and not job["done"]:
            job["polls"] += 1
            if job["polls"] >= 2:  # one frame showing "Thinking..." has been drawn
                job["work"]()
        if not job or not job["done"]:
            return
        self.thinking = None
        hint = job["result"]
        # Drop it if the player moved on (new game, or guessed) while it was computing.
        if hint is None or job["game"] is not self.game or job["guesses"] != len(self.game.guesses):
            return
        if not self.accepting_input():
            return
        if hint.word is None:
            self.toast(hint.explain(), now)
            return
        self.typed = hint.word
        self.pop = None
        self.shown_hint = hint
        self.record["hints"] = self.record.get("hints", 0) + 1
        self.history.update(self.record)
        if self.shown_enter_tip:
            self.toast(hint.explain(), now, HINT_TOAST_MS)
        else:
            self.shown_enter_tip = True
            self.toast(hint.explain() + ". Enter plays it", now, HINT_TOAST_MS)

    # ----- events --------------------------------------------------------

    def handle_event(self, event, now):
        if event.type == pygame.QUIT:
            return False
        if event.type == pygame.VIDEORESIZE and self.window is None:
            w, h = max(MIN_SIZE[0], event.w), max(MIN_SIZE[1], event.h)
            if (w, h) != (event.w, event.h):
                pygame.display.set_mode((w, h), pygame.RESIZABLE)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if WEB and (getattr(event, "touch", False) or now - self.last_touch < 600):
                # Browsers report a tap twice: as a touch, then as an emulated mouse click. The
                # FINGERDOWN below already handled it (and Hint toggles, so twice would undo it).
                return True
            pos = (event.pos[0] / self.scale, event.pos[1] / self.scale - self.offset_y) if WEB else event.pos
            if self.scroller() is not None and self.scroll_area and self.scroll_area.collidepoint(pos):
                self.drag = {"start": pos, "scroll": self.scroller()["scroll"], "moved": False, "mouse": True}
            else:
                self.click(pos, now)
        elif event.type == pygame.MOUSEMOTION and self.drag and self.drag.get("mouse") and self.scroller() is not None:
            pos = (event.pos[0] / self.scale, event.pos[1] / self.scale - self.offset_y) if WEB else event.pos
            self.drag_to(pos)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.drag and self.drag.get("mouse"):
            self.end_drag(now)
        elif event.type == pygame.FINGERDOWN and WEB:
            # Phone taps: use the touch position itself (x/y are 0-1 across the canvas) rather than
            # the browser's emulated mouse, whose position can lag behind.
            self.last_touch = now
            pos = self.finger_pos(event)
            area = self.scroll_area if self.scroller() is not None else None
            if area and area.collidepoint(pos):
                # In the words-left list (or a definition) a finger can drag to scroll, so wait for it
                # to lift: a tap (little movement) picks the word under it, a drag only scrolls.
                self.drag = {"start": pos, "scroll": self.scroller()["scroll"], "moved": False}
            else:
                self.click(pos, now)
        elif event.type == pygame.FINGERMOTION and WEB and self.drag and not self.drag.get("mouse") and self.scroller() is not None:
            self.drag_to(self.finger_pos(event))
        elif event.type == pygame.FINGERUP and WEB and self.drag and not self.drag.get("mouse"):
            self.last_touch = now
            self.end_drag(now)
        elif event.type == pygame.MOUSEWHEEL and self.scroller() is not None:
            self.scroller()["scroll"] -= event.y * 24
        elif event.type == pygame.KEYDOWN:
            self.handle_key(event, now)
        return True

    def drag_to(self, pos):
        """Scroll the open panel with a dragging finger (or mouse)."""
        dy = pos[1] - self.drag["start"][1]
        if abs(dy) > 8:
            self.drag["moved"] = True
        if self.drag["moved"]:
            self.scroller()["scroll"] = self.drag["scroll"] - dy

    def end_drag(self, now):
        """Lifting without having dragged is a tap: pick the word under it."""
        drag, self.drag = self.drag, None
        if not drag["moved"] and self.scroller() is not None:
            self.click(drag["start"], now)

    def finger_pos(self, event):
        """A touch event's position in points (event.x/y are 0-1 across the whole canvas)."""
        full_w, full_h = self.full_screen.get_size()
        return (event.x * full_w / self.scale, event.y * full_h / self.scale - self.offset_y)

    def click(self, pos, now):
        for rect, action, _name in reversed(self.clickables):
            if rect.collidepoint(pos):
                action(now)
                break

    def handle_key(self, event, now):
        if self.sync.auth_form and not WEB:
            self.auth_key(event, now)
            return
        if event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            return  # leave Cmd/Ctrl shortcuts (like Cmd+Q) to the system
        if pygame.K_a <= event.key <= pygame.K_z:
            char = chr(event.key)
        else:
            char = event.unicode.lower() if getattr(event, "unicode", "") else ""
        enter = event.key in (pygame.K_RETURN, pygame.K_KP_ENTER)

        panel = self.panel()
        if panel:
            if event.key in (pygame.K_DOWN, pygame.K_PAGEDOWN):
                panel["scroll"] += 24 if event.key == pygame.K_DOWN else 96
                return
            if event.key in (pygame.K_UP, pygame.K_PAGEUP):
                panel["scroll"] -= 24 if event.key == pygame.K_UP else 96
                return
            # Any other key puts the keyboard back; typing carries on as normal.
            self.close_panel()
            if event.key == pygame.K_ESCAPE:
                return

        if self.hint_picker and self.scene == "game":
            if char and char in "1234":
                if not self.game.boards[int(char) - 1].solved:
                    self.pick_hint(now, int(char) - 1)
                return  # a solved board's number does nothing
            if enter:
                self.pick_hint(now)
                return
            self.hint_picker = False  # any other key closes it; Esc does nothing else
            if event.key == pygame.K_ESCAPE:
                return

        if self.scene == "menu":
            if char in ("w", "q"):
                self.play_from_menu(char)
            elif char in ("d", "p"):
                self.set_menu_kind("daily" if char == "d" else "practice")
            elif char == "s":
                self.open_stats()
            elif char == "a":
                self.open_archive()
            elif char == "f" and self.sync.configured:
                self.open_friends()
            return

        if self.scene in ("sync", "friends"):
            if self.entry is not None:
                if event.key == pygame.K_ESCAPE:
                    self.entry = None
                elif event.key == pygame.K_BACKSPACE:
                    self.entry_key("back", now)
                elif enter:
                    self.entry_key("enter", now)
                elif event.key == pygame.K_SPACE:
                    self.entry_key("space", now)
                elif char:
                    typed = getattr(event, "unicode", "")
                    self.entry_key(typed if len(typed) == 1 and typed.isalnum() else char, now)
            elif self.scene == "friends" and char in ("w", "q"):
                self.friends_screen["mode"] = char
            elif self.scene == "friends" and event.key in (pygame.K_DOWN, pygame.K_UP):
                self.friends_screen["scroll"] += 44 if event.key == pygame.K_DOWN else -44
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if self.scene in ("stats", "archive"):
            archive = self.scene == "archive"
            if char in ("w", "q"):
                if archive:
                    self.open_archive(char)
                else:
                    self.stats_mode = char
            elif not archive and char in ("d", "p"):
                self.stats_kind = "daily" if char == "d" else "practice"
            elif char == "a" and not archive:
                self.open_archive()
            elif char == "s" and archive:
                self.open_stats()
            elif archive and event.key in (pygame.K_DOWN, pygame.K_UP, pygame.K_PAGEDOWN, pygame.K_PAGEUP):
                step = {pygame.K_DOWN: 52, pygame.K_UP: -52, pygame.K_PAGEDOWN: 260, pygame.K_PAGEUP: -260}
                self.archive["scroll"] += step[event.key]
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if self.result_at is not None:
            if char == "s":
                self.share(False, now)
            elif self.daily is not None:
                if enter:
                    self.open_stats(self.mode, "daily")
                elif char == "a":
                    self.open_archive(self.mode)
                elif char == "m" or event.key == pygame.K_ESCAPE:
                    self.go_to_menu()
            elif enter or char == "n":
                self.start(self.mode)
            elif char == "r":
                self.start(self.mode, self.words)
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if enter:
            self.submit(now)
        elif event.key == pygame.K_BACKSPACE:
            self.backspace(now)
        elif len(char) == 1 and "a" <= char <= "z":
            self.type_letter(char, now)

    def run(self):
        running = True
        while running:
            running = self.frame()
            self.clock.tick(FPS)
        pygame.quit()

    async def run_async(self):
        """The same loop for the browser, which needs control back after every frame."""
        while self.frame():
            self.clock.tick(FPS)
            await asyncio.sleep(0)

    def apply_web_canvas(self):
        points, self.web_scale, self.web_insets = web_canvas_size(self.web_view)
        pygame.display.set_mode((round(points[0] * self.web_scale), round(points[1] * self.web_scale)))

    def check_web_resize(self, now):
        """Rebuild the canvas when the browser window changes size (or moves to a screen with a
        different pixel ratio), once it has stayed put for a moment, so it stays sharp."""
        self.web_frames += 1
        if self.web_frames % 10:
            return  # asking the browser every frame is wasteful
        view = browser_view()
        if view is None or view == self.web_view:
            self.web_resize = None
            return
        if self.web_resize is None or self.web_resize[0] != view:
            self.web_resize = (view, now)
        elif now - self.web_resize[1] >= 250:
            self.web_view, self.web_resize = view, None
            self.apply_web_canvas()
            try:
                import platform
                platform.window.window_resize()  # the page re-fits the canvas to the window
            except Exception:
                pass

    def frame(self):
        now = pygame.time.get_ticks()
        if WEB:
            self.check_web_resize(now)
        running = True
        for event in pygame.event.get():
            if not self.handle_event(event, now):
                running = False
        self.run_timers(now)
        self.poll_hint(now)
        self.tick_sync(now)
        self.draw(now)
        self.present()
        if WEB:
            self.publish_share_targets()
            self.poll_share(now)
            self.publish_auth_form()
            self.poll_auth_form(now)
        return running

    def tick_sync(self, now):
        """Send and take in synced games (never waits: see sync.py)."""
        on_screen = self.scene == "game" and self.daily is not None and self.game and not self.game.over
        self.sync.keep = (self.mode, self.daily) if on_screen else None
        if self.pending and now >= self.pending["at"]:
            self.finish_pending(now)
        try:
            if self.scene == "friends":
                self.sync.refresh_friends(now)  # (at most once a minute)
            self.sync.tick(now)
        except Exception:
            self.sync.busy = None  # a bug in syncing must never stop the game; try again later
            self.sync.next_at = now + 60 * 1000

    # ----- sharing -------------------------------------------------------

    def share_message(self, spoilers):
        record = self.record
        key = ("share", record["id"], len(record["guesses"]), record.get("hints", 0), spoilers, self.link)
        return self.memo(key, lambda: share_text(record, self.game.max_guesses, spoilers, self.link))

    def share(self, spoilers, now, clicked=False):
        """Copy the result (computer), or hand it to the page to share (browser)."""
        text = self.share_message(spoilers)
        if WEB:
            if clicked:
                return  # the page shares on the click itself (see publish_share_targets)
            try:
                import platform
                platform.window.wordleShareText(text)  # the S key
            except Exception:
                self.toast("Couldn't share from here", now)
            return
        try:
            pygame.scrap.put_text(text)
        except Exception:
            self.toast("Couldn't copy to the clipboard", now)
            return
        self.toast("Copied! Paste it to share", now)

    def publish_share_targets(self):
        """Tell the page where the Share buttons are, in canvas pixels, with their text.

        Browsers only open the share sheet (or write to the clipboard) during the tap or click
        itself, and Python sees a tap a frame later, so web/template.tmpl's click handler does the
        sharing when a click lands on one of these."""
        targets = [[round(rect.x * self.scale), round((rect.y + self.offset_y) * self.scale),
                    round(rect.w * self.scale), round(rect.h * self.scale), text] for rect, text in self.share_targets]
        data = json.dumps(targets)
        if data != self.published_share:
            try:
                import platform
                platform.window.wordleShareTargets = data
                if not targets:
                    platform.window.wordleShareStatus = ""  # a late "copied" mustn't pop up on the next result
                self.published_share = data
            except Exception:
                pass

    def poll_share(self, now):
        """Show how the page's share went ("copied" etc.)."""
        if not self.share_targets:
            return
        try:
            import platform
            status = str(platform.window.wordleShareStatus or "")
            if status:
                platform.window.wordleShareStatus = ""
        except Exception:
            return
        if status == "copied":
            self.toast("Copied! Paste it to share", now)
        elif status == "failed":
            self.toast("Couldn't share from this browser", now)

    def present(self):
        if self.window is not None:
            self.window.flip()
        else:
            pygame.display.flip()

    # ----- drawing helpers -----------------------------------------------
    # Callers work in points; these helpers convert to real pixels with self.scale.

    def begin_frame(self):
        """Grab the window surface (it changes on resize) and work out pixels per point."""
        if self.window is not None:
            self.screen = self.window.get_surface()
            points_w = self.window.size[0]
        else:
            self.screen = pygame.display.get_surface()
            points_w = self.screen.get_width() / (self.web_scale if WEB else 1)
        self.scale = self.screen.get_width() / points_w if points_w else 1.0
        self.full_screen = self.screen
        self.offset_y = 0
        if WEB and any(self.web_insets):
            # Draw everything inside the iPhone safe area: a sub-surface below the notch and above
            # the home indicator. Layout code never knows; clicks are shifted to match.
            top = round(self.web_insets[0] * self.scale)
            bottom = round(self.web_insets[1] * self.scale)
            w, h = self.screen.get_size()
            self.screen = self.screen.subsurface((0, top, w, max(1, h - top - bottom)))
            self.offset_y = top / self.scale
        pixels_w, pixels_h = self.screen.get_size()
        self.size =(round(pixels_w / self.scale), round(pixels_h / self.scale))

    def mouse(self):
        """Mouse position in points (in the browser, pygame reports canvas pixels), used for hover
        effects. Touch screens have no hover: the browser parks the "mouse" where the last tap was,
        which would leave something lit up, so report it as nowhere (taps use event positions)."""
        if self.touch:
            return (-10000, -10000)
        x, y = pygame.mouse.get_pos()
        return (x / self.scale, y / self.scale - self.offset_y) if WEB else (x, y)

    def px(self, value):
        return int(round(value * self.scale))

    def px_rect(self, rect):
        """A rect in points -> the same rect in pixels (edges rounded, so neighbors don't gap)."""
        x, y, w, h = rect
        s = self.scale
        left, top = round(x * s), round(y * s)
        return pygame.Rect(left, top, max(1, round((x + w) * s) - left), max(1, round((y + h) * s) - top))

    def rrect(self, color, rect, radius, width=0, **corners):
        corners = {k: self.px(v) for k, v in corners.items()}
        pygame.draw.rect(self.screen, color, self.px_rect(rect), max(1, self.px(width)) if width else 0,
                         border_radius=self.px(radius), **corners)

    def text(self, text, size, color, center=None, bold=True, **anchor):
        surface = self.fonts.render(text, size * self.scale, color, bold)
        if center:
            rect = surface.get_rect(center=(self.px(center[0]), self.px(center[1])))
        else:
            (name, value), = anchor.items()
            value = tuple(self.px(v) for v in value) if isinstance(value, tuple) else self.px(value)
            rect = surface.get_rect(**{name: value})
        self.screen.blit(surface, rect)
        # Where it landed, back in points.
        return pygame.Rect(rect.x / self.scale, rect.y / self.scale, rect.w / self.scale, rect.h / self.scale)

    def button(self, rect, label, action, size=17, primary=False, enabled=True):
        rect = pygame.Rect(rect)
        hovered = enabled and rect.collidepoint(self.mouse())
        color = ACCENT if primary else BUTTON
        if not enabled:
            color = PANEL
        elif hovered:
            color = lighten(color, 0.12)
        self.rrect(color, rect, 10)
        self.text(label, size, TEXT if enabled else MUTED, center=rect.center)
        if enabled:
            self.clickables.append((rect, action, "button:" + label))
        return rect

    def draw_tile(self, cell, letter, state, scale=1.0, scale_y=1.0):
        """state: "empty", "typed", or a score color ("green", "yellow", "black")."""
        # Work straight in pixels here so flips and pops animate smoothly at Retina resolution.
        s = self.scale
        rect = pygame.Rect(0, 0, max(1, int(cell.w * s * scale)), max(1, int(cell.h * s * scale * scale_y)))
        rect.center = (round(cell.centerx * s), round(cell.centery * s))
        radius = self.px(max(3, cell.w // 7))
        border = self.px(max(2, cell.w // 24))
        if state == "empty":
            pygame.draw.rect(self.screen, EMPTY_BORDER, rect, border, border_radius=radius)
        elif state == "typed":
            pygame.draw.rect(self.screen, PANEL, rect, border_radius=radius)
            pygame.draw.rect(self.screen, TYPED_BORDER, rect, border, border_radius=radius)
        else:
            pygame.draw.rect(self.screen, TILE_COLORS[state], rect, border_radius=radius)
        if letter and scale_y > 0.12:
            surface = self.fonts.render(letter.upper(), cell.h * 0.56 * s, TEXT)
            if scale_y < 1:
                size = (surface.get_width(), max(1, int(surface.get_height() * scale_y)))
                surface = pygame.transform.smoothscale(surface, size)
            self.screen.blit(surface, surface.get_rect(center=rect.center))

    # ----- menu ----------------------------------------------------------

    def draw(self, now):
        self.clickables = []
        self.share_targets = []
        self.scroll_area = None  # set by whatever scrollable list is drawn this frame
        self.begin_frame()
        self.full_screen.fill(BG)
        if self.scene == "menu":
            self.draw_menu(now)
        elif self.scene == "stats":
            self.draw_stats(now)
        elif self.scene == "archive":
            self.draw_archive(now)
        elif self.scene == "sync":
            self.draw_sync(now)
        elif self.scene == "friends":
            self.draw_friends(now)
        else:
            self.draw_game(now)
        if self.scene != "game":
            self.draw_pending(now)
        if self.sync.auth_form and not WEB:
            self.draw_auth_form(now)
        self.draw_toasts(now)

    def segmented(self, rect, options, selected, choose, name):
        """A row of options with one selected (like Daily | Practice). Targets are "name:value"."""
        rect = pygame.Rect(rect)
        self.rrect(PANEL, rect, 12)
        width = rect.w / len(options)
        for i, (value, label) in enumerate(options):
            seg = pygame.Rect(round(rect.x + i * width) + 4, rect.y + 4, round(width) - 8, rect.h - 8)
            on = value == selected
            if on:
                self.rrect(BUTTON, seg, 9)
            elif seg.collidepoint(self.mouse()):
                self.rrect(lighten(PANEL, 0.08), seg, 9)
            self.text(label, 16, TEXT if on else MUTED, center=seg.center)
            self.clickables.append((seg, lambda now, value=value: choose(value), "%s:%s" % (name, value)))

    def daily_status(self, mode, number):
        """How a daily puzzle stands, as (text, color): "Solved in 4/6", "In progress, 2/6"..."""
        game, finished = self.history.daily_game(mode, number)
        limit = WORDLE_GUESSES if mode == "w" else QUORDLE_GUESSES
        if finished:
            if game.get("won"):
                return "Solved in %d/%d" % (len(game["guesses"]), limit), SOLVED_TEXT
            return "Not solved", MUTED
        if game and game["guesses"]:
            return "In progress, %d/%d" % (len(game["guesses"]), limit), TEXT
        return "Not played yet", MUTED

    def draw_menu(self, now):
        w, h = self.size
        title = "WORDLE"
        colors = ["green", "black", "yellow", "black", "green", "yellow"]
        tile, gap = 62, 8
        card_w, card_h = min(420, w - 64), 96
        content_h = tile + 62 + 40 + 18 + 2 * (card_h + 16) + 44 + (40 if not self.touch else 0)
        top = max(24, int((h - content_h) * 0.42))
        total = len(title) * tile + (len(title) - 1) * gap
        for i, (letter, color) in enumerate(zip(title, colors)):
            bob = math.sin(now / 420 + i * 0.7) * 5
            cell = pygame.Rect(w // 2 - total // 2 + i * (tile + gap), top + bob, tile, tile)
            self.draw_tile(cell, letter, color)
        self.text("& QUORDLE", 22, MUTED, center=(w // 2, top + tile + 30))

        kinds = pygame.Rect(w // 2 - 130, top + tile + 62, 260, 40)
        self.segmented(kinds, [("daily", "Daily"), ("practice", "Practice")], self.menu_kind, self.set_menu_kind,
                       "kind")
        number = daily.puzzle_number(self.today())
        y = kinds.bottom + 18
        for key, name, detail in (("w", "Wordle", "One word, six guesses"),
                                  ("q", "Quordle", "Four words at once, nine guesses")):
            rect = pygame.Rect(w // 2 - card_w // 2, y, card_w, card_h)
            hovered = rect.collidepoint(self.mouse())
            self.rrect(lighten(PANEL, 0.08) if hovered else PANEL, rect, 16)
            if hovered:
                self.rrect(ACCENT, rect, 16, 2)
            self.text(name, 28, TEXT, topleft=(rect.x + 26, rect.y + 18))
            color = MUTED
            if self.menu_kind == "daily":
                status, color = self.daily_status(key, number)
                detail = "#%d  \u00b7  %s" % (number, status)
            elif self.history.practice_game(key):
                limit = WORDLE_GUESSES if key == "w" else QUORDLE_GUESSES
                detail = "In progress, %d/%d" % (len(self.history.practice_game(key)["guesses"]), limit)
                color = TEXT
            self.text(detail, 16, color, bold=False, topleft=(rect.x + 26, rect.y + 58))
            if not self.touch:  # keyboard shortcut badge; no keyboard on a phone
                badge = pygame.Rect(0, 0, 44, 44)
                badge.midright = (rect.right - 24, rect.centery)
                self.rrect(BUTTON, badge, 10)
                self.text(key.upper(), 20, TEXT, center=badge.center)
            self.clickables.append((rect, lambda now, key=key: self.play_from_menu(key), "menu:" + key))
            y += card_h + 16

        buttons = [("Stats", lambda now: self.open_stats()), ("Archive", lambda now: self.open_archive())]
        if self.sync.configured:
            buttons.append(("Friends", lambda now: self.open_friends()))
            buttons.append(("Account", lambda now: self.open_sync()))
        each = (card_w - 12 * (len(buttons) - 1)) // len(buttons)
        x = w // 2 - card_w // 2
        for label, action in buttons:
            self.button((x, y, each, 44), label, action, size=16)
            x += each + 12
        if not self.touch:
            self.text("W or Q: play     D / P: daily or practice     S: stats     A: archive", 13, MUTED,
                      bold=False, center=(w // 2, y + 44 + 28))

    # ----- stats and archive ---------------------------------------------

    def draw_screen_header(self, title):
        w = self.size[0]
        bw = 84 if w >= 640 else 62
        self.button((16, 14, bw, 36), "Menu", lambda now: self.go_to_menu(), size=16)
        shown = self.text(title, 26, TEXT, center=(w // 2, 32))
        if self.release:
            self.draw_release_badge((shown.right + 8, shown.centery), "midleft")
        self.rrect(EMPTY_BORDER, (0, 64, w, 1), 0)

    def draw_stats(self, now):
        w, h = self.size
        self.draw_screen_header("STATS")
        mode = self.stats_mode
        self.segmented((w // 2 - 130, 80, 260, 40), [("w", "Wordle"), ("q", "Quordle")], mode,
                       lambda value: setattr(self, "stats_mode", value), "stats")
        kind = self.stats_kind
        self.segmented((w // 2 - 150, 128, 300, 36), [("daily", "Daily"), ("practice", "Practice"), ("all", "All")],
                       kind, lambda value: setattr(self, "stats_kind", value), "stats-kind")
        today = self.today()
        stats = self.memo(("stats", mode, kind, today), lambda: self.history.stats(mode, kind, today))
        col = pygame.Rect(max(24, w // 2 - 260), 0, min(520, w - 48), 0)

        y = 184
        if kind == "daily":
            y = self.stat_row(col, y, [(stats.played, "Played"), (stats.win_percent, "Win %"),
                                       (stats.current_streak, "Streak"), (stats.best_streak, "Best streak")])
        else:
            solved = sum(n * count for n, count in stats.distribution.items())
            average = "%.1f" % (solved / stats.won) if stats.won else "-"
            y = self.stat_row(col, y, [(stats.played, "Played"), (stats.win_percent, "Win %"),
                                       (average, "Avg guesses")])
        highlight = None
        if kind != "practice":  # today's daily puzzle, if solved, shows in green
            game, finished = self.history.daily_game(mode, daily.puzzle_number(today))
            highlight = len(game["guesses"]) if finished and game.get("won") else None
        self.text("GUESSES TO SOLVE", 13, MUTED, topleft=(col.x, y + 6))
        y = self.draw_distribution(col, y + 28, stats, mode, highlight)
        if stats.hinted:
            note = "Hints used in %d of these game%s" % (stats.hinted, "" if stats.hinted == 1 else "s")
            self.text(note, 14, MUTED, bold=False, topleft=(col.x, y + 6))

    def stat_row(self, col, y, items):
        """Big numbers with small labels under them, spread across the column. Returns the bottom."""
        width = col.w / len(items)
        for i, (value, label) in enumerate(items):
            center = col.x + width * i + width / 2
            self.text(str(value), 30, TEXT, center=(center, y + 18))
            self.text(label, 13, MUTED, bold=False, center=(center, y + 46))
        return y + 62

    def draw_distribution(self, col, y, stats, mode, highlight):
        """A bar per number of guesses (1-6 in Wordle, 4-9 in Quordle) for the games won."""
        counts = range(1, WORDLE_GUESSES + 1) if mode == "w" else range(4, QUORDLE_GUESSES + 1)
        biggest = max([stats.distribution.get(n, 0) for n in counts] + [1])
        for n in counts:
            count = stats.distribution.get(n, 0)
            self.text(str(n), 15, TEXT, center=(col.x + 8, y + 11))
            bar = pygame.Rect(col.x + 24, y, 30 + (col.w - 24 - 30) * count / biggest, 22)
            self.rrect(ACCENT if n == highlight else BUTTON, bar, 5)
            self.text(str(count), 13, TEXT, midright=(bar.right - 8, bar.centery))
            y += 28
        return y

    def draw_archive(self, now):
        w, h = self.size
        self.draw_screen_header("ARCHIVE")
        mode = self.archive["mode"]
        self.segmented((w // 2 - 130, 80, 260, 40), [("w", "Wordle"), ("q", "Quordle")], mode,
                       lambda value: self.open_archive(value), "archive-mode")
        box = pygame.Rect(16, 136, w - 32, h - 136 - 16)
        self.rrect(PANEL, box, 14)
        area = self.scroll_area = box.inflate(-16, -16)
        today = self.today()
        latest = daily.puzzle_number(today)
        row_h = 52
        content_h = latest * row_h
        info = self.archive
        info["scroll"] = max(0, min(info["scroll"], content_h - area.h))
        scroll = info["scroll"]

        self.screen.set_clip(self.px_rect(area))
        mouse = self.mouse()
        first = int(scroll // row_h)
        for i in range(first, min(latest, first + area.h // row_h + 2)):
            number = latest - i  # newest first
            row = pygame.Rect(area.x, area.y + i * row_h - scroll, area.w, row_h - 6)
            hit = row.clip(area)
            if hit.collidepoint(mouse):
                self.rrect(lighten(PANEL, 0.08), row, 10)
            self.text("#%d" % number, 18, TEXT, midleft=(row.x + 12, row.centery))
            self.text(daily.describe(number, today), 15, MUTED, bold=False, midleft=(row.x + 78, row.centery))
            status, color = self.daily_status(mode, number)
            if status == "Not played yet":
                pill = pygame.Rect(0, 0, 64, 30)
                pill.midright = (row.right - 10, row.centery)
                self.rrect(BUTTON, pill, 8)
                self.text("Play", 15, TEXT, center=pill.center)
            else:
                self.text(status, 15, color, bold=False, midright=(row.right - 12, row.centery))
            if hit.h > 0:
                self.clickables.append((hit, lambda now, n=number: self.start(mode, number=n), "archive:%d" % number))
        self.screen.set_clip(None)
        self.draw_scrollbar(box, area, content_h, scroll)

    # ----- account (sync) and friends --------------------------------------------
    # Two different things, explained on both screens: Account keeps your OWN games on all your
    # devices; Friends only shows daily results side by side, and never mixes anyone's games.
    # Anything hard to take back waits UNDO_MS with an Undo button (self.pending).

    PRIVACY_NOTE = ("Games are saved to the server under a random ID for this device (no email, no location), "
                    "with or without an account. Signing in keeps your email with your account. A name only if "
                    "you pick one for Friends.")
    FRIENDS_NOTE = ("Compare daily puzzles with friends. Pick a name and you'll get a friend code to give them. "
                    "Friends only see your daily results (guesses, streak, win %): never your words, your "
                    "practice games, or anything on your devices. Your games never mix with theirs.")
    ENTRY_HINTS = {
        "friend": "Ask your friend for the code on their Friends screen. You can remove a friend any time.",
        "name": "Up to 16 letters, numbers or spaces. It doesn't have to be unique: friends are matched by code.",
    }

    def undoable(self, text, action, now, key=None):
        """Do action in UNDO_MS unless Undo is tapped (a pending one goes ahead first)."""
        self.finish_pending(now)
        self.pending = {"text": text, "action": action, "at": now + UNDO_MS, "key": key}

    def finish_pending(self, now):
        pending, self.pending = self.pending, None
        if pending:
            pending["action"](now)

    def undo(self, now):
        self.pending = None

    def pending_key(self):
        return self.pending["key"] if self.pending else None

    def draw_pending(self, now):
        """The "...  Undo" bar along the bottom while an action waits."""
        if not self.pending:
            return
        w, h = self.size
        bar = pygame.Rect(12, h - 76, w - 24, 64)
        self.rrect(TEXT, bar, 14)
        left = max(0, -(-(self.pending["at"] - now) // 1000))
        self.text("%s in %d s" % (self.pending["text"], left), 16, DARK_TEXT, midleft=(bar.x + 18, bar.centery))
        self.button((bar.right - 112, bar.y + 10, 100, 44), "Undo", self.undo, size=16, primary=True)

    def paragraph(self, text, size, color, col, y, center=False):
        """Wrapped text across the column; returns the y below it."""
        line_h = round(size * 1.4)
        for line in self.wrap(text, size, col.w):
            if center:
                self.text(line, size, color, bold=False, center=(col.centerx, y + line_h / 2))
            else:
                self.text(line, size, color, bold=False, topleft=(col.x, y))
            y += line_h
        return y

    def show_message(self, message, col, y):
        if not message:
            return y
        text, ok = message
        return self.paragraph(text, 15, SOLVED_TEXT if ok else ERROR_TEXT, col, y + 4, center=True)

    def column(self):
        w = self.size[0]
        return pygame.Rect(max(24, w // 2 - 260), 0, min(520, w - 48), 0)

    def entry_keyboard_area(self):
        w, h = self.size
        rows = 4 if self.entry and self.entry["kind"] == "name" else 3
        return pygame.Rect(16, h - rows * 52 - (rows - 1) * 6 - 16, w - 32, rows * 52 + (rows - 1) * 6)

    def draw_entry(self, col, y, label, message):
        """The code or name being typed, with big Cancel and Save/Link/Add buttons (phones have no
        Enter key), a hint, and the letter keyboard at the bottom."""
        entry = self.entry
        kind = entry["kind"]
        self.text(label, 16, MUTED, center=(col.centerx, y + 10))
        y += 30
        y = self.draw_name_box(col, y, entry["text"]) if kind == "name" else self.draw_code_boxes(col, y, entry["text"])
        text = entry["text"].strip()
        ready = bool(text) if kind == "name" else len(text) == 8
        done = {"friend": "Add friend", "name": "Save"}[kind]
        half = min(150, (col.w - 12) // 2)
        self.button((col.centerx - half - 6, y, half, 46), "Cancel", lambda now: setattr(self, "entry", None), size=16)
        self.button((col.centerx + 6, y, half, 46), done, lambda now: self.entry_key("enter", now), size=16,
                    primary=True, enabled=ready)
        y = self.show_message(message, col, y + 52)
        self.paragraph(self.ENTRY_HINTS[kind], 14, MUTED, col, y + 8, center=True)
        self.draw_entry_keyboard(self.entry_keyboard_area())

    def draw_sync(self, now):
        """The Account screen: signed in (with Sign out / Delete account) or the optional sign-in."""
        w, h = self.size
        self.draw_screen_header("ACCOUNT")
        sync = self.sync
        col = self.column()
        y = self.paragraph(sync.status(now), 15, TEXT, col, 84, center=True) + 18
        busy = self.pending_key() in ("sign out", "delete account") or sync.waiting("detach", "account_delete")
        if sync.signed_in:
            self.text("Signed in as", 13, MUTED, topleft=(col.x, y))
            self.text(sync.signed_in, 20, TEXT, topleft=(col.x, y + 18))
            y = self.paragraph("Your games are saved to your account. Sign in on your other phones and computers "
                               "to see them there too.", 15, MUTED, col, y + 50) + 10
            half = (col.w - 12) // 2
            if not busy:
                self.button((col.x, y, half, 44), "Sign out", self.sign_out, size=16)
                self.button((col.x + half + 12, y, half, 44), "Delete account", self.delete_account, size=16)
            y = self.paragraph("Signing out takes your games off this device; they stay safe in your account.", 13,
                               MUTED, col, y + 54)
        else:
            self.text("SAVE YOUR STATS", 13, MUTED, topleft=(col.x, y))
            y = self.paragraph("Sign in and your games are kept in your account: sign in on your phone, tablet "
                               "and computer to see them everywhere, and a new phone or a cleared browser gets "
                               "them back. It's optional: you can keep playing without one.", 15, MUTED, col,
                               y + 22) + 10
            if not busy:
                self.button((col.x, y, col.w, 46), "Sign in or create account",
                            lambda now: self.sync.open_account_form(), size=16, primary=True)
            y += 46
        y = self.show_message(sync.message, col, y + 8)
        self.button((col.centerx - 160, y + 14, 320, 38), "Comparing with friends? Open Friends",
                    lambda now: self.open_friends(), size=14)
        lines = self.wrap(self.PRIVACY_NOTE, 13, col.w)
        self.paragraph(self.PRIVACY_NOTE, 13, MUTED, col, max(y + 64, h - 16 - len(lines) * 18))

    def sign_out(self, now):
        self.undoable("Signing out", self.sync.sign_out, now, key="sign out")

    def delete_account(self, now):
        self.undoable("Deleting your account and its games", self.sync.delete_account, now, key="delete account")

    # The sign-in form. In a browser it's a real HTML form (web/template.tmpl), so Safari can fill in
    # the email, password and emailed code; on a computer it's drawn here.

    def publish_auth_form(self):
        form = self.sync.auth_form
        spec = json.dumps(form, sort_keys=True) if form else ""
        if spec == self.published_auth:
            return
        try:
            import platform
            if form:
                platform.window.wordleAuthShow(spec)
            else:
                platform.window.wordleAuthHide()
            self.published_auth = spec
        except Exception:
            pass

    def poll_auth_form(self, now):
        if not self.sync.auth_form:
            return
        try:
            import platform
            text = str(platform.window.wordleAuthTake() or "")
            event = json.loads(text) if text else None
        except Exception:
            return
        if isinstance(event, dict):
            self.sync.account_action(str(event.get("action", "")), str(event.get("email", "")),
                                     str(event.get("password", "")), str(event.get("code", "")), now)

    AUTH_TITLES = {"signin": "Sign in to save your stats", "signup": "Create an account", "code": "Email me a code",
                   "verify": "Enter the code", "newpassword": "Choose a new password"}
    AUTH_FIELDS = {"signin": [("email", "Email"), ("password", "Password")],
                   "signup": [("email", "Email"), ("password", "New password (6 or more characters)")],
                   "code": [("email", "Email")], "verify": [("code", "6-digit code from the email")],
                   "newpassword": [("password", "New password (6 or more characters)")]}
    AUTH_SUBMIT = {"signin": ("Sign in", "signin"), "signup": ("Create account", "signup"),
                   "code": ("Email me a code", "send_code"), "verify": ("Continue", "verify"),
                   "newpassword": ("Save password", "set_password")}
    AUTH_LINKS = {"signin": [("Email me a code instead", "mode:code"), ("Forgot password?", "mode:reset"),
                             ("Create an account", "mode:signup")],
                  "signup": [("I already have an account", "mode:signin")],
                  "code": [("Use my password instead", "mode:signin")],
                  "verify": [("Send a new code", "resend"), ("Use a different email", "mode:code")],
                  "newpassword": []}

    def auth_state(self):
        """The Mac form's typed values, reset when the form changes screens."""
        form = self.sync.auth_form
        key = (form["mode"], form.get("purpose"))
        if self.auth_input.get("mode") != key:
            fields = [name for name, _label in self.AUTH_FIELDS[form["mode"]]]
            self.auth_input = {"mode": key, "email": form.get("email", ""), "password": "", "code": "",
                               "field": next((f for f in fields if not (f == "email" and form.get("email"))),
                                             fields[0])}
        return self.auth_input

    def auth_do(self, action, now):
        state = self.auth_state()
        self.sync.account_action(action, state["email"], state["password"], state["code"], now)

    def auth_key(self, event, now):
        state = self.auth_state()
        fields = [name for name, _label in self.AUTH_FIELDS[self.sync.auth_form["mode"]]]
        if event.key == pygame.K_ESCAPE:
            self.auth_do("cancel", now)
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.auth_do(self.AUTH_SUBMIT[self.sync.auth_form["mode"]][1], now)
        elif event.key == pygame.K_TAB:
            at = fields.index(state["field"]) if state["field"] in fields else -1
            state["field"] = fields[(at + 1) % len(fields)]
        elif event.key == pygame.K_BACKSPACE:
            state[state["field"]] = state[state["field"]][:-1]
        elif event.key == pygame.K_v and event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            try:
                pasted = pygame.scrap.get_text() or ""
            except Exception:
                pasted = ""
            state[state["field"]] = (state[state["field"]] + pasted.strip())[:200]
        elif not event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            char = getattr(event, "unicode", "")
            if len(char) == 1 and char.isprintable() and len(state[state["field"]]) < 200:
                if state["field"] != "code" or char.isdigit():
                    state[state["field"]] += char

    def draw_auth_form(self, now):
        """The Mac app's sign-in form (a browser shows a real HTML form instead)."""
        form = self.sync.auth_form
        state = self.auth_state()
        w, h = self.size
        mode = form["mode"]
        self.clickables.append((pygame.Rect(0, 0, w, h), lambda now: None, "auth:backdrop"))
        shade = pygame.Surface(self.full_screen.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 150))
        self.full_screen.blit(shade, (0, 0))
        panel_w = min(460, w - 32)
        col = pygame.Rect(w // 2 - panel_w // 2 + 20, 0, panel_w - 40, 0)
        fields = self.AUTH_FIELDS[mode]
        links = self.AUTH_LINKS[mode]
        if mode == "verify" and form.get("purpose") == "signup":
            links = [("Send a new code", "resend"), ("Used the link in the email? Sign in", "mode:signin"),
                     ("Use a different email", "mode:signup")]
        notes = [t for t in (form.get("error"), form.get("note")) if t]
        panel_h = 70 + 64 * len(fields) + 24 * sum(len(self.wrap(t, 14, col.w)) for t in notes) + 58 + 46 * (
            len(links) + 1) + 16
        panel = pygame.Rect(w // 2 - panel_w // 2, max(16, (h - panel_h) // 2), panel_w, panel_h)
        self.rrect(PANEL, panel, 16)
        title = self.AUTH_TITLES[mode] if form.get("purpose") != "reset" or mode != "code" else "Reset your password"
        self.text(title, 20, TEXT, topleft=(col.x, panel.y + 18))
        y = panel.y + 56
        for name, label in fields:
            box = pygame.Rect(col.x, y + 18, col.w, 40)
            self.text(label, 13, MUTED, topleft=(col.x, y))
            focused = state["field"] == name
            self.rrect(BG, box, 8)
            self.rrect(TYPED_BORDER if focused else EMPTY_BORDER, box, 8, 2)
            shown = "•" * len(state[name]) if name == "password" else state[name]
            cursor = "|" if focused and (pygame.time.get_ticks() // 500) % 2 else ""
            self.text((shown + cursor)[-40:], 16, TEXT, bold=False, midleft=(box.x + 10, box.centery))
            self.clickables.append((box, lambda now, n=name: state.update(field=n), "auth:" + name))
            y += 64
        if form.get("error"):
            y = self.paragraph(form["error"], 14, ERROR_TEXT, col, y)
        if form.get("note"):
            y = self.paragraph(form["note"], 14, SOLVED_TEXT, col, y)
        label, submit = self.AUTH_SUBMIT[mode]
        self.button((col.x, y + 8, col.w, 46), "One moment..." if form.get("busy") else label,
                    lambda now, a=submit: self.auth_do(a, now), size=17, primary=True, enabled=not form.get("busy"))
        y += 62
        for label, action in links + [("Cancel", "cancel")]:
            self.button((col.x, y, col.w, 38), label, lambda now, a=action: self.auth_do(a, now), size=15)
            y += 46

    def draw_code_boxes(self, col, y, typed):
        box, gap, dash = 40, 6, 18
        total = 8 * box + 6 * gap + dash
        x = col.centerx - total / 2
        for i in range(8):
            cell = pygame.Rect(round(x), y, box, 48)
            self.rrect(EMPTY_BORDER if i >= len(typed) else TYPED_BORDER, cell, 8, 2)
            if i < len(typed):
                self.text(typed[i], 24, TEXT, center=cell.center)
            x += box + (dash if i == 3 else gap)
        self.text("-", 24, MUTED, center=(col.centerx, y + 24))
        return y + 48 + 14

    def draw_name_box(self, col, y, typed):
        box = pygame.Rect(col.centerx - 160, y, 320, 48)
        self.rrect(TYPED_BORDER if typed else EMPTY_BORDER, box, 10, 2)
        self.text(typed + ("|" if (pygame.time.get_ticks() // 500) % 2 else " "), 22, TEXT, center=box.center)
        return box.bottom + 14

    def draw_entry_keyboard(self, area):
        """Letters (and a space bar for names) for whatever self.entry is typing."""
        kind = self.entry["kind"]
        rows = KEY_ROWS + ([["space"]] if kind == "name" else [])
        gap = 6
        key_h = int(min(52, (area.h - (len(rows) - 1) * gap) / len(rows)))
        width = min(area.w, 640)
        key_w = (width - 9 * gap) / 10
        top = area.bottom - len(rows) * key_h - (len(rows) - 1) * gap
        text = self.entry["text"].strip()
        ready = bool(text) if kind == "name" else len(text) == 8
        enter_label = {"friend": "ADD", "name": "SAVE"}[kind]
        for r, row in enumerate(rows):
            widths = [key_w * 1.55 if k in ("enter", "back") else key_w * 5 if k == "space" else key_w for k in row]
            x = area.centerx - (sum(widths) + gap * (len(row) - 1)) / 2
            y = top + r * (key_h + gap)
            for key, key_width in zip(row, widths):
                rect = pygame.Rect(round(x), y, round(key_width), key_h)
                color = ACCENT if key == "enter" and ready else KEY
                if rect.collidepoint(self.mouse()):
                    color = lighten(color, 0.14)
                self.rrect(color, rect, 8)
                label = {"enter": enter_label, "back": "DEL", "space": "SPACE"}.get(key, key.upper())
                self.text(label, min(16 if len(label) > 1 else 22, key_h * 0.4), TEXT, center=rect.center)
                self.clickables.append((rect, lambda now, key=key: self.entry_key(key, now), "key:" + key))
                x += key_width + gap

    # Friends

    def stop_sharing(self, now):
        self.undoable("Stopping sharing", self.sync.stop_sharing, now, key="stop")

    def remove_friend(self, friend_id, name, now):
        self.undoable("Removing %s" % name, lambda now: self.sync.remove_friend(friend_id, now), now,
                      key=("remove", friend_id))

    def friend_rows(self, mode, today):
        """[(name, today's result, Stats, friend id or None for you)], you first. Names needn't be
        unique (friends are matched by code), so a name shared in the list gets a short tag."""
        def compute():
            data = self.sync.friends_data()
            mine = [g for g in self.history.games if g.get("daily") is not None]
            me = data["profile"]["name"] if data["profile"] else "You"
            names = [str(f.get("name", "?")) for f in data["list"]]
            counts = {}
            for name in names + [me]:
                counts[name.lower()] = counts.get(name.lower(), 0) + 1
            rows = [("%s (you)" % me,) + friend_summary(mine, mode, today) + (None,)]
            for friend, name in zip(data["list"], names):
                if counts[name.lower()] > 1:
                    name = "%s · %s" % (name, str(friend["id"]).replace("-", "")[:3].upper())
                rows.append((name,) + friend_summary(friend_games(friend.get("games") or [], mode), mode, today)
                            + (friend["id"],))
            return rows
        removing = self.pending_key()
        return [r for r in self.memo(("friends", mode, today), compute)
                if not (r[3] is not None and removing == ("remove", r[3]))]

    def draw_friends(self, now):
        w, h = self.size
        self.draw_screen_header("FRIENDS")
        sync, screen = self.sync, self.friends_screen
        col = self.column()
        data = sync.friends_data()
        profile = data["profile"]
        if not sync.enabled:
            self.paragraph("Friends needs the server, which isn't set up in this version.", 16, MUTED, col, 100,
                           center=True)
            return
        if self.entry and self.entry["kind"] in ("name", "friend"):
            label = "Your name (friends see it)" if self.entry["kind"] == "name" else "Your friend's code"
            self.draw_entry(col, 80, label, sync.friends_message)
            return
        waiting = sync.waiting("profile", "friend_add", "friend_remove")
        if profile is None:
            y = self.paragraph(self.FRIENDS_NOTE, 15, MUTED, col, 88)
            if waiting:
                self.text("Asking the server...", 16, MUTED, bold=False, center=(col.centerx, y + 30))
            else:
                self.button((col.centerx - 110, y + 16, 220, 46), "Choose a name",
                            lambda now: self.start_entry("name"), size=16, primary=True)
            y = self.show_message(sync.friends_message, col, y + 70)
            y = self.paragraph("Want your own games on your phone and computer too? That's your Account.", 14, MUTED,
                               col, y + 24, center=True)
            self.button((col.centerx - 90, y + 6, 180, 40), "Open Account", lambda now: self.open_sync(), size=15)
            return

        # Your name and code.
        self.text("Sharing as", 13, MUTED, topleft=(col.x, 78))
        self.text(profile.get("name", ""), 20, TEXT, topleft=(col.x, 96))
        self.button((col.right - 120, 82, 120, 36), "Change name", lambda now: self.start_entry("name"), size=14)
        self.text("Your friend code: give it to friends", 13, MUTED, topleft=(col.x, 130))
        self.text(format_code(str(profile.get("code", ""))), 24, TEXT, topleft=(col.x, 148))
        self.button((col.right - 120, 136, 120, 36), "New code", lambda now: self.sync.new_friend_code(now), size=14,
                    enabled=not waiting)
        half = (col.w - 12) // 2
        self.button((col.x, 188, half, 40), "Add a friend", lambda now: self.start_entry("friend"), size=15,
                    primary=True, enabled=not waiting)
        self.segmented((col.x + half + 12, 188, half, 40), [("w", "Wordle"), ("q", "Quordle")], screen["mode"],
                       lambda value: screen.update(mode=value), "friends")
        y = self.show_message(sync.friends_message, col, 232)

        # The table: you, then friends.
        top = max(y + 6, 246)
        cols = [("TODAY", 0.45), ("STREAK", 0.59), ("WIN %", 0.72), ("PLAYED", 0.84)]
        self.text("NAME", 12, MUTED, midleft=(col.x + 8, top + 8))
        for label, at in cols:
            self.text(label, 12, MUTED, center=(col.x + col.w * at, top + 8))
        bottom = h - 72
        box = pygame.Rect(col.x - 8, top + 20, col.w + 16, bottom - top - 28)
        self.rrect(PANEL, box, 12)
        area = self.scroll_area = box.inflate(-8, -8)
        rows = self.friend_rows(screen["mode"], self.today())
        row_h = 44
        content_h = len(rows) * row_h + (60 if len(rows) == 1 else 0)
        screen["scroll"] = max(0, min(screen["scroll"], content_h - area.h))
        self.screen.set_clip(self.px_rect(area))
        for i, (name, result, stats, friend_id) in enumerate(rows):
            row = pygame.Rect(area.x, area.y + i * row_h - screen["scroll"], area.w, row_h - 4)
            if row.bottom < area.y or row.y > area.bottom:
                continue
            if friend_id is None:
                self.rrect(lighten(PANEL, 0.06), row, 8)
            shown = name if len(name) <= 22 else name[:21] + "..."
            self.text(shown, 16, TEXT, midleft=(row.x + 10, row.centery))
            values = [result, stats.current_streak, "%d" % stats.win_percent if stats.played else "-", stats.played]
            for (label, at), value in zip(cols, values):
                self.text(str(value), 16, SOLVED_TEXT if label == "TODAY" and value not in ("-",) and
                          not str(value).startswith("X") else TEXT, center=(col.x + col.w * at, row.centery))
            if friend_id is not None:
                x_btn = pygame.Rect(0, 0, 30, 30)
                x_btn.midright = (row.right - 6, row.centery)
                hit = x_btn.clip(area)
                self.rrect(BUTTON, x_btn, 8)
                self.text("x", 16, MUTED, center=x_btn.center)
                if hit.h > 0:
                    self.clickables.append((hit, lambda now, f=friend_id, n=name: self.remove_friend(f, n, now),
                                            "remove:%s" % name))
        if len(rows) == 1:
            self.paragraph("No friends yet. Give a friend your code, or add theirs.", 14, MUTED,
                           pygame.Rect(area.x + 10, 0, area.w - 20, 0), area.y + row_h + 8)
        self.screen.set_clip(None)
        self.draw_scrollbar(box, area, content_h, screen["scroll"])
        if self.pending_key() != "stop":
            self.button((col.centerx - 130, h - 60, 260, 44), "Stop sharing", self.stop_sharing, size=15,
                        enabled=not waiting)

    # ----- game screen ---------------------------------------------------

    def draw_game(self, now):
        w, h = self.size
        header_h = 64
        self.draw_header(w, header_h)

        keyboard_h = min(186, int(h * 0.25))
        keyboard = pygame.Rect(16, h - keyboard_h - 16, w - 32, keyboard_h)
        # Messages get their own strip under the header so they never cover a board.
        strip = pygame.Rect(16, header_h + 6, w - 32, 30)
        area = pygame.Rect(16, strip.bottom + 14, w - 32, keyboard.y - strip.bottom - 28)
        self.draw_boards(now, area)
        self.draw_message_strip(now, strip)

        # The words-left list and definitions take the keyboard's spot (like the result panel) so
        # the boards stay visible.
        if self.word_list:
            self.draw_word_list(keyboard)
        elif self.definition:
            self.draw_definition(keyboard)
        elif self.result_at is not None:
            self.draw_result(now, keyboard)
        else:
            self.draw_keyboard(keyboard)

    def draw_word_list(self, panel):
        """Every answer that was still possible after one guess on one board, in place of the keyboard."""
        info = self.word_list
        board, row = info["board"], info["row"]
        words = self.game.possible_after(board, row + 1)
        guess = self.game.boards[board].history()[row][0]

        self.rrect(PANEL, panel, 14)
        where = "Board %d, after " % (board + 1) if len(self.game.boards) > 1 else "After "
        title = self.text(where + guess.upper(), 17, TEXT, topleft=(panel.x + 16, panel.y + 14))
        noun = "word" if len(words) == 1 else "words"
        self.text("%d possible %s" % (len(words), noun), 14, MUTED, bold=False,
                  midleft=(title.right + 12, title.centery))
        self.button((panel.right - 16 - 72, panel.y + 9, 72, 30), "Close", self.close_panel, size=14)

        area = self.scroll_area = pygame.Rect(panel.x + 16, panel.y + 48, panel.w - 40, panel.h - 48 - 8)
        col_w, line_h = 74, 24
        cols = max(1, area.w // col_w)
        col_w = area.w / cols
        lines = (len(words) + cols - 1) // cols
        content_h = lines * line_h
        info["scroll"] = max(0, min(info["scroll"], content_h - area.h))
        scroll = info["scroll"]

        self.screen.set_clip(self.px_rect(area))
        first = int(scroll // line_h)
        mouse = self.mouse()
        pickable = self.accepting_input()
        for n in range(first * cols, min(len(words), (first + area.h // line_h + 2) * cols)):
            word = words[n]
            x = area.x + (n % cols) * col_w
            y = area.y + (n // cols) * line_h - scroll
            cell = pygame.Rect(x - 6, y + 1, col_w - 6, line_h - 2)
            hit = cell.clip(area)
            chosen = self.typed == word
            hovered = pickable and hit.collidepoint(mouse)
            if chosen or hovered:
                self.rrect(ACCENT if chosen else BUTTON, cell, 6)
            self.text(word.upper(), 15, TEXT, bold=chosen, topleft=(x, y + 3))
            if pickable and hit.h > 0:
                # Clicking a word types it in, like a hint; Enter plays it.
                self.clickables.append((hit, lambda now, word=word: self.pick_word(word, now), "word:" + word))
        self.screen.set_clip(None)
        self.draw_scrollbar(panel, area, content_h, scroll)

    def draw_scrollbar(self, panel, area, content_h, scroll):
        """A scrollbar at the panel's right edge when the content is taller than its area."""
        if content_h > area.h:
            track = pygame.Rect(panel.right - 12, area.y, 4, area.h)
            thumb_h = max(24, area.h * area.h / content_h)
            thumb = pygame.Rect(track.x, area.y + (area.h - thumb_h) * scroll / (content_h - area.h), 4, thumb_h)
            self.rrect(BUTTON, track, 2)
            self.rrect(MUTED, thumb, 2)

    def draw_definition(self, panel):
        """What a guessed word means, in place of the keyboard."""
        info = self.definition
        definition = define(info["word"])
        self.rrect(PANEL, panel, 14)
        title = self.text(info["word"].upper(), 17, TEXT, topleft=(panel.x + 16, panel.y + 14))
        if definition.base:
            # "plural of bird", trimmed so it never runs under the Close button.
            note = definition.note
            room = panel.right - 16 - 72 - 12 - (title.right + 12)
            while note and self.fonts.get(14 * self.scale, False).size(note)[0] > room * self.scale:
                note = note[:-2].rstrip() + "…"
            self.text(note, 14, MUTED, bold=False, midleft=(title.right + 12, title.centery))
        self.button((panel.right - 16 - 72, panel.y + 9, 72, 30), "Close", self.close_panel, size=14)

        area = self.scroll_area = pygame.Rect(panel.x + 16, panel.y + 48, panel.w - 40, panel.h - 48 - 8)
        size, line_h, label_w = 15, 20, 98
        if not definition.found:
            message = ("No definition in the game's dictionary. It has every possible answer, "
                       "but not every rare guess word.")
            for n, line in enumerate(self.wrap(message, 14, area.w)):
                self.text(line, 14, MUTED, bold=False, topleft=(area.x, area.y + n * line_h))
            return
        # Lay out every sense: its part of speech in a narrow column, the meaning wrapped beside it,
        # and an example sentence (if there is one) under the meaning.
        lines = []  # (y, x, text, color)
        y, last_pos = 0, None
        for pos, meaning, example in definition.senses:
            if pos and pos != last_pos:  # "verb" once for a run of verb meanings
                lines.append((y, 0, pos, MUTED))
            last_pos = pos
            for line in self.wrap(meaning, size, area.w - label_w):
                lines.append((y, label_w, line, TEXT))
                y += line_h
            if example:
                for line in self.wrap("\u201c%s\u201d" % example, size, area.w - label_w):
                    lines.append((y, label_w, line, MUTED))
                    y += line_h
            y += 8
        content_h = y - 8
        info["scroll"] = max(0, min(info["scroll"], content_h - area.h))
        scroll = info["scroll"]

        self.screen.set_clip(self.px_rect(area))
        for line_y, x, line, color in lines:
            top = area.y + line_y - scroll
            if area.y - line_h < top < area.bottom:
                self.text(line, size if x else 14, color, bold=False, topleft=(area.x + x, top + (0 if x else 1)))
        self.screen.set_clip(None)
        self.draw_scrollbar(panel, area, content_h, scroll)

    def wrap(self, text, size, width, bold=False):
        """Split text into lines that fit width points at this font size."""
        key = (text, size, round(width), bold, self.scale)
        lines = self.wrap_cache.get(key)
        if lines is None:
            font = self.fonts.get(size * self.scale, bold)
            lines, line = [], ""
            for word in text.split():
                trial = line + " " + word if line else word
                if line and font.size(trial)[0] > width * self.scale:
                    lines.append(line)
                    line = word
                else:
                    line = trial
            lines.append(line)
            if len(self.wrap_cache) > 300:
                self.wrap_cache.clear()
            self.wrap_cache[key] = lines
        return lines

    def draw_header(self, w, h):
        game = self.game
        bw = 84 if w >= 640 else 62
        self.button((16, 14, bw, 36), "Menu", lambda now: self.go_to_menu(), size=16)
        self.button((w - 16 - bw, 14, bw, 36), "New", lambda now: self.start(self.mode), size=16)
        if not self.accepting_input():
            self.hint_picker = False
        # "Solve" once the answer is certain (one board left, one word possible): it fills in the answer.
        solve = self.accepting_input() and game.known_answer() is not None
        hint_rect = self.hint_rect = self.button((w - 24 - 2 * bw, 14, bw, 36), "Solve" if solve else "Hint",
                                                 self.hint_button, size=16, primary=self.hint_picker,
                                                 enabled=self.accepting_input() and not self.thinking)
        self.hint_hover = (len(game.boards) > 1 and self.accepting_input() and not self.thinking and not solve
                           and not self.hint_picker and hint_rect.collidepoint(self.mouse()))

        name = "WORDLE" if self.mode == "w" else "QUORDLE"
        if self.daily is not None:
            name += " #%d" % self.daily
        title = self.text(name, 26, TEXT, center=(w // 2, 25))
        if self.release:
            self.draw_release_badge((title.right + 8, title.centery), "midleft")
        if game.over:
            status = ""
        elif game.remaining_guesses == 1:
            status = "1 guess left. Don't get nervous!"
        else:
            status = "%d guesses left" % game.remaining_guesses
        if status:
            self.text(status, 14, MUTED, bold=False, center=(w // 2, 50))
        self.rrect(EMPTY_BORDER, (0, h, w, 1), 0)

    def draw_message_strip(self, now, strip):
        """The hint chooser if it's open, else the newest message, else a quiet line about what's hovered."""
        if self.hint_picker:
            self.draw_hint_picker(strip)
            return
        live = [t for t in self.toasts if now - t[1] < t[2]]
        if live:
            text, start, duration = live[-1]
            pill = self.make_pill(text, strip.w)
            fade = duration - (now - start)
            if fade < 300:
                pill.set_alpha(int(255 * fade / 300))
            self.screen.blit(pill, pill.get_rect(center=self.px_rect(strip).center))
            return
        if self.thinking:
            label = "Thinking..."
        elif self.hint_hover:
            label = "Hint: choose all boards or just one"
        else:
            return
        self.text(label, 14, MUTED, bold=False, center=strip.center)

    def draw_hint_picker(self, strip):
        """Hint for: [All boards] [1] [2] [3] [4] [Cancel], centered in the message strip."""
        h = 28
        items = [("All boards", 96, lambda now: self.pick_hint(now), True)]
        for i, board in enumerate(self.game.boards):
            items.append((str(i + 1), 38, lambda now, i=i: self.pick_hint(now, i), not board.solved))
        items.append(("Cancel", 72, lambda now: setattr(self, "hint_picker", False), True))
        label_w, gap = 66, 6
        total = label_w + sum(width for _, width, _, _ in items) + gap * len(items)
        x = strip.centerx - total // 2
        self.text("Hint for", 14, MUTED, bold=False, midleft=(x, strip.centery))
        x += label_w + gap
        for label, width, action, enabled in items:
            self.button((x, strip.centery - h // 2, width, h), label, action, size=14,
                        primary=label == "All boards", enabled=enabled)
            x += width + gap

    def board_layout(self, area):
        game = self.game
        n, rows, cols = len(game.boards), game.max_guesses, game.word_length
        gap_ratio, board_gap = 0.12, 26
        count_ratio = 1.0  # room right of each board for the "words left" counts, in tiles
        define_ratio = 0.8  # room left of each board for the "?" (definition) buttons, in tiles
        cap = 66 if n == 1 else 46
        grids = [(1, 1)] if n == 1 else [(2, 2), (4, 1)]

        best = None
        for gx, gy in grids:
            tile_w = (area.w - board_gap * (gx - 1)) / gx / (cols + gap_ratio * (cols - 1) + count_ratio + define_ratio)
            tile_h = (area.h - board_gap * (gy - 1)) / gy / (rows + gap_ratio * (rows - 1))
            tile = int(min(tile_w, tile_h, cap))
            # Prefer the 2x2 grid unless the single row gives clearly bigger tiles.
            if best is None or tile > best[0] * 1.15:
                best = (tile, gx, gy)
        tile, gx, gy = best

        gap = max(3, round(tile * gap_ratio))
        board_w = cols * tile + (cols - 1) * gap
        board_h = rows * tile + (rows - 1) * gap
        count_w = round(tile * count_ratio)
        define_w = round(tile * define_ratio)
        slot_w = define_w + board_w + count_w
        total_w = gx * slot_w + (gx - 1) * board_gap
        total_h = gy * board_h + (gy - 1) * board_gap
        # Wordle keeps its board centered with the buttons hanging off the sides; Quordle centers
        # each "?" + board + counts slot.
        x0 = area.centerx - (board_w // 2 if n == 1 else total_w // 2 - define_w)
        y0 = area.centery - total_h // 2
        rects = [pygame.Rect(x0 + (i % gx) * (slot_w + board_gap), y0 + (i // gx) * (board_h + board_gap),
                             board_w, board_h) for i in range(n)]
        self.board_grid = (gx, gy)
        return rects, tile, gap

    def bouncing(self, board_index, now):
        start = self.bounces.get(board_index)
        return start is not None and now - start < BOUNCE_MS + BOUNCE_STAGGER_MS * self.game.word_length

    def board_done(self, board_index):
        """Solved, and its winning row has finished flipping."""
        revealing = self.reveal is not None and board_index in self.reveal["rows"]
        return self.game.boards[board_index].solved and not revealing

    def draw_boards(self, now, area):
        rects, tile, gap = self.board_layout(area)
        multi = len(rects) > 1
        mouse = self.mouse()
        hint = self.shown_hint if self.shown_hint and self.typed == self.shown_hint.word else None
        if hint is None:
            self.shown_hint = None
        for i, (board, rect) in enumerate(zip(self.game.boards, rects)):
            hit = rect.inflate(gap * 2 + 10, gap * 2 + 10)
            if multi and self.accepting_input() and not board.solved:
                thinking_here = self.thinking and self.thinking["board"] == i
                if self.hint_picker or thinking_here:
                    # While choosing a hint, every open board is a target (tap one for a hint on just it).
                    self.rrect(PANEL, hit, 12)
                    if self.hint_picker and hit.collidepoint(mouse):
                        self.rrect(TYPED_BORDER, hit, 12, 2)
                if self.hint_picker:
                    self.clickables.append((hit, lambda now, i=i: self.pick_hint(now, i), "board:%d" % (i + 1)))
            if multi and hint and i in (hint.sure_boards or hint.possible):
                # Outline the boards the hint in the typed row was chosen for.
                self.rrect(ACCENT, hit, 12, 2)

            self.draw_board(now, i, board, rect, tile, gap)

            # Dim finished boards while play continues; show everything at full strength once it's over.
            if multi and self.board_done(i) and not self.bouncing(i, now) and self.result_at is None:
                area_px = self.px_rect(rect.inflate(8, 8))
                shade = pygame.Surface(area_px.size, pygame.SRCALPHA)
                shade.fill(BG + (150,))
                self.screen.blit(shade, area_px)

    def draw_board(self, now, board_index, board, rect, tile, gap):
        game = self.game
        rows = board.rows()
        reveal_row = self.reveal["rows"].get(board_index) if self.reveal else None
        input_row = len(rows) if not board.solved and not game.over else None

        shake = 0
        if self.shake_start is not None:
            p = (now - self.shake_start) / SHAKE_MS
            if p < 1:
                shake = math.sin(p * math.pi * 6) * tile * 0.18 * (1 - p)
            else:
                self.shake_start = None

        for r in range(game.max_guesses):
            y = rect.y + r * (tile + gap)
            for c in range(game.word_length):
                cell = pygame.Rect(rect.x + c * (tile + gap), y, tile, tile)
                if r < len(rows):
                    letter, color = rows[r][c]
                    if r == reveal_row:
                        p = clamp01((now - self.reveal["start"] - c * FLIP_STAGGER_MS) / FLIP_MS)
                        if p <= 0:
                            self.draw_tile(cell, letter, "typed")
                        else:
                            self.draw_tile(cell, letter, "typed" if p < 0.5 else color,
                                           scale_y=abs(math.cos(math.pi * p)) if p < 1 else 1)
                    else:
                        if r == len(rows) - 1 and self.bouncing(board_index, now):
                            p = clamp01((now - self.bounces[board_index] - c * BOUNCE_STAGGER_MS) / BOUNCE_MS)
                            cell = cell.move(0, -math.sin(math.pi * p) * tile * 0.3)
                        self.draw_tile(cell, letter, color)
                elif r == input_row:
                    letter = self.typed[c] if c < len(self.typed) else ""
                    scale = 1.0
                    if self.pop and self.pop[0] == c:
                        p = (now - self.pop[1]) / POP_MS
                        if p < 1:
                            scale = 1 + 0.1 * math.sin(math.pi * p)
                    self.draw_tile(cell.move(shake, 0), letter, "typed" if letter else "empty", scale=scale)
                else:
                    self.draw_tile(cell, "", "empty")

            if r < len(rows) and r != reveal_row:
                self.draw_count(board_index, r, rect.right + gap, y, tile)
                self.draw_define(board_index, r, rect.x - gap, y, tile)

    def draw_define(self, board_index, row, right, y, tile):
        """A small "?" button left of a guessed row that shows what its word means."""
        size = min(18, max(11, round(tile * 0.42)))
        button = pygame.Rect(0, 0, size + 8, size + 8)
        button.midright = (right, y + tile // 2)
        hovered = button.collidepoint(self.mouse())
        active = self.definition and (self.definition["board"], self.definition["row"]) == (board_index, row)
        if active or hovered:
            self.rrect(ACCENT if active else BUTTON, button, button.h // 2)
        else:
            self.rrect(EMPTY_BORDER, button, button.h // 2, 1.5)
        self.text("?", size - 1, TEXT if active or hovered else MUTED, center=button.center)
        self.clickables.append((button.inflate(4, 4), lambda now: self.open_definition(board_index, row),
                                "define:%d:%d" % (board_index + 1, row + 1)))

    def draw_count(self, board_index, row, x, y, tile):
        """How many answers were still possible after this row's guess; click to list them."""
        count = len(self.game.possible_after(board_index, row + 1))
        size = min(18, max(11, round(tile * 0.42)))
        label = str(count)
        text_w = self.fonts.render(label, size * self.scale, MUTED).get_width() / self.scale
        pill = pygame.Rect(x, 0, max(text_w + 10, size * 1.7), size + 8)
        pill.centery = y + tile // 2
        hovered = pill.collidepoint(self.mouse())
        active = self.word_list and (self.word_list["board"], self.word_list["row"]) == (board_index, row)
        if active or hovered:
            self.rrect(ACCENT if active else BUTTON, pill, pill.h // 2)
        self.text(label, size, TEXT if active or hovered else MUTED, center=pill.center)
        self.clickables.append((pill.inflate(4, 4), lambda now: self.open_word_list(board_index, row),
                                "count:%d:%d" % (board_index + 1, row + 1)))

    def key_colors(self):
        """For each board, letter -> best color seen so far (ignoring tiles still flipping)."""
        result = []
        for i, board in enumerate(self.game.boards):
            rows = board.rows()
            if self.reveal and i in self.reveal["rows"]:
                rows = rows[:self.reveal["rows"][i]]
            colors = {}
            for row in rows:
                for letter, color in row:
                    if PRIORITY[color] > PRIORITY[colors.get(letter, "gray")]:
                        colors[letter] = color
            result.append(colors)
        return result

    def draw_keyboard(self, area):
        gap = 6
        key_h = int(min(58, (area.h - 2 * gap) / 3))
        width = min(area.w, 640)
        key_w = (width - 9 * gap) / 10
        top = area.bottom - 3 * key_h - 2 * gap
        colors = self.key_colors()
        enabled = self.accepting_input()

        for r, row in enumerate(KEY_ROWS):
            widths = [key_w * 1.55 if k in ("enter", "back") else key_w for k in row]
            x = area.centerx - (sum(widths) + gap * (len(row) - 1)) / 2
            y = top + r * (key_h + gap)
            for key, key_width in zip(row, widths):
                rect = pygame.Rect(round(x), y, round(key_width), key_h)
                self.draw_key(rect, key, colors, enabled)
                x += key_width + gap

    def draw_key(self, rect, key, colors, enabled):
        hovered = enabled and rect.collidepoint(self.mouse())
        radius = 8

        def shade(color):
            return lighten(color, 0.14) if hovered else color

        if key in ("enter", "back"):
            self.rrect(shade(KEY), rect, radius)
            self.text("ENTER" if key == "enter" else "DEL", min(16, rect.h * 0.3), TEXT, center=rect.center)
            action = self.submit if key == "enter" else self.backspace
        else:
            boards = self.game.boards
            # In Quordle, a finished board's slice goes back to plain once its last row has flipped.
            per_board = [None if len(boards) > 1 and self.board_done(i) else colors[i].get(key)
                         for i in range(len(boards))]
            if len(boards) == 1:
                self.rrect(shade(key_color(per_board[0])), rect, radius)
            else:
                # One slice per board, laid out like the boards on screen.
                gx, gy = self.board_grid
                for i, color in enumerate(per_board):
                    cx, cy = i % gx, i // gx
                    x0, x1 = rect.x + rect.w * cx // gx, rect.x + rect.w * (cx + 1) // gx
                    y0, y1 = rect.y + rect.h * cy // gy, rect.y + rect.h * (cy + 1) // gy
                    self.rrect(
                        shade(key_color(color)), (x0, y0, x1 - x0, y1 - y0), 0,
                        border_top_left_radius=radius if cx == 0 and cy == 0 else 0,
                        border_top_right_radius=radius if cx == gx - 1 and cy == 0 else 0,
                        border_bottom_left_radius=radius if cx == 0 and cy == gy - 1 else 0,
                        border_bottom_right_radius=radius if cx == gx - 1 and cy == gy - 1 else 0,
                    )
            # Dim the letter when it's ruled out everywhere it still matters.
            live = [c for c in per_board if c is not None] or per_board
            ruled_out = all(c == "black" for c in live)
            self.text(key.upper(), min(22, rect.h * 0.4), KEY_RULED_OUT_TEXT if ruled_out else TEXT,
                      center=rect.center)
            action = lambda now, key=key: self.type_letter(key, now)

        if enabled:
            self.clickables.append((rect, action, "key:" + key))

    def draw_result(self, now, area):
        game = self.game
        slide = ease_out(clamp01((now - self.result_at) / RESULT_SLIDE_MS))
        card = area.move(0, int((1 - slide) * 30))
        self.rrect(PANEL, card, 18)

        used = len(game.guesses)
        if game.won:
            if len(game.boards) == 1:
                title, detail = WIN_MESSAGES.get(used, "Winner!"), "Solved in %d of %d guesses" % (used, game.max_guesses)
            else:
                title, detail = "All four solved!", "Finished with %d guesses to spare" % game.remaining_guesses
        else:
            solved = sum(board.solved for board in game.boards)
            title = "Out of guesses"
            if len(game.boards) == 1:
                detail = "The word was %s" % game.words[0].upper()
            else:
                detail = "Solved %d of 4.  Answers: %s" % (solved, "  ".join(
                    "%d %s" % (i + 1, word.upper()) for i, word in enumerate(game.words)))

        self.text(title, 26, TEXT, center=(card.centerx, card.y + 28))
        self.text(detail, 15, MUTED, bold=False, center=(card.centerx, card.y + 54))

        bw, bh, gap = 150, 38, 12
        row_w = 3 * bw + 2 * gap
        x, y = card.centerx - row_w // 2, card.y + 72
        half = (row_w - gap) // 2
        plain = self.button((x, y, half, bh), "Share", lambda now: self.share(False, now, clicked=True), size=16,
                            primary=True)
        spoilers = self.button((x + half + gap, y, half, bh), "Share with spoilers",
                               lambda now: self.share(True, now, clicked=True), size=16)
        self.share_targets = [(plain, self.share_message(False)), (spoilers, self.share_message(True))]

        y += bh + 8
        if self.daily is not None:
            buttons = [("Stats", lambda now: self.open_stats(self.mode, "daily")),
                       ("Archive", lambda now: self.open_archive(self.mode)),
                       ("Menu", lambda now: self.go_to_menu())]
            shortcuts = "S: share   Enter: stats   A: archive   Esc: menu"
        else:
            replay = "Replay word" if len(game.words) == 1 else "Replay words"
            buttons = [("New game", lambda now: self.start(self.mode)),
                       (replay, lambda now: self.start(self.mode, self.words)),
                       ("Menu", lambda now: self.go_to_menu())]
            shortcuts = "Enter: new game   R: replay   S: share   Esc: menu"
        for i, (label, action) in enumerate(buttons):
            self.button((x + i * (bw + gap), y, bw, bh), label, action, size=16)
        if card.bottom - (y + bh) > 24 and not self.touch:  # keyboard shortcuts: no keyboard on a phone
            self.text(shortcuts, 13, MUTED, bold=False, center=(card.centerx, y + bh + 17))

    def draw_toasts(self, now):
        """Floating messages for the menu (the game screen shows them in its message strip)."""
        self.toasts = [t for t in self.toasts if now - t[1] < t[2]]
        if self.release and self.scene == "menu":
            self.draw_release_badge((self.size[0] - 16, 16), "topright")
        if self.scene == "game":
            return
        w, y = self.size[0], 20
        for text, start, duration in self.toasts:
            pill = self.make_pill(text, w - 32)
            fade = duration - (now - start)
            if fade < 300:
                pill.set_alpha(int(255 * fade / 300))
            self.screen.blit(pill, pill.get_rect(midtop=(self.px(w / 2), self.px(y))))
            y += pill.get_height() / self.scale + 8

    def draw_release_badge(self, at, anchor):
        """A small orange "UAT" tag so the testing site is never mistaken for the real one."""
        label = self.fonts.render(self.release, 12 * self.scale, TEXT)
        badge = pygame.Rect(0, 0, label.get_width() / self.scale + 12, 20)
        setattr(badge, anchor, at)
        self.rrect(UAT_COLOR, badge, 6)
        self.text(self.release, 12, TEXT, center=badge.center)

    def make_pill(self, text, max_w):
        """A message pill in pixels, shrinking the font if needed so it fits max_w points."""
        size = 16
        while True:
            label = self.fonts.render(text, size * self.scale, DARK_TEXT)
            if label.get_width() + self.px(30) <= self.px(max_w) or size <= 11:
                break
            size -= 1
        pill = pygame.Surface((label.get_width() + self.px(30), self.px(28)), pygame.SRCALPHA)
        pygame.draw.rect(pill, TEXT, pill.get_rect(), border_radius=pill.get_height() // 2)
        pill.blit(label, label.get_rect(center=pill.get_rect().center))
        return pill

if __name__ == "__main__":
    App().run()
