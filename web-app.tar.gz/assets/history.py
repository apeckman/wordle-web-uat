"""Saved games and stats, kept on the device: a JSON file on a computer, localStorage in a browser.

Every finished game is kept with its guesses, so past games can be shown again and stats worked out.
A daily puzzle in progress is saved after every guess, so closing the game (or reloading the page)
carries on where you were instead of giving a fresh try.

The format is ready to sync to a server later: every game has a random id and timestamps, a finished
game is never changed again (games are only added), and each device has its own random id.
"""
import datetime
import json
import os
import sys
import uuid

import daily

FORMAT = 1
MAX_PRACTICE_GAMES = 3000  # oldest practice games are dropped past this (browser storage holds ~5 MB)


def now_iso():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def game_key(mode, number):
    return "%s:%d" % (mode, number)


# ----- where it's stored -------------------------------------------------

class MemoryStorage:
    """Nothing kept between runs (tests, or a browser that blocks storage)."""

    def __init__(self, text=None):
        self.text = text
        self.damaged = None

    def load(self):
        return self.text

    def save(self, text):
        self.text = text

    def keep_damaged(self, text):
        self.damaged = text


class FileStorage:
    def __init__(self, path):
        self.path = path

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return f.read()
        except FileNotFoundError:
            return None

    def save(self, text):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        temp = self.path + ".tmp"
        with open(temp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(temp, self.path)  # all or nothing, even if the app quits mid-write

    def keep_damaged(self, text):
        with open(self.path + ".damaged-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S"), "w",
                  encoding="utf-8") as f:
            f.write(text)


class BrowserStorage:
    """The browser's localStorage. UAT and prod share one origin (apeckman.github.io) and so one
    localStorage, so the key includes the site's folder and the two never see each other's games."""

    def __init__(self, key):
        self.key = key

    @staticmethod
    def _local():
        import platform  # pygbag's bridge to JavaScript
        return platform.window.localStorage

    def load(self):
        value = self._local().getItem(self.key)
        if value is None or str(value) in ("null", "undefined"):
            return None
        return str(value)

    def save(self, text):
        self._local().setItem(self.key, text)

    def keep_damaged(self, text):
        self._local().setItem(self.key + " damaged", text)


def data_dir():
    """Where the computer version keeps its files (WORDLE_DATA_DIR overrides it, e.g. for tests)."""
    if os.environ.get("WORDLE_DATA_DIR"):
        return os.environ["WORDLE_DATA_DIR"]
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "Wordle")
    if sys.platform == "win32":
        return os.path.join(os.environ.get("APPDATA", home), "Wordle")
    return os.path.join(os.environ.get("XDG_DATA_HOME", os.path.join(home, ".local", "share")), "wordle")


def default_storage(web):
    if web:
        try:
            import platform
            storage = BrowserStorage("wordle %s history" % platform.window.location.pathname)
            storage.load()  # some private-browsing modes refuse storage; find out now
            return storage
        except Exception:
            return MemoryStorage()
    return FileStorage(os.path.join(data_dir(), "history.json"))


# ----- games and stats ---------------------------------------------------

class Stats:
    def __init__(self, games, today, daily_games):
        self.played = len(games)
        wins = [g for g in games if g.get("won")]
        self.won = len(wins)
        self.win_percent = round(100 * self.won / self.played) if self.played else 0
        self.distribution = {}  # guesses used -> wins
        for g in wins:
            used = len(g["guesses"])
            self.distribution[used] = self.distribution.get(used, 0) + 1
        self.hinted = sum(1 for g in games if g.get("hints"))
        self.current_streak, self.best_streak = streaks(games, today) if daily_games else (0, 0)


def streaks(games, today):
    """(current, best) runs of daily puzzles won on their own day. Archive games (played on a later
    day) neither add to a streak nor break it; a loss or a missed day does."""
    on_day = {}  # puzzle number -> won, for puzzles finished on their own day
    for g in games:
        number, played_on = g.get("daily"), g.get("played_on")
        if number is None or not played_on:
            continue
        if daily.puzzle_number(datetime.date.fromisoformat(played_on)) == number:
            on_day[number] = bool(g.get("won"))
    won = {n for n, w in on_day.items() if w}
    best = 0
    for n in won:
        if n - 1 not in won:
            length = 1
            while n + length in won:
                length += 1
            best = max(best, length)
    today_number = daily.puzzle_number(today)
    if on_day.get(today_number) is False:
        return 0, best
    n = today_number if today_number in won else today_number - 1  # today not played yet: count from yesterday
    current = 0
    while n in won:
        current += 1
        n -= 1
    return current, best


class History:
    def __init__(self, storage):
        self.storage = storage
        data = self._read()
        self.device = data.get("device") or uuid.uuid4().hex
        self.games = [g for g in data.get("games", []) if isinstance(g, dict) and g.get("guesses") is not None]
        self.current = data.get("current") if isinstance(data.get("current"), dict) else {}
        self.prefs = data.get("prefs") if isinstance(data.get("prefs"), dict) else {}
        self.revision = 0  # goes up on every change (the GUI caches stats until it does)
        self._finished_daily = None  # (mode, number) -> finished game, built when first needed

    def _read(self):
        try:
            text = self.storage.load()
        except Exception:
            return {}
        if not text:
            return {}
        try:
            data = json.loads(text)
            if not isinstance(data, dict):
                raise ValueError("not a history")
            return data
        except ValueError:
            # Never throw someone's games away silently: keep the unreadable copy aside.
            try:
                self.storage.keep_damaged(text)
            except Exception:
                pass
            return {}

    def save(self):
        self.revision += 1
        data = {"format": FORMAT, "device": self.device, "prefs": self.prefs, "current": self.current,
                "games": self.games}
        try:
            self.storage.save(json.dumps(data, separators=(",", ":")))
        except Exception:
            pass  # storage full or blocked: keep playing, it just won't be remembered

    def set_pref(self, name, value):
        if self.prefs.get(name) != value:
            self.prefs[name] = value
            self.save()

    # A game is a dict: id, mode ("w"/"q"), daily (puzzle number, or None for practice), answers,
    # guesses, hints (solver hints shown), lists (words-left lists opened), started; once over also
    # won, finished and played_on (the local date it ended, which tells archive games apart).

    def start(self, mode, answers, number=None):
        game = {"id": uuid.uuid4().hex, "mode": mode, "daily": number, "answers": list(answers), "guesses": [],
                "hints": 0, "lists": 0, "started": now_iso()}
        if number is not None:
            self.current[game_key(mode, number)] = game
            self.save()
        return game

    def update(self, game):
        """Save a daily puzzle's progress (practice games are only saved once they end)."""
        if game.get("daily") is not None and "finished" not in game:
            self.current[game_key(game["mode"], game["daily"])] = game
            self.save()

    def finish(self, game, won, today):
        if "finished" in game:
            return
        game.update(won=bool(won), finished=now_iso(), played_on=today.isoformat())
        if game.get("daily") is not None:
            self.current.pop(game_key(game["mode"], game["daily"]), None)
        self.games.append(game)
        self._finished_daily = None
        practice = [g for g in self.games if g.get("daily") is None]
        if len(practice) > MAX_PRACTICE_GAMES:
            drop = {id(g) for g in practice[:len(practice) - MAX_PRACTICE_GAMES]}
            self.games = [g for g in self.games if id(g) not in drop]
        self.save()

    def daily_game(self, mode, number):
        """(game, finished) for a daily puzzle: the finished game, the one in progress, or (None, False)."""
        if self._finished_daily is None:
            self._finished_daily = {(g.get("mode"), g["daily"]): g for g in self.games if g.get("daily") is not None}
        game = self._finished_daily.get((mode, number))
        if game:
            return game, True
        game = self.current.get(game_key(mode, number))
        return (game, False) if game else (None, False)

    def stats(self, mode, kind, today):
        """Stats for "daily" puzzles (today's and the archive) or "practice" games."""
        want_daily = kind == "daily"
        games = [g for g in self.games if g.get("mode") == mode and (g.get("daily") is not None) == want_daily]
        return Stats(games, today, want_daily)
