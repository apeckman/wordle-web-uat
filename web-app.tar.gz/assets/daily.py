"""Daily puzzles: the same words for everyone on the same date, worked out with no server.

Each day's words come from a fixed shuffle of the answer list (sorted by a SHA-256 hash, so it's
identical in every Python version, on the Mac and in the browser). Puzzle #1 is EPOCH, and the date
is the player's own local date, so the next puzzle arrives at their midnight.

Wordle and Quordle use different shuffles. Wordle takes one word per day and doesn't repeat for
2,315 days (about six years); Quordle takes the next four each day.

Never change EPOCH, SALT or the word bank's contents without meaning to: it would change everyone's
puzzle for every day (test_daily.py pins the first few).

The one exception: on US Thanksgiving (the 4th Thursday of November) the daily Wordle is a Thanksgiving
word instead (thanksgiving_words(), one a year in turn; Alex, Nov 2026). Quordle and every other day are
untouched. A game already started keeps the words it was saved with (gui.start reads them back).
"""
import base64
import datetime
import hashlib

EPOCH = datetime.date(2026, 11, 1)  # Daily #1
SALT = "alex-wordle-daily-v1"
COUNTS = {"w": 1, "q": 4}

# The daily Wordle on Thanksgiving, by year in turn from 2026 (each must be in the word bank). Encoded so
# that reading the code doesn't spoil them (Alex plays it too): base64 of the comma-joined list, reversed.
# Decode with thanksgiving_words(); never print them in a commit, PR or message Alex reads.
_THANKSGIVING = "ZXRzYWIsa25haHQsZHJ1b2cscmVkaWMsZXZyYWM="
# UAT's ?turkey=1 preview plays this one instead, so a preview can't spoil the real word.
THANKSGIVING_PREVIEW_WORD = "gravy"

_orders = {}


def thanksgiving(year):
    """US Thanksgiving: the fourth Thursday of November."""
    first = datetime.date(year, 11, 1)
    return first + datetime.timedelta(days=(3 - first.weekday()) % 7, weeks=3)


def thanksgiving_words():
    return base64.b64decode(_THANKSGIVING).decode()[::-1].split(",")


def thanksgiving_word(year):
    words = thanksgiving_words()
    return words[(year - 2026) % len(words)]


def puzzle_number(day):
    """The puzzle number for a date (1 on EPOCH; never below 1, even if a clock is wrong)."""
    return max(1, (day - EPOCH).days + 1)


def puzzle_date(number):
    return EPOCH + datetime.timedelta(days=number - 1)


def _order(word_bank, mode):
    key = (mode, tuple(word_bank))
    if key not in _orders:
        _orders[key] = sorted(word_bank, key=lambda w: hashlib.sha256((SALT + mode + w).encode()).hexdigest())
    return _orders[key]


def daily_words(word_bank, mode, number):
    """The answers for puzzle `number`: one word for Wordle ("w"), four for Quordle ("q")."""
    if mode == "w":
        day = puzzle_date(number)
        if day == thanksgiving(day.year) and thanksgiving_word(day.year) in word_bank:
            return [thanksgiving_word(day.year)]
    order = _order(word_bank, mode)
    count = COUNTS[mode]
    start = (number - 1) * count
    return [order[(start + k) % len(order)] for k in range(count)]


def describe(number, today=None):
    """A short date label for a puzzle: "Today", "Yesterday" or like "Sat, Nov 7"."""
    day = puzzle_date(number)
    if today is not None:
        if day == today:
            return "Today"
        if day == today - datetime.timedelta(days=1):
            return "Yesterday"
    return "%s, %s %d" % (DAYS[day.weekday()], MONTHS[day.month - 1], day.day)


DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]  # not strftime: that depends on the locale
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
