"""Word lists, bundled in Media/ so the game behaves the same on every computer (and in a browser).

- Media/word_bank: the possible answers (2,315 words).
- Media/valid_guesses: every word accepted as a guess (14,855 words, answers included), the
  standard Wordle list from https://github.com/tabatkins/wordle-list.
- Media/other_lengths: words of 3, 4, 6 and 7 letters, for custom Wordles of those lengths (Alex,
  Nov 2026): the ENABLE word list (public domain) plus the Wordnik word list (MIT), which adds the
  newer words and forms ENABLE lacks (TAPINGS), minus obscene words and slurs; 50,495 words, built by
  tools/make_other_lengths.py. Read only
  when a custom Wordle needs it (load_length), so the usual launch doesn't pay for it.
"""
import os
import sys


def resource_path(rel_path):
    """Find a bundled file whether running from source or from a PyInstaller build."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel_path)


def _read(name):
    with open(resource_path(os.path.join("Media", name)), "r") as f:
        return [line.strip().lower() for line in f if line.strip()]


def load_word_bank():
    return _read("word_bank")


def load_dictionary(word_bank):
    """Valid guesses: the bundled guess list plus every possible answer."""
    return sorted(set(_read("valid_guesses")) | set(word_bank))


_LENGTHS = {}


def load_length(letters, dictionary=None):
    """Every accepted word of this many letters: the usual guess list for 5 (`dictionary`, if given),
    else Media/other_lengths. A frozenset, read once."""
    if letters == 5:
        return frozenset(dictionary if dictionary is not None else load_dictionary(load_word_bank()))
    if not _LENGTHS:
        for word in _read("other_lengths"):
            _LENGTHS.setdefault(len(word), set()).add(word)
        for n in list(_LENGTHS):
            _LENGTHS[n] = frozenset(_LENGTHS[n])
    return _LENGTHS.get(letters, frozenset())
