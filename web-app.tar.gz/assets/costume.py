"""Tile costumes: a joke on one friend's account (Alex, Nov 2026).

For an account listed in COSTUMES, the board's green / yellow / gray tiles each wear an emoji in
the corner (the tile keeps its colour and letter, so the game reads exactly as usual), and Share
copies the emoji in place of the coloured squares. Nothing else changes: rules, stats, sync, what
friends and the owner page see.

On/off: add or remove (or comment out) the account's line in COSTUMES, then release as usual.
Accounts are listed by `tag()`, the first 16 hex characters of the SHA-256 of their sign-in id
(Supabase auth user id), so the public site never shows anyone's id. Signed out = no costume.
"""
import hashlib

# The emoji per tile colour. Each needs its picture as Media/costume_<codepoint>.png (Twemoji,
# Media/TWEMOJI_LICENSE) and listed in web/build_web.py MEDIA_FILES.
PEACHY = {"green": "\U0001F346", "yellow": "\U0001F351", "black": "\U0001F4A9"}  # 🍆 🍑 💩

COSTUMES = {
    "3b72659d0890c36f": PEACHY,  # the friend it was made for (prod)
    "d5445e285eb57cab": PEACHY,  # Alex's own prod account (he asked to wear it too)
    "026bb07462a6783c": PEACHY,  # the UAT owner account, for trying it out on UAT
}


def tag(user_id):
    return hashlib.sha256(str(user_id).encode("utf-8")).hexdigest()[:16]


def costume_for(user_id):
    """The emoji per colour for this sign-in id, or None (no costume, or signed out)."""
    if not user_id:
        return None
    return COSTUMES.get(tag(user_id))


def picture_name(emoji):
    """Media file of an emoji's picture: costume_1f346.png."""
    return "costume_%s.png" % "-".join("%x" % ord(ch) for ch in emoji if ord(ch) != 0xFE0F)
