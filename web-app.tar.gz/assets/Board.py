from collections import Counter

COLORS = {
    "green": '\x1b[6;30;42m',
    "yellow": '\x1b[6;30;43m',
    "gray": '\x1b[1;30;47m',   # not guessed yet
    "black": '\x1b[0;37;40m',  # not in the word
}
RESET = '\x1b[0m'

# A letter's color in the letter bank only ever gets "better" as more is learned.
PRIORITY = {"gray": 0, "black": 1, "yellow": 2, "green": 3}

KEYBOARD = "qwertyuiopasdfghjklzxcvbnm"


def colorize(letter, color):
    return COLORS[color] + letter + RESET


def score(guess, word):
    """Standard Wordle scoring, handling repeated letters correctly."""
    result = ["black"] * len(guess)
    unmatched = Counter()

    for i, (g, w) in enumerate(zip(guess, word)):
        if g == w:
            result[i] = "green"
        else:
            unmatched[w] += 1

    for i, g in enumerate(guess):
        if result[i] != "green" and unmatched[g] > 0:
            result[i] = "yellow"
            unmatched[g] -= 1

    return result


class Board:
    def __init__(self, word):
        self.word = word
        self.solved = False
        self.guesses = []
        self.letters_bank_to_print = {letter: "gray" for letter in KEYBOARD}

    def process_guess(self, guess):
        if self.solved:
            return self.solved

        entry = []
        for letter, color in zip(guess, score(guess, self.word)):
            entry.append([colorize(letter, color), letter, color])
            if PRIORITY[color] > PRIORITY[self.letters_bank_to_print[letter]]:
                self.letters_bank_to_print[letter] = color

        self.guesses.append(entry)
        self.solved = guess == self.word
        return self.solved

    def draw(self):
        for guess in self.guesses:
            print("".join(letter[0] for letter in guess))

        if self.guesses:
            print("")

        print("Letter Bank:")
        for letter, color in self.letters_bank_to_print.items():
            print(colorize(letter, color), end='  ')
            if letter == "p":
                print("\n\n  ", end='')
            elif letter == "l":
                print("\n\n    ", end='')

        print("\n")

    def rows(self):
        """Guesses so far as [[(letter, color), ...], ...], without terminal color codes."""
        return [[(letter, color) for _, letter, color in entry] for entry in self.guesses]

    def history(self):
        """Guesses so far as [(word, [color, ...]), ...], the form Solver.candidates takes."""
        return [("".join(letter for _, letter, _ in entry), [color for _, _, color in entry]) for entry in self.guesses]

    def get_remaining_letters(self):
        return {k for k, v in self.letters_bank_to_print.items() if v != "black"}

    def get_yellows(self):
        return {k for k, v in self.letters_bank_to_print.items() if v == "yellow"}

    def get_known_pattern(self):
        """Regex like "[^e]ai[a-z]e" describing what is known about each position."""
        result = []
        for position in range(len(self.word)):
            green = None
            not_here = set()
            for guess in self.guesses:
                _, letter, color = guess[position]
                if color == "green":
                    green = letter
                    break
                if color == "yellow":
                    not_here.add(letter)
            if green:
                result.append(green)
            elif not_here:
                result.append("[^%s]" % ''.join(sorted(not_here)))
            else:
                result.append("[a-z]")

        return "".join(result)
