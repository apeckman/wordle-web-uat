"""Browser entry point. pygbag needs a main.py with an async loop; build_web.py copies this in."""
import asyncio


def page_ms():
    """The page's clock (ms since it opened), for the launch breakdown in the server's log (gui.BOOT)."""
    try:
        import platform  # pygbag's bridge to the browser's JavaScript
        return float(platform.window.performance.now())
    except Exception:
        return None


MAIN_AT = page_ms()  # (pygbag has installed pygame and started this file)
import pygame  # noqa: E402,F401  (pygbag decides which packages to load from main.py's imports)
PYGAME_AT = page_ms()
import gui  # noqa: E402
GUI_AT = page_ms()

TITLE = "Wordle & Quordle"
UAT_TITLE = "Wordle UAT"  # the testing site (see gui.release_label); matches web/template.tmpl


def document():
    import platform  # pygbag's bridge to the browser's JavaScript
    return platform.window.document


def style_page():
    """Match the page to the game (no gray bars beside the canvas). Icons are in web/template.tmpl."""
    try:
        document().body.style.background = "#151924"
    except Exception:
        pass  # cosmetic only


def set_title():
    """The tab title, which iPhones also use as the home-screen name."""
    try:
        title = UAT_TITLE if gui.browser_release_label() else TITLE
        if document().title != title:
            document().title = title
    except Exception:
        pass


async def main():
    app = gui.App()
    gui.BOOT.update(main=MAIN_AT, pygame=PYGAME_AT, gui=GUI_AT, app=page_ms())
    style_page()
    frames = 0
    while app.safe_frame():  # (never app.frame(): an error escaping it would end this loop and freeze the page)
        app.clock.tick(gui.FPS)
        frames += 1
        if frames % 30 == 1:  # the browser's SDL layer renames the tab "pygame window" once it draws
            set_title()
        await asyncio.sleep(0)


asyncio.run(main())
