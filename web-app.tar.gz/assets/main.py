"""Browser entry point. pygbag needs a main.py with an async loop; build_web.py copies this in."""
import asyncio

import pygame  # noqa: F401  (pygbag decides which packages to load from main.py's imports)

import gui

TITLE = "Wordle & Quordle"
UAT_TITLE = "Wordle UAT"  # the testing site (see gui.release_label); matches web/template.tmpl


def document():
    import platform  # pygbag's bridge to the browser's JavaScript
    return platform.window.document


def style_page():
    """Match the page to the game (no gray bars beside the canvas). Icons are in web/template.tmpl."""
    try:
        document().body.style.background = "#151924"
    except Exception:
        pass  # cosmetic only


def set_title():
    """The tab title, which iPhones also use as the home-screen name."""
    try:
        title = UAT_TITLE if gui.browser_release_label() else TITLE
        if document().title != title:
            document().title = title
    except Exception:
        pass


async def main():
    app = gui.App()
    style_page()
    frames = 0
    while app.safe_frame():  # (never app.frame(): an error escaping it would end this loop and freeze the page)
        app.clock.tick(gui.FPS)
        frames += 1
        if frames % 30 == 1:  # the browser's SDL layer renames the tab "pygame window" once it draws
            set_title()
        await asyncio.sleep(0)


asyncio.run(main())
