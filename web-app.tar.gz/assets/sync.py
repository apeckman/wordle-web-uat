"""Optional sync through a server (Supabase): the same games and stats on all of a player's devices,
and the numbers behind the analytics in server/analytics.sql.

Nothing here ever waits on the network. The GUI calls `tick(now)` every frame; requests go out in
the background (a thread on a computer, the page's fetch() in a browser) and their answers are
applied on a later frame. Offline, finished games just wait ("sent" is only set once the server has
them) and the next try goes out later, backing off up to 10 minutes.

The server only knows a device by a random secret made here, and which devices belong together.
Devices are linked with a short code shown on one and typed into the other. There are no accounts,
names or emails. Setting the "sync" pref to False turns all of it off.

SERVERS holds two Supabase projects: "wordle" for real players (the website and the Mac app) and
"wordle-uat" for the UAT site and local test builds, so database changes can be tried on UAT before
prod. Blank a URL to turn sync off for that site. Each key is the project's publishable (public)
key: it's meant to be in the game, since the database only lets it call the wordle_* functions in
server/schema.sql. Never put a secret or service key here.
"""
import json
import threading
import time
import uuid

import history

SERVERS = {  # (URL, publishable key) per site group
    "prod": ("https://aaanufmvawaqxnumzaqr.supabase.co", "sb_publishable_DHPRn2ffsmC5YBUyc6Y6HQ_NJodvtVW"),
    "uat": ("https://rznfechkplcrpgvfixnq.supabase.co", "sb_publishable_2cAvWndZOU5nyaHaiSMqLA_VFHsYcXM"),
}
REALMS = {"prod": "prod", "desktop": "prod", "uat": "uat"}  # site -> server (the Mac app syncs with the website)
OLD_SERVER = SERVERS["prod"][0]  # where every device synced before UAT got its own project
# Bumped only when a server's games were wiped on purpose (server/reset_all_games.sql), so devices
# start fresh there: 2 = Nov 2026, when link codes gave way to accounts. Never a habit.
RESET = 2
# Bumped to have every device send all of its finished games again once (the server keeps one copy
# of each, so nothing doubles): Nov 2026, after some games were on devices but no longer on the
# server. 1 sent each device's own games; 2 sends the ones that came from other devices too (they
# belong to the same account, and their own device may be gone); 3 fills in each game's marks (how
# each guess was played), which the server only started keeping then. Unlike RESET, nothing is dropped.
RESEND = 3


def server_for(site):
    return SERVERS[REALMS.get(site, "uat")]

MAX_GAMES = 100      # per request (the server's limit)
MAX_PROGRESS = 30
EVERY_MS = 30 * 1000         # look for other devices' games this often (while online)
FIRST_MS = 2000              # after starting (let the game draw first)
RETRY_MS = 15 * 1000         # first retry after a failure, doubling...
MAX_RETRY_MS = 10 * 60 * 1000
TIMEOUT_S = 15
# Once a day each device downloads its whole list of games from the server and sends again any
# finished game it has that the server doesn't (see _start_check), so a game can't sit on one
# device unsaved for long, whatever the cause. A day keeps the downloads small (5 GB a month free).
CHECK_EVERY_S = 24 * 3600
UPLOAD_FIELDS = ("id", "mode", "daily", "answers", "guesses", "hints", "lists", "started", "won", "finished",
                 "played_on", "marks")
ERRORS = {  # (the account functions' errors, shown in the form they came from)
    "bad code": "That code didn't work or has expired. Tap Send a new code",
    "too many tries": "Too many wrong codes. Try again in a few minutes",
    "owner": "This is the game owner's account, so it can't be deleted",
}
DELETED_MESSAGE = ("This email's account was deleted, so it can't sign in again for now. To come back, talk to the "
                   "game's owner about reinstating it")
FRIEND_ERRORS = {
    "bad code": "That friend code didn't work. Check it with your friend",
    "too many tries": "Too many wrong codes. Try again in a few minutes",
    "no profile": "Choose a name first",
    "no account": "Friends works with an account. Sign in first",
    "bad name": "Use up to 16 letters, numbers or spaces",
    "too many friends": "That's the most friends allowed (50)",
}
FUNCTIONS = {             "profile": "wordle_profile", "friend_add": "wordle_friend_add", "friend_remove": "wordle_friend_remove",
             "friends": "wordle_friends"}
FRIEND_KINDS = ("profile", "friend_add", "friend_remove", "friends")
FUNCTIONS.update(attach="wordle_account_attach", detach="wordle_account_detach", account_delete="wordle_account_delete",
                 delete_request="wordle_account_delete_request")
ACCOUNT_KINDS = ("auth", "attach", "detach", "account_delete", "delete_request")
# Supabase Auth's error codes (and a few of its messages) in plain words.
AUTH_ERRORS = {
    "invalid_credentials": "Wrong email or password. Forgot it? Tap Forgot password? below",
    "invalid_grant": "Wrong email or password. Forgot it? Tap Forgot password? below",
    "user_already_exists": "There's already an account for this email. Sign in instead",
    "email_exists": "There's already an account for this email. Sign in instead",
    "weak_password": "Choose a longer password (at least 6 characters)",
    "over_email_send_rate_limit": "Too many emails just now. Wait a minute and try again",
    "over_request_rate_limit": "Too many tries just now. Wait a minute and try again",
    "otp_expired": "That code didn't work or has expired. Send a new one",
    "signup_disabled": "New accounts are switched off right now",
    "email_address_invalid": "Check the email address",
    "validation_failed": "Check the email address",
    "user_not_found": "There's no account for this email. Create one instead",
    "same_password": "That's already your password. Choose a different one",
}


def format_code(code):  # (friend codes)
    """ABCDEFGH -> ABCD-EFGH"""
    return code[:4] + "-" + code[4:] if len(code) == 8 else code


# ----- getting requests there ----------------------------------------------

class ThreadTransport:
    """urllib on a background thread (computers)."""

    def __init__(self):
        self.results = {}
        self.lock = threading.Lock()

    def start(self, url, headers, body, method="POST"):
        handle = uuid.uuid4().hex
        threading.Thread(target=self._run, args=(handle, url, headers, body, method), daemon=True).start()
        return handle

    def _run(self, handle, url, headers, body, method="POST"):
        import urllib.error
        import urllib.request
        try:
            data = None if method in ("GET", "HEAD") else body.encode()  # (no body on a GET)
            request = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(request, timeout=TIMEOUT_S, context=ssl_context()) as response:
                result = (response.status, response.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as error:
            result = (error.code, error.read().decode("utf-8", "replace"))
        except Exception:
            result = (0, "")  # no connection, timed out...
        with self.lock:
            self.results[handle] = result

    def result(self, handle):
        """None while it's on its way, then (HTTP status, body); status 0 if it never got there."""
        with self.lock:
            return self.results.pop(handle, None)


_ssl_context = None


def ssl_context():
    """HTTPS settings for urllib. python.org's Python on a Mac ships without root certificates
    (until its "Install Certificates" script is run), so use certifi's when it's installed."""
    global _ssl_context
    if _ssl_context is None:
        import ssl
        try:
            import certifi
            _ssl_context = ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            _ssl_context = ssl.create_default_context()
    return _ssl_context


class BrowserTransport:
    """The page's fetch() (web/template.tmpl wordleFetch), since the browser's Python has no threads
    or sockets. The page keeps each answer until it's taken."""

    def start(self, url, headers, body, method="POST"):
        import platform
        handle = uuid.uuid4().hex
        platform.window.wordleFetch(handle, url, json.dumps(headers), body, method)
        return handle

    def result(self, handle):
        import platform
        text = str(platform.window.wordleFetchTake(handle) or "")
        if not text:
            return None
        try:
            answer = json.loads(text)
            return int(answer.get("status", 0)), str(answer.get("text", ""))
        except (ValueError, AttributeError):
            return 0, ""


def default_transport(web):
    return BrowserTransport() if web else ThreadTransport()


# ----- syncing -----------------------------------------------------------------

class Sync:
    """Keeps a History in step with the server. State kept in history.sync: secret (this device),
    player (the server's id for the linked devices), cursor (how far this device has downloaded),
    last (when it last synced; just for show)."""

    def __init__(self, saved, transport, site, url=None, key=None):
        self.history = saved
        self.transport = transport
        self.site = site  # "prod", "uat" or "desktop" (kept apart on the server)
        self.url = server_for(site)[0] if url is None else url
        self.key = server_for(site)[1] if key is None else key
        self.busy = None        # {"kind", "handle", ...} for the request on its way
        self.next_at = None     # when to sync next (ms); None until the first tick
        self.started = False    # the first tick ran (_check_server)
        self.hold_until = 0     # after a failure, nothing goes out before this (ms)
        self.retry = RETRY_MS
        self.failed = False     # the last try didn't get through
        self.wanted = []        # link / code / forget requests waiting for the request on its way
        self.message = None     # (text, ok) for the sync screen: how linking went
        self.keep = None        # (mode, number) of the daily on screen (merge leaves its progress alone)
        self.friends_message = None  # (text, ok) for the Friends screen
        self.friends_at = None  # when friends' results were last asked for (ms)
        self.friends_fresh_at = None  # when the friend code last came back from the server (ms)
        # The sign-in form while it's open (both front ends draw it from this): mode is "signin",
        # "signup", "code" (ask for a code), "verify" (type the code) or "newpassword"; purpose says
        # what a code is for ("email" to sign in, "signup" to confirm a new account, "reset").
        self.auth_form = None
        self.clock = time.time  # wall clock, for token expiry
        self.format_when = None  # (iso time) -> "today at 3:42 PM", set by the GUI in a browser
        self.applied = 0        # changes taken in from the server (for tests and the GUI)
        self.check = None       # the daily check in progress: {"seen": game ids, "dailies": (mode, number)}

    @property
    def configured(self):
        return bool(self.url and self.key)

    @property
    def enabled(self):
        return self.configured

    def state(self):
        return self.history.sync

    def secret(self):
        state = self.state()
        if not state.get("secret"):
            state["secret"] = uuid.uuid4().hex
            state["server"] = self.server_key()
            state["resent"] = RESEND  # (a new device: everything it has goes up anyway)
            self.history.save()
        return state["secret"]

    def server_key(self):
        return "%s#%d" % (self.url, RESET)

    def _check_server(self):
        """If this device last synced with a different server (UAT moved to its own project) or before
        a deliberate wipe (RESET), start fresh there: forget the old player and cursor, drop games that
        came from other devices, send this device's own games again, and rejoin the account if signed in.
        And once per RESEND, send every finished game here again without dropping anything."""
        state = self.state()
        if not self.configured or not (state.get("secret") or state.get("player")):
            return
        if state.get("server", OLD_SERVER) != self.server_key():
            for name in ("player", "cursor", "last", "devices", "friends"):
                state.pop(name, None)
            state["server"] = self.server_key()
            self.history.drop_from_sync()
            for game in self.history.games:
                game.pop("sent", None)
            if self.signed_in:
                self.wanted.append({"kind": "attach", "params": {}, "bearer": True})
            self.history.save()
        if state.get("resent") != RESEND:
            # Send every finished game here again (see RESEND).
            state["resent"] = RESEND
            for game in self.history.games:
                game.pop("sent", None)
            self.history.save()

    def soon(self, now, delay=1000):
        """Sync shortly (a guess, or a game just ended)."""
        if self.next_at is None or now + delay < self.next_at:
            self.next_at = now + delay

    def woke(self, now):
        """The game was opened again, came back to the front, or got back online: sync now (even if
        an earlier failure said to wait), so games from other devices show up straight away."""
        self.hold_until = 0
        self.next_at = now

    # Accounts (optional): sign in with email + password, or a 6-digit emailed code.

    def auth(self):
        auth = self.state().get("auth")
        return auth if isinstance(auth, dict) else {}

    @property
    def signed_in(self):
        """The account's email when signed in, else None."""
        return self.auth().get("email") if self.auth().get("refresh") else None

    def _token_stale(self):
        return float(self.auth().get("expires", 0)) - self.clock() < 60

    def _auth_job(self, step, body, path=None, method="POST", bearer=False):
        paths = {"password": "/auth/v1/token?grant_type=password", "refresh": "/auth/v1/token?grant_type=refresh_token",
                 "signup": "/auth/v1/signup", "otp": "/auth/v1/otp", "verify": "/auth/v1/verify",
                 "resend": "/auth/v1/resend", "set_password": "/auth/v1/user",
                 "reauthenticate": "/auth/v1/reauthenticate"}
        return {"kind": "auth", "step": step, "body": body, "path": path or paths[step], "method": method,
                "bearer": bearer}

    def open_account_form(self, mode="signin"):
        self.forms_opened = getattr(self, "forms_opened", 0) + 1
        self.auth_form = {"mode": mode, "email": self.auth_form["email"] if self.auth_form else "",
                          "purpose": "email", "error": None, "note": None, "busy": False,
                          "opened": self.forms_opened}  # (tells the drawn form it's a fresh one)

    def close_account_form(self):
        self.auth_form = None

    def account_action(self, action, email="", password="", code="", now=0):
        """What the sign-in form asks for: "signin", "signup", "send_code", "verify", "resend",
        "set_password", "cancel", or "mode:<mode>" to switch screens (e.g. "mode:code")."""
        form = self.auth_form
        if form is None or not self.enabled:
            return
        email = (email or form.get("email") or "").strip()
        form.update(email=email, error=None, note=None)
        if action == "cancel":
            self.auth_form = None
            return
        if action == "mode:code" and form.get("mode") == "verify" and form.get("purpose") == "reset":
            action = "mode:reset"  # ("Use a different email" while resetting a password)
        if action.startswith("mode:"):
            form.update(mode=action[5:], purpose="reset" if action == "mode:reset" else "email")
            if action == "mode:reset":
                form["mode"] = "code"
            return
        if action in ("confirm_delete", "resend_delete"):
            if action == "resend_delete":
                form.update(busy=True)
                self.wanted.append(self._auth_job("reauthenticate", {}, method="GET", bearer=True))
            elif not (code.strip().isdigit() and 6 <= len(code.strip()) <= 10):
                form["error"] = "Type the code from the email (6 digits)"
            else:
                form.update(busy=True)
                self.wanted.append({"kind": "account_delete", "params": {"p_code": code.strip()}, "bearer": True})
            return
        problem = None
        if action in ("signin", "signup", "send_code", "resend") and ("@" not in email or "." not in email.split("@")[-1]):
            problem = "Check the email address"
        elif action == "signin" and not password:
            problem = "Type your password, or tap Email me a code"
        elif action in ("signup", "set_password") and len(password) < 6:
            problem = "Choose a password of at least 6 characters"
        elif action == "verify" and not (code.strip().isdigit() and 6 <= len(code.strip()) <= 8):
            problem = "Type the code from the email (6 digits)"
        if problem:
            form["error"] = problem
            return
        form["busy"] = True
        if action == "signin":
            job = self._auth_job("password", {"email": email, "password": password})
        elif action == "signup":
            job = self._auth_job("signup", {"email": email, "password": password})
        elif action == "send_code":
            job = self._auth_job("otp", {"email": email, "create_user": form.get("purpose") != "reset"})
        elif action == "resend":
            if form.get("purpose") == "signup":
                job = self._auth_job("resend", {"type": "signup", "email": email})
            else:
                job = self._auth_job("otp", {"email": email, "create_user": form.get("purpose") != "reset"})
        elif action == "verify":
            job = self._auth_job("verify", {"type": "signup" if form.get("purpose") == "signup" else "email",
                                            "email": email, "token": code.strip()})
        elif action == "set_password":
            job = self._auth_job("set_password", {"password": password}, method="PUT", bearer=True)
        else:
            form["busy"] = False
            return
        self.wanted.append(job)

    def sign_out(self, now=0):
        """Leave the account on this device (the account keeps every game)."""
        self.message = None
        self._want("detach", now)

    def delete_account(self, now=0):
        """Start deleting the account: Supabase emails a code (its "Reauthentication" email, which says
        what deleting means) and the form asks for it; account_action("confirm_delete") then deletes."""
        self.message = None
        self.auth_form = {"mode": "delete", "email": self.signed_in or "", "purpose": "delete", "error": None,
                          "note": None, "busy": True, "opened": getattr(self, "forms_opened", 0) + 1}
        self.forms_opened = self.auth_form["opened"]
        self.wanted.append({"kind": "delete_request", "params": {}, "bearer": True})  # (logged; then the code)

    def _store_session(self, answer):
        user = answer.get("user") if isinstance(answer.get("user"), dict) else {}
        old = self.auth()
        if not old.get("refresh"):
            self.state()["attach_pending"] = True  # (cleared once the server ties this device to the account)
        self.state()["auth"] = {
            "email": user.get("email") or old.get("email") or (self.auth_form or {}).get("email", ""),
            "user": user.get("id") or old.get("user"),
            "access": answer.get("access_token", ""), "refresh": answer.get("refresh_token", old.get("refresh", "")),
            "expires": self.clock() + float(answer.get("expires_in", 3600) or 3600)}
        self.history.save()

    def _finish_auth(self, job, status, text, now):
        try:
            answer = json.loads(text) if text else {}
        except ValueError:
            answer = {}
        if not isinstance(answer, dict):
            answer = {}
        step = job["step"]
        form = self.auth_form
        if status == 0:
            self._failed(now, job)
            if form:
                form.update(busy=False, error="Can't reach the server. Check the connection and try again")
            return
        self.failed = False
        if status >= 400:
            code = str(answer.get("error_code") or answer.get("error") or "")
            words = str(answer.get("msg") or answer.get("error_description") or answer.get("message") or "")
            if step == "refresh":
                self.state().pop("auth", None)  # (signed out elsewhere, or the account is gone)
                self.history.save()
                self.wanted = [w for w in self.wanted if not w.get("bearer")]
                self.message = ("You were signed out. Sign in again to keep saving to your account", False)
                if self.auth_form and self.auth_form.get("purpose") == "delete":
                    self.auth_form = None  # (deleting needs a sign-in)
                return
            if code == "email_not_confirmed" or "not confirmed" in words.lower():
                # An account that never typed its code: send a fresh one and ask for it.
                self.wanted.append(self._auth_job("resend", {"type": "signup", "email": form["email"]}))
                form.update(mode="verify", purpose="signup", busy=True, error=None,
                            note="Confirm your email first: we sent a new code to %s" % form["email"])
                return
            if step == "reauthenticate" and form and (status == 429 or "rate_limit" in code):
                form.update(busy=False, error=None,
                            note="We emailed you a code a moment ago: check your email (and spam)")
                return
            if step in ("otp", "resend", "signup") and (status == 429 or "rate_limit" in code):
                # A code went out moments ago: use that one rather than show an error.
                import re
                wait = re.search(r"(\d+) seconds", words)
                form.update(mode="verify", busy=False, error=None,
                            purpose="signup" if step == "signup" else form.get("purpose", "email"),
                            note="We sent you a code a moment ago: check your email (and spam)%s" % (
                                ". You can get a new one in %s seconds" % wait.group(1) if wait else ""))
                return
            if step == "otp" and form and form.get("purpose") == "reset" and (
                    code == "otp_disabled" or "signups not allowed" in words.lower()):
                message = AUTH_ERRORS["user_not_found"]  # (a reset code never makes an account)
            elif "signups not allowed" in words.lower() or "signup" in code and "disabled" in code:
                message = AUTH_ERRORS["signup_disabled"]
            elif code in AUTH_ERRORS:
                message = AUTH_ERRORS[code]
            elif step == "verify":
                message = AUTH_ERRORS["otp_expired"]
            elif status == 429:
                message = AUTH_ERRORS["over_request_rate_limit"]
            else:
                message = words[:120] if words else "That didn't work. Try again"
            if form:
                form.update(busy=False, error=message)
            return
        if step in ("password", "verify", "refresh") and answer.get("access_token"):
            self._store_session(answer)
            if step != "refresh":
                self.wanted.append({"kind": "attach", "params": {}, "bearer": True})
            return
        if step == "signup":
            if answer.get("access_token"):  # (email confirmation is off)
                self._store_session(answer)
                self.wanted.append({"kind": "attach", "params": {}, "bearer": True})
                return
            if answer.get("identities") == []:
                # Supabase's answer for an email that already has an account (it sends no code).
                form.update(busy=False, error=AUTH_ERRORS["email_exists"])
                return
            form.update(mode="verify", purpose="signup", busy=False,
                        note="We emailed a 6-digit code to %s. Type it here. (Already have an account? Go back "
                             "and sign in.)" % form["email"])
            return
        if step == "reauthenticate":
            if form:
                form.update(busy=False, note="We emailed a 6-digit code to %s. Typing it here deletes your account "
                                             "for good" % form.get("email", "you"))
            return
        if step in ("otp", "resend"):
            if form:
                form.update(mode="verify", busy=False,
                            note="We emailed a 6-digit code to %s. It works for an hour" % form["email"])
            return
        if step == "set_password":
            self.auth_form = None
            self.message = ("Password saved. Signed in as %s" % self.auth().get("email", ""), True)
            return
        if form:
            form.update(busy=False)

    # Friends (the Friends screen).

    def friends_data(self):
        """{"profile": {"name", "code", "id"} or None, "list": [{"id", "name", "games"}]}, as last fetched."""
        data = self.state().get("friends")
        return data if isinstance(data, dict) else {"profile": None, "list": []}

    def refresh_friends(self, now, max_age=60 * 1000):
        """Fetch friends' results if the last fetch is older than max_age (the screen calls this)."""
        if not self.enabled or any(w["kind"] == "friends" for w in self.wanted):
            return
        if self.busy and self.busy["kind"] == "friends":
            return
        if self.friends_at is None or now - self.friends_at > max_age:
            self.friends_at = now
            self._want("friends", now)

    def invite_ready(self, now):
        """True when the friend code is fresh enough to share (codes last 10 minutes; the server swaps
        them with under 5 left, and the Friends screen re-fetches every minute)."""
        return self.friends_fresh_at is not None and now - self.friends_fresh_at < 60 * 1000

    def set_name(self, name, now):
        self.friends_message = None
        self._want("profile", now, p_name=name)

    def new_friend_code(self, now):
        self._want("profile", now, p_new_code=True)

    def stop_sharing(self, now):
        self._want("profile", now, p_stop=True)

    def add_friend(self, code, now):
        self.friends_message = None
        self._want("friend_add", now, p_code=code)

    def remove_friend(self, friend_id, now):
        self._want("friend_remove", now, p_friend=friend_id)

    def _want(self, kind, now, **params):
        if not self.enabled:
            return
        if kind in ("friend_add", "friend_remove", "profile"):
            self.wanted.append({"kind": kind, "params": params})
        else:
            self.wanted = [w for w in self.wanted if w["kind"] != kind] + [{"kind": kind, "params": params}]

    def waiting(self, *kinds):
        """True while a request of one of these kinds is queued or on its way."""
        return any(w["kind"] in kinds for w in self.wanted) or bool(self.busy and self.busy["kind"] in kinds)

    def last_saved(self, now=None):
        """When the server last took this device's games, like "today at 3:42 PM" (None if never)."""
        if self.state().get("last") and self.format_when:
            return self.format_when(self.state()["last"])  # (a browser: the page knows the phone's time zone)
        moment = history.parse_time(self.state().get("last"))
        if moment is None:
            return None
        import datetime
        moment = moment.astimezone()
        now = (now or datetime.datetime.now()).astimezone()
        hour = moment.strftime("%I:%M:%S %p").lstrip("0")
        if moment.date() == now.date():
            day = "today"
        elif moment.date() == now.date() - datetime.timedelta(days=1):
            day = "yesterday"
        else:
            day = "%s %d" % ("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()[moment.month - 1], moment.day)
        return "%s at %s" % (day, hour)

    def status(self, now_ms, now=None):
        """One line for the Account screen: when games were last saved to the server."""
        if not self.configured:
            return "Saving to the server isn't set up in this version"
        when = self.last_saved(now)
        unsent = len(self.history.unsent())
        waiting = "%d game%s waiting to be saved. " % (unsent, "" if unsent == 1 else "s") if unsent else ""
        if self.failed:
            return "Can't reach the server right now. %s%s" % (
                waiting, "Last saved %s" % when if when else "Your games are kept here until it's back")
        if not when:
            return "Saving to the server..."
        return "%sLast saved to the server %s" % (waiting, when)

    # Every frame.

    def tick(self, now):
        """Start a request when one is due and take in any answer. Returns True if games changed."""
        if not self.started:
            # Once per launch, whatever already asked for a sync (in a browser the page's "woke" signal
            # fires on load and sets next_at before the first tick, which used to skip this).
            self.started = True
            if self.next_at is None:
                self.next_at = now + FIRST_MS
            self._check_server()
        before = self.applied
        if self.busy:
            result = self.transport.result(self.busy["handle"])
            if result is not None:
                job, self.busy = self.busy, None
                self._finish(job, result, now)
        # Button requests (codes, friends...) go out at once; the regular sync when it's due.
        if not self.busy and now >= self.hold_until and (self.wanted or (self.enabled and now >= self.next_at)):
            self._send(now)
        return self.applied != before

    def _call(self, function, params, bearer=False, path=None, method="POST"):
        headers = {"Content-Type": "application/json", "apikey": self.key}
        if bearer and self.auth().get("access"):
            headers["Authorization"] = "Bearer " + self.auth()["access"]
        elif not self.key.startswith("sb_"):  # an old-style anon key (a JWT) also goes in Authorization
            headers["Authorization"] = "Bearer " + self.key
        url = self.url.rstrip("/") + (path or "/rest/v1/rpc/" + function)
        body = json.dumps(params, separators=(",", ":"))
        if method == "POST":
            return self.transport.start(url, headers, body)
        return self.transport.start(url, headers, body, method)

    def _send(self, now):
        try:
            job = self.wanted.pop(0) if self.wanted else None
            if job and job.get("bearer") and job.get("step") != "refresh" and self._token_stale():
                self.wanted.insert(0, job)  # fresh token first
                job = self._auth_job("refresh", {"refresh_token": self.auth().get("refresh", "")})
            if (job is None and self.signed_in and self.state().get("attach_pending")
                    and now >= self.next_at):
                job = {"kind": "attach", "params": {}, "bearer": True}  # (an earlier try didn't get through)
                if self._token_stale():
                    self.wanted.insert(0, job)
                    job = self._auth_job("refresh", {"refresh_token": self.auth().get("refresh", "")})
            if job and job["kind"] in ("detach", "attach") and self.history.unsent():
                # Upload this device's games first: before signing out, or before joining an account
                # (so the server sees them when it decides which of two results for a daily to keep).
                self.wanted.insert(0, job)
                job = None
            if job is None:
                checking = self._start_check()
                games = self.history.unsent()[:MAX_GAMES]
                progress = [g for g in self.history.current.values() if g.get("guesses")][:MAX_PROGRESS]
                job = {"kind": "sync", "sent": [g["id"] for g in games], "checking": checking}
                params = {
                    "p_secret": self.secret(), "p_site": self.site, "p_since": int(self.state().get("cursor", 0)),
                    "p_games": [upload(g) for g in games], "p_progress": [upload(g) for g in progress],
                    "p_practice": [upload(g) for g in self.history.practice.values() if g.get("guesses")][:2]}
                settings = self.history.settings()
                if settings and settings["at"] != self.state().get("settings_sent"):
                    params["p_settings"] = settings  # (changed here since the server last had them)
                    job["settings_at"] = settings["at"]
                job["handle"] = self._call("wordle_sync", params)
            elif job["kind"] == "auth":
                job["handle"] = self._call(None, job["body"], bearer=job.get("bearer"), path=job["path"],
                                           method=job.get("method", "POST"))
            else:
                params = ({} if job["kind"] in ("account_delete", "delete_request")
                          else {"p_secret": self.secret(), "p_site": self.site})
                params.update(job["params"])
                job["handle"] = self._call(FUNCTIONS[job["kind"]], params, bearer=job.get("bearer"))
            self.busy = job
        except Exception:
            self._failed(now)

    def _say(self, job, text, ok):
        """Show how a button's request went, on the screen it came from."""
        if job["kind"] == "attach" and not ok and self.signed_in:
            # Signed in, but the server hasn't joined this device to the account yet: the sign-in is
            # done (the emailed code can't be used twice), and the join is retried by itself.
            if self.auth_form and self.auth_form.get("purpose") == "reset":
                self.auth_form = dict(self.auth_form, mode="newpassword", busy=False, error=None, note=None)
            else:
                self.auth_form = None
            self.message = ("Signed in as %s. Your games will join your account as soon as the server answers"
                            % self.signed_in, True)
        elif job["kind"] in ("auth", "attach", "account_delete", "delete_request") and self.auth_form:
            self.auth_form.update(busy=False, error=None if ok else text, note=text if ok else None)
        elif job["kind"] in FRIEND_KINDS:
            if job["kind"] != "friends":  # (background refreshes stay quiet)
                self.friends_message = (text, ok)
        elif job["kind"] != "sync":
            self.message = (text, ok)

    def _failed(self, now, job=None):
        self.failed = True
        self.hold_until = now + self.retry
        self.next_at = max(self.next_at or 0, self.hold_until)
        self.retry = min(self.retry * 2, MAX_RETRY_MS)
        if job:
            self._say(job, "Can't reach the server. Check the connection and try again", False)

    def _finish(self, job, result, now):
        status, text = result
        if job["kind"] == "auth":
            self._finish_auth(job, status, text, now)
            return
        try:
            answer = json.loads(text) if status == 200 else None
        except ValueError:
            answer = None
        if not isinstance(answer, dict):
            self._failed(now, job)
            return
        kind = job["kind"]
        if not answer.get("ok"):
            error = answer.get("error", "")
            if kind == "attach" and error == "deleted":
                # A deleted account's email: blocked until the owner reinstates it. Sign out here.
                for name in ("auth", "attach_pending"):
                    self.state().pop(name, None)
                self.wanted = [w for w in self.wanted if not w.get("bearer")]
                self.history.save()
                if self.auth_form:
                    self.auth_form.update(mode="signin", purpose="email", busy=False, note=None, error=DELETED_MESSAGE)
                else:
                    self.message = (DELETED_MESSAGE, False)
                return
            if kind in ACCOUNT_KINDS and error == "signed out":
                self.state().pop("auth", None)
                self._say(job, "Please sign in again", False)
                self.history.save()
                return
            messages = FRIEND_ERRORS if kind in FRIEND_KINDS else ERRORS
            if error in messages and kind != "sync":
                self._say(job, messages[error], False)
                return
            self._failed(now, job)
            return
        self.failed = False
        self.retry = RETRY_MS
        self.hold_until = 0
        state = self.state()
        if kind == "attach":
            state.pop("attach_pending", None)
            switched = self._new_player(answer.get("player"))
            if not switched:
                state["cursor"] = 0  # (first contact) get the account's games
            if answer.get("joined"):
                state["account_wins"] = True  # (until it's all downloaded: see _apply)
            self.friends_at = None
            self.history.save()
            self.next_at = now
            email = self.auth().get("email", "")
            if self.auth_form and self.auth_form.get("purpose") == "reset":
                self.auth_form = dict(self.auth_form, mode="newpassword", busy=False, error=None, note=None)
            else:
                self.auth_form = None
            self.message = ("Signed in as %s. Your games are saved to your account" % email, True)
        elif kind == "detach":
            # The account has every game; this device starts over as a new, signed-out one.
            self.applied += self.history.clear_games()
            state.update(player=answer.get("player"), cursor=0, devices=1)
            for name in ("auth", "friends", "last", "attach_pending", "account_wins"):
                state.pop(name, None)
            self.friends_at = None
            self.history.save()
            self.next_at = now
            self.message = ("Signed out. Your games are safe in your account: sign in to get them back", True)
        elif kind == "delete_request":
            self.wanted.append(self._auth_job("reauthenticate", {}, method="GET", bearer=True))
        elif kind == "account_delete":
            self.applied += self.history.clear_games()
            self.history.sync = {"secret": state.get("secret"), "server": self.server_key()}
            self.friends_at = None
            self.history.save()
            self.next_at = now
            self.auth_form = None
            self.message = ("Account deleted, with all its games. This device starts fresh", True)
        elif kind == "profile":
            self.friends_fresh_at = now
            data = self.friends_data()
            profile = answer.get("profile") if isinstance(answer.get("profile"), dict) else None
            state["friends"] = {"profile": profile, "list": data["list"] if profile else []}
            if job["params"].get("p_stop"):
                self.friends_message = ("You've stopped sharing. Your name and friends are deleted", True)
            elif job["params"].get("p_new_code"):
                self.friends_message = ("New friend code. The old one no longer works", True)
            self.history.save()
            if profile:
                self._want("friends", now)
        elif kind == "friend_add":
            self.friends_message = ("Added %s" % answer.get("name", "your friend"), True)
            self._want("friends", now)
        elif kind == "friend_remove":
            data = self.friends_data()
            gone = job["params"].get("p_friend")
            state["friends"] = dict(data, list=[f for f in data["list"] if f.get("id") != gone])
            self.history.save()
        elif kind == "friends":
            self.friends_fresh_at = now
            profile = answer.get("profile") if isinstance(answer.get("profile"), dict) else None
            friends = [f for f in answer.get("friends") or [] if isinstance(f, dict) and f.get("id")]
            state["friends"] = {"profile": profile, "list": friends}
            self.history.save()
        else:
            self.next_at = now + EVERY_MS
            self._apply(job, answer, now)

    def _start_check(self):
        """Begin the daily check if it's due: download everything from the start (cursor 0) and note
        what the server has. Returns True while a check is under way."""
        state = self.state()
        if self.check is None:
            try:
                last = float(state.get("checked_at") or 0)
            except (TypeError, ValueError):
                last = 0
            if self.clock() - last < CHECK_EVERY_S:
                return False
            self.check = {"seen": set(), "dailies": set()}
            state["cursor"] = 0
        return True

    def _end_check(self):
        """The whole list is in: send again every finished game here the server didn't list. Not one
        whose daily the server has another game for (that one won), nor one the server turned down or
        that was already sent again once and is still missing (the server log says why)."""
        state = self.state()
        check, self.check = self.check, None
        skip = set(state.get("rejected") or []) | set(state.get("healed") or [])
        missing = [g for g in self.history.games
                   if g.get("sent") and g["id"] not in check["seen"] and g["id"] not in skip
                   and not (g.get("daily") is not None and (g.get("mode"), g.get("daily")) in check["dailies"])]
        for game in missing:
            game.pop("sent", None)
        if missing:
            state["healed"] = (list(state.get("healed") or []) + [g["id"] for g in missing])[-200:]
        state["checked_at"] = self.clock()

    def _new_player(self, player):
        """Note the server's player id. If it changed (this device was linked to another one's games),
        start downloading from the beginning again; returns True then."""
        state = self.state()
        if not player or player == state.get("player"):
            return False
        switched = bool(state.get("player"))
        state["player"] = player
        if switched:
            state["cursor"] = 0
        return switched

    def _apply(self, job, answer, now):
        state = self.state()
        sent = set(job["sent"])
        for game in self.history.games:
            if game["id"] in sent:
                game["sent"] = True  # (rejected ones too: sending them again wouldn't help)
        rejected = [r for r in (answer.get("rejected") or []) if isinstance(r, str)]
        if rejected:  # (kept for looking into later: which games the server turned down)
            state["rejected"] = (list(state.get("rejected") or []) + rejected)[-50:]
        games = answer.get("games") if isinstance(answer.get("games"), list) else []
        progress = answer.get("progress") if isinstance(answer.get("progress"), list) else []
        removed = answer.get("removed") if isinstance(answer.get("removed"), list) else []
        practice = answer.get("practice") if isinstance(answer.get("practice"), list) else []
        # Just joined an account: its dailies replace ones this device finished signed out.
        self.applied += self.history.merge(games, progress, keep=self.keep, removed=removed, practice=practice,
                                           account_wins=bool(state.get("account_wins")))
        if not answer.get("more"):
            state.pop("account_wins", None)
        if job.get("checking") and self.check is not None:
            for game in games:
                if isinstance(game, dict):
                    self.check["seen"].add(game.get("id"))
                    if game.get("daily") is not None:
                        self.check["dailies"].add((game.get("mode"), game.get("daily")))
            if not answer.get("more"):
                self._end_check()
        if isinstance(answer.get("devices"), int):
            state["devices"] = answer["devices"]
        if job.get("settings_at"):
            state["settings_sent"] = job["settings_at"]
        if self.history.apply_settings(answer.get("settings")):  # (changed on another device)
            state["settings_sent"] = self.history.prefs["settings_at"]
            self.applied += 1
        switched = self._new_player(answer.get("player"))
        if not switched:
            try:
                state["cursor"] = max(int(state.get("cursor", 0)), int(answer.get("cursor", 0)))
            except (TypeError, ValueError):
                pass
        state["last"] = history.now_iso()
        self.history.save()
        if switched or answer.get("more") or self.history.unsent():
            self.next_at = now  # more to send or fetch


def friend_games(rows, mode):
    """A friend's daily results from the server ([mode, number, won, guesses, hints, played_on]) as
    game records history.Stats understands."""
    games = []
    for row in rows:
        try:
            m, number, won, used, hints, played_on = row
            if m == mode:
                games.append({"mode": m, "daily": int(number), "won": bool(won), "guesses": [""] * int(used),
                              "hints": int(hints or 0), "played_on": str(played_on)})
        except (TypeError, ValueError):
            continue
    return games


def friend_summary(games, mode, today):
    """(today's result like "3/6", "X/6" or "-", history.Stats) for one player's daily games."""
    number = daily_number(today)
    limit = 6 if mode == "w" else 9
    result = "-"
    for game in games:
        if game.get("mode") == mode and game.get("daily") == number:
            result = "%d/%d" % (len(game["guesses"]), limit) if game.get("won") else "X/%d" % limit
    return result, history.Stats([g for g in games if g.get("mode") == mode and g.get("daily") is not None],
                                 today, True)


def daily_number(today):
    import daily
    return daily.puzzle_number(today)


def upload(game):
    return {k: game.get(k) for k in UPLOAD_FIELDS if k in game}
