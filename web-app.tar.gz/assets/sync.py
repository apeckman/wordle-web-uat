"""Optional sync through a server (Supabase): the same games and stats on all of a player's devices,
and the numbers behind the analytics in server/analytics.sql.

Nothing here ever waits on the network. The GUI calls `tick(now)` every frame; requests go out in
the background (a thread on a computer, the page's fetch() in a browser) and their answers are
applied on a later frame. Offline, finished games just wait ("sent" is only set once the server has
them) and the next try goes out later, backing off up to 10 minutes.

The server only knows a device by a random secret made here, and which devices belong together.
Devices are linked with a short code shown on one and typed into the other. There are no accounts,
names or emails. Setting the "sync" pref to False turns all of it off.

SERVER_URL and SERVER_KEY point at the "wordle" Supabase project (blank them to turn sync off
everywhere). The key is the project's publishable (public) key: it's meant to be in the game, since
the database only lets it call the wordle_* functions in server/schema.sql. Never put a secret or
service key here.
"""
import json
import threading
import uuid

import history

SERVER_URL = "https://aaanufmvawaqxnumzaqr.supabase.co"  # the "wordle" Supabase project
SERVER_KEY = "sb_publishable_DHPRn2ffsmC5YBUyc6Y6HQ_NJodvtVW"  # its publishable key (public by design)

MAX_GAMES = 100      # per request (the server's limit)
MAX_PROGRESS = 30
EVERY_MS = 5 * 60 * 1000     # look for other devices' games this often
FIRST_MS = 2000              # after starting (let the game draw first)
RETRY_MS = 15 * 1000         # first retry after a failure, doubling...
MAX_RETRY_MS = 10 * 60 * 1000
TIMEOUT_S = 15
CODE_MS = 10 * 60 * 1000     # how long a link code works
UPLOAD_FIELDS = ("id", "mode", "daily", "answers", "guesses", "hints", "lists", "started", "won", "finished",
                 "played_on")
ERRORS = {
    "bad code": "That code didn't work. Check it, or get a new one",
    "too many tries": "Too many wrong codes. Try again in a few minutes",
}
FRIEND_ERRORS = {
    "bad code": "That friend code didn't work. Check it with your friend",
    "too many tries": "Too many wrong codes. Try again in a few minutes",
    "no profile": "Choose a name first",
    "bad name": "Use up to 16 letters, numbers or spaces",
    "too many friends": "That's the most friends allowed (50)",
}
FUNCTIONS = {"code": "wordle_link_code", "link": "wordle_link", "unlink": "wordle_unlink", "forget": "wordle_forget",
             "profile": "wordle_profile", "friend_add": "wordle_friend_add", "friend_remove": "wordle_friend_remove",
             "friends": "wordle_friends"}
FRIEND_KINDS = ("profile", "friend_add", "friend_remove", "friends")


def format_code(code):
    """ABCDEFGH -> ABCD-EFGH"""
    return code[:4] + "-" + code[4:] if len(code) == 8 else code


# ----- getting requests there ----------------------------------------------

class ThreadTransport:
    """urllib on a background thread (computers)."""

    def __init__(self):
        self.results = {}
        self.lock = threading.Lock()

    def start(self, url, headers, body):
        handle = uuid.uuid4().hex
        threading.Thread(target=self._run, args=(handle, url, headers, body), daemon=True).start()
        return handle

    def _run(self, handle, url, headers, body):
        import urllib.error
        import urllib.request
        try:
            request = urllib.request.Request(url, data=body.encode(), headers=headers, method="POST")
            with urllib.request.urlopen(request, timeout=TIMEOUT_S, context=ssl_context()) as response:
                result = (response.status, response.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as error:
            result = (error.code, error.read().decode("utf-8", "replace"))
        except Exception:
            result = (0, "")  # no connection, timed out...
        with self.lock:
            self.results[handle] = result

    def result(self, handle):
        """None while it's on its way, then (HTTP status, body); status 0 if it never got there."""
        with self.lock:
            return self.results.pop(handle, None)


_ssl_context = None


def ssl_context():
    """HTTPS settings for urllib. python.org's Python on a Mac ships without root certificates
    (until its "Install Certificates" script is run), so use certifi's when it's installed."""
    global _ssl_context
    if _ssl_context is None:
        import ssl
        try:
            import certifi
            _ssl_context = ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            _ssl_context = ssl.create_default_context()
    return _ssl_context


class BrowserTransport:
    """The page's fetch() (web/template.tmpl wordleFetch), since the browser's Python has no threads
    or sockets. The page keeps each answer until it's taken."""

    def start(self, url, headers, body):
        import platform
        handle = uuid.uuid4().hex
        platform.window.wordleFetch(handle, url, json.dumps(headers), body)
        return handle

    def result(self, handle):
        import platform
        text = str(platform.window.wordleFetchTake(handle) or "")
        if not text:
            return None
        try:
            answer = json.loads(text)
            return int(answer.get("status", 0)), str(answer.get("text", ""))
        except (ValueError, AttributeError):
            return 0, ""


def default_transport(web):
    return BrowserTransport() if web else ThreadTransport()


# ----- syncing -----------------------------------------------------------------

class Sync:
    """Keeps a History in step with the server. State kept in history.sync: secret (this device),
    player (the server's id for the linked devices), cursor (how far this device has downloaded),
    last (when it last synced; just for show)."""

    def __init__(self, saved, transport, site, url=None, key=None):
        self.history = saved
        self.transport = transport
        self.site = site  # "prod", "uat" or "desktop" (kept apart on the server)
        self.url = SERVER_URL if url is None else url
        self.key = SERVER_KEY if key is None else key
        self.busy = None        # {"kind", "handle", ...} for the request on its way
        self.next_at = None     # when to sync next (ms); None until the first tick
        self.hold_until = 0     # after a failure, nothing goes out before this (ms)
        self.retry = RETRY_MS
        self.failed = False     # the last try didn't get through
        self.wanted = []        # link / code / forget requests waiting for the request on its way
        self.code = None        # {"code", "until"} once a link code has come back
        self.message = None     # (text, ok) for the sync screen: how linking went
        self.keep = None        # (mode, number) of the daily on screen (merge leaves its progress alone)
        self.friends_message = None  # (text, ok) for the Friends screen
        self.friends_at = None  # when friends' results were last asked for (ms)
        self.applied = 0        # changes taken in from the server (for tests and the GUI)

    @property
    def configured(self):
        return bool(self.url and self.key)

    @property
    def enabled(self):
        return self.configured and self.history.prefs.get("sync", True) is not False

    def set_enabled(self, on):
        self.history.set_pref("sync", bool(on))
        self.message = None
        self.code = None
        if on:
            self.next_at = 0

    def state(self):
        return self.history.sync

    def secret(self):
        state = self.state()
        if not state.get("secret"):
            state["secret"] = uuid.uuid4().hex
            self.history.save()
        return state["secret"]

    def soon(self, now, delay=1000):
        """Sync shortly (a game just ended, or a daily got a guess)."""
        if self.next_at is None or now + delay < self.next_at:
            self.next_at = now + delay

    # The sync screen's buttons.

    def request_code(self, now):
        self.code = None
        self.message = None
        self._want("code", now)

    def link(self, code, now):
        self.message = None
        self._want("link", now, p_code=code)

    def unlink(self, now):
        """Take this device out of its linked group (after linking by mistake). It keeps the games
        played on it; the others' games leave it, and its games leave them."""
        self.message = None
        self.code = None
        self._want("unlink", now)

    def forget(self, now):
        """Delete this device's games from the server (all of them, if no other device is linked)
        and turn sync off."""
        self.code = None
        self._want("forget", now)

    @property
    def linked_devices(self):
        """How many other devices share this one's games (as of the last sync)."""
        return max(0, int(self.state().get("devices", 1) or 1) - 1)

    # Friends (the Friends screen).

    def friends_data(self):
        """{"profile": {"name", "code", "id"} or None, "list": [{"id", "name", "games"}]}, as last fetched."""
        data = self.state().get("friends")
        return data if isinstance(data, dict) else {"profile": None, "list": []}

    def refresh_friends(self, now, max_age=60 * 1000):
        """Fetch friends' results if the last fetch is older than max_age (the screen calls this)."""
        if not self.enabled or any(w["kind"] == "friends" for w in self.wanted):
            return
        if self.busy and self.busy["kind"] == "friends":
            return
        if self.friends_at is None or now - self.friends_at > max_age:
            self.friends_at = now
            self._want("friends", now)

    def set_name(self, name, now):
        self.friends_message = None
        self._want("profile", now, p_name=name)

    def new_friend_code(self, now):
        self._want("profile", now, p_new_code=True)

    def stop_sharing(self, now):
        self._want("profile", now, p_stop=True)

    def add_friend(self, code, now):
        self.friends_message = None
        self._want("friend_add", now, p_code=code)

    def remove_friend(self, friend_id, now):
        self._want("friend_remove", now, p_friend=friend_id)

    def _want(self, kind, now, **params):
        if not self.enabled and kind != "forget":
            return
        if kind in ("friend_add", "friend_remove", "profile"):
            self.wanted.append({"kind": kind, "params": params})
        else:
            self.wanted = [w for w in self.wanted if w["kind"] != kind] + [{"kind": kind, "params": params}]

    def waiting(self, *kinds):
        """True while a request of one of these kinds is queued or on its way."""
        return any(w["kind"] in kinds for w in self.wanted) or bool(self.busy and self.busy["kind"] in kinds)

    def status(self, now_ms):
        """One line for the sync screen."""
        if not self.configured:
            return "Sync isn't set up in this version"
        if not self.enabled:
            return "Sync is off: games stay on this device only"
        if self.failed:
            return "Can't reach the server right now. Games are saved here and will sync later"
        if not self.state().get("last"):
            return "Syncing..."
        unsent = len(self.history.unsent())
        if unsent:
            return "%d game%s waiting to sync" % (unsent, "" if unsent == 1 else "s")
        others = self.linked_devices
        if others:
            return "Up to date, linked with %d other device%s" % (others, "" if others == 1 else "s")
        return "Up to date"

    # Every frame.

    def tick(self, now):
        """Start a request when one is due and take in any answer. Returns True if games changed."""
        if self.next_at is None:
            self.next_at = now + FIRST_MS
        before = self.applied
        if self.busy:
            result = self.transport.result(self.busy["handle"])
            if result is not None:
                job, self.busy = self.busy, None
                self._finish(job, result, now)
        if self.code and now >= self.code["until"]:
            self.code = None
        # Button requests (codes, friends...) go out at once; the regular sync when it's due.
        if not self.busy and now >= self.hold_until and (self.wanted or (self.enabled and now >= self.next_at)):
            self._send(now)
        return self.applied != before

    def _call(self, function, params):
        headers = {"Content-Type": "application/json", "apikey": self.key}
        if not self.key.startswith("sb_"):  # an old-style anon key (a JWT) also goes in Authorization
            headers["Authorization"] = "Bearer " + self.key
        url = self.url.rstrip("/") + "/rest/v1/rpc/" + function
        return self.transport.start(url, headers, json.dumps(params, separators=(",", ":")))

    def _send(self, now):
        try:
            if self.wanted:
                job = self.wanted.pop(0)
                params = {"p_secret": self.secret()}
                if job["kind"] != "forget":
                    params["p_site"] = self.site
                params.update(job["params"])
                job["handle"] = self._call(FUNCTIONS[job["kind"]], params)
            else:
                games = self.history.unsent()[:MAX_GAMES]
                progress = [g for g in self.history.current.values() if g.get("guesses")][:MAX_PROGRESS]
                job = {"kind": "sync", "sent": [g["id"] for g in games]}
                job["handle"] = self._call("wordle_sync", {
                    "p_secret": self.secret(), "p_site": self.site, "p_since": int(self.state().get("cursor", 0)),
                    "p_games": [upload(g) for g in games], "p_progress": [upload(g) for g in progress]})
            self.busy = job
        except Exception:
            self._failed(now)

    def _say(self, job, text, ok):
        """Show how a button's request went, on the screen it came from."""
        if job["kind"] in FRIEND_KINDS:
            if job["kind"] != "friends":  # (background refreshes stay quiet)
                self.friends_message = (text, ok)
        elif job["kind"] != "sync":
            self.message = (text, ok)

    def _failed(self, now, job=None):
        self.failed = True
        self.hold_until = now + self.retry
        self.next_at = max(self.next_at or 0, self.hold_until)
        self.retry = min(self.retry * 2, MAX_RETRY_MS)
        if job:
            self._say(job, "Can't reach the server. Check the connection and try again", False)

    def _finish(self, job, result, now):
        status, text = result
        try:
            answer = json.loads(text) if status == 200 else None
        except ValueError:
            answer = None
        if not isinstance(answer, dict):
            self._failed(now, job)
            return
        kind = job["kind"]
        if not answer.get("ok"):
            error = answer.get("error", "")
            messages = FRIEND_ERRORS if kind in FRIEND_KINDS else ERRORS
            if error in messages and kind != "sync":
                self._say(job, messages[error], False)
                return
            self._failed(now, job)
            return
        self.failed = False
        self.retry = RETRY_MS
        self.hold_until = 0
        state = self.state()
        if kind == "code":
            self.code = {"code": str(answer.get("code", "")),
                         "until": now + min(CODE_MS, 1000 * int(answer.get("expires_in", 600)))}
            self.next_at = now  # send this device's games now, so the other one gets them when it links
        elif kind == "link":
            self.message = ("Linked! Games from both devices will show on each", True)
            self.code = None
            if not self._new_player(answer.get("player")):
                state["cursor"] = 0  # (first contact was this link) get the other device's games
            self.friends_at = None
            self.history.save()
            self.next_at = now
        elif kind == "unlink":
            if answer.get("unlinked"):
                self.applied += self.history.drop_from_sync()
                state.update(player=answer.get("player"), cursor=0, devices=1)
                state.pop("friends", None)  # (friends belong to the group it left)
                self.friends_at = None
                self.message = ("Unlinked. This device keeps only the games played on it", True)
            else:
                self.message = ("This device isn't linked to any others", True)
            self.history.save()
            self.next_at = now
        elif kind == "forget":
            self.history.sync = {}
            self.history.prefs["sync"] = False
            for game in self.history.games:
                game.pop("sent", None)  # if sync is turned on again, a fresh start uploads them again
            self.history.save()
            self.message = ("Deleted from the server. Sync is off", True)
        elif kind == "profile":
            data = self.friends_data()
            profile = answer.get("profile") if isinstance(answer.get("profile"), dict) else None
            state["friends"] = {"profile": profile, "list": data["list"] if profile else []}
            if job["params"].get("p_stop"):
                self.friends_message = ("You've stopped sharing. Your name and friends are deleted", True)
            elif job["params"].get("p_new_code"):
                self.friends_message = ("New friend code. The old one no longer works", True)
            self.history.save()
            if profile:
                self._want("friends", now)
        elif kind == "friend_add":
            self.friends_message = ("Added %s" % answer.get("name", "your friend"), True)
            self._want("friends", now)
        elif kind == "friend_remove":
            data = self.friends_data()
            gone = job["params"].get("p_friend")
            state["friends"] = dict(data, list=[f for f in data["list"] if f.get("id") != gone])
            self.history.save()
        elif kind == "friends":
            profile = answer.get("profile") if isinstance(answer.get("profile"), dict) else None
            friends = [f for f in answer.get("friends") or [] if isinstance(f, dict) and f.get("id")]
            state["friends"] = {"profile": profile, "list": friends}
            self.history.save()
        else:
            self.next_at = now + EVERY_MS
            self._apply(job, answer, now)

    def _new_player(self, player):
        """Note the server's player id. If it changed (this device was linked to another one's games),
        start downloading from the beginning again; returns True then."""
        state = self.state()
        if not player or player == state.get("player"):
            return False
        switched = bool(state.get("player"))
        state["player"] = player
        if switched:
            state["cursor"] = 0
        return switched

    def _apply(self, job, answer, now):
        state = self.state()
        sent = set(job["sent"])
        for game in self.history.games:
            if game["id"] in sent:
                game["sent"] = True  # (rejected ones too: sending them again wouldn't help)
        games = answer.get("games") if isinstance(answer.get("games"), list) else []
        progress = answer.get("progress") if isinstance(answer.get("progress"), list) else []
        removed = answer.get("removed") if isinstance(answer.get("removed"), list) else []
        self.applied += self.history.merge(games, progress, keep=self.keep, removed=removed)
        if isinstance(answer.get("devices"), int):
            state["devices"] = answer["devices"]
        switched = self._new_player(answer.get("player"))
        if not switched:
            try:
                state["cursor"] = max(int(state.get("cursor", 0)), int(answer.get("cursor", 0)))
            except (TypeError, ValueError):
                pass
        state["last"] = history.now_iso()
        self.history.save()
        if switched or answer.get("more") or self.history.unsent():
            self.next_at = now  # more to send or fetch


def friend_games(rows, mode):
    """A friend's daily results from the server ([mode, number, won, guesses, hints, played_on]) as
    game records history.Stats understands."""
    games = []
    for row in rows:
        try:
            m, number, won, used, hints, played_on = row
            if m == mode:
                games.append({"mode": m, "daily": int(number), "won": bool(won), "guesses": [""] * int(used),
                              "hints": int(hints or 0), "played_on": str(played_on)})
        except (TypeError, ValueError):
            continue
    return games


def friend_summary(games, mode, today):
    """(today's result like "3/6", "X/6" or "-", history.Stats) for one player's daily games."""
    number = daily_number(today)
    limit = 6 if mode == "w" else 9
    result = "-"
    for game in games:
        if game.get("mode") == mode and game.get("daily") == number:
            result = "%d/%d" % (len(game["guesses"]), limit) if game.get("won") else "X/%d" % limit
    return result, history.Stats([g for g in games if g.get("mode") == mode and g.get("daily") is not None],
                                 today, True)


def daily_number(today):
    import daily
    return daily.puzzle_number(today)


def upload(game):
    return {k: game.get(k) for k in UPLOAD_FIELDS if k in game}
